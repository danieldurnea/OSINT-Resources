# Contributing to BBounty Pro

Thanks for considering a contribution. This project favours **focused PRs**
over big bangs. One feature/fix per PR makes review tractable.

## Setup

```bash
git clone <repo>
cd bbounty-pro
cp .env.example .env
# fill in JWT_SECRET, ANTHROPIC_API_KEY (optional), set MODE=local

# Install dependencies
make install-deps

# Install pre-commit hooks (REQUIRED)
pip install pre-commit
pre-commit install
```

## Development workflow

```bash
# Hot-reload dev (foreground, both services)
ALLOW_LOCAL=true make local-dev

# Run tests before pushing
cd apps/orchestrator
go test ./...
go test -tags=integration ./internal/integration/...

# Lint
golangci-lint run

# Build
make build
```

## Branch + commit conventions

- Branches: `feat/short-name`, `fix/short-name`, `docs/short-name`
- Commits: imperative mood, prefix with type:
  - `feat: add tenant isolation`
  - `fix: prevent ROE bypass via redirect`
  - `docs: update VPS deployment guide`
  - `test: add integration tests for auth flow`
  - `refactor: extract constants to config package`

## What we look for in PRs

- **Tests** for new functionality. We don't enforce coverage % but test absence is grounds for review delay.
- **Limitation disclaimers** in code comments when partial. Don't pretend something is production-ready when it isn't.
- **No new dependencies** without justification. Each new Go module increases attack surface.
- **No secrets in commits**. Pre-commit gitleaks should catch this; if it doesn't, you broke the hook.
- **Changes to ROE Gate require extra scrutiny** — this is the safety boundary.

## What we don't accept

- Code that bypasses ROE checks
- Tooling that aids unauthorised testing
- Weaponised exploits, malware, AV evasion
- "Premium" features behind paywalls (this is open-source)
- Major refactors without prior discussion (open an issue first)

## Code style

- **Go**: `gofmt` + `goimports`. Errors wrapped with `fmt.Errorf("ctx: %w", err)`.
- **TypeScript**: `prettier` defaults. Functional components, no class components.
- **Shell**: `shellcheck` clean. `set -euo pipefail` at top.
- **YAML**: 2-space indent. No trailing whitespace.

## Testing

```bash
# Unit tests
go test -v -race -cover ./...

# Integration tests (requires Redis or miniredis)
go test -tags=integration ./internal/integration/...

# Frontend
cd apps/web && bun test
```

## License

By contributing, you agree your code is released under the project license.
See LICENSE for details.
