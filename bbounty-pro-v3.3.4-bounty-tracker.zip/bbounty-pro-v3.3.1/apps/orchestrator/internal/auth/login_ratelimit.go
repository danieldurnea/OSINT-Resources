package auth

// login_ratelimit.go — Redis-backed brute-force protection for /auth/login.
//
// Two-tier approach (defense-in-depth on top of Fail2Ban):
//   Tier 1 — per-IP:      max 10 attempts / 15 min
//   Tier 2 — per-account: max 5 attempts / 15 min (username-based)
//
// On lockout: returns 429 with Retry-After header.
// Successful login resets both counters.

import (
	"context"
	"fmt"
	"net/http"
	"strconv"
	"time"
)

const (
	loginWindowIP      = 15 * time.Minute
	loginWindowAccount = 15 * time.Minute
	maxAttemptsIP      = 10
	maxAttemptsAccount = 5
)

func loginIPKey(ip string) string     { return "login:ip:" + ip }
func loginAccountKey(u string) string { return "login:account:" + u }

// checkLoginRateLimit returns an error if the IP or username is locked out.
// Returns (retry-after seconds, error).
func (m *Manager) checkLoginRateLimit(ctx context.Context, ip, username string) (int, error) {
	// Tier 1 — IP-based
	ipKey := loginIPKey(ip)
	ipCount, err := m.cache.Raw().Incr(ctx, ipKey).Result()
	if err != nil {
		// Redis error → fail open (don't block legitimate users on cache failure)
		return 0, nil
	}
	if ipCount == 1 {
		m.cache.Raw().Expire(ctx, ipKey, loginWindowIP)
	}
	if ipCount > maxAttemptsIP {
		ttl, _ := m.cache.Raw().TTL(ctx, ipKey).Result()
		secs := int(ttl.Seconds())
		if secs < 1 {
			secs = 1
		}
		return secs, fmt.Errorf("too many login attempts from this IP — retry in %ds", secs)
	}

	// Tier 2 — account-based (only if username provided)
	if username != "" {
		accKey := loginAccountKey(username)
		accCount, err := m.cache.Raw().Incr(ctx, accKey).Result()
		if err != nil {
			return 0, nil
		}
		if accCount == 1 {
			m.cache.Raw().Expire(ctx, accKey, loginWindowAccount)
		}
		if accCount > maxAttemptsAccount {
			ttl, _ := m.cache.Raw().TTL(ctx, accKey).Result()
			secs := int(ttl.Seconds())
			if secs < 1 {
				secs = 1
			}
			return secs, fmt.Errorf("account locked — too many failed attempts, retry in %ds", secs)
		}
	}

	return 0, nil
}

// resetLoginRateLimit clears brute-force counters after a successful login.
func (m *Manager) resetLoginRateLimit(ctx context.Context, ip, username string) {
	m.cache.Raw().Del(ctx, loginIPKey(ip), loginAccountKey(username))
}

// realIP extracts the real client IP, respecting X-Real-IP / X-Forwarded-For
// set by Caddy/nginx reverse proxy.
func realIP(r *http.Request) string {
	if ip := r.Header.Get("X-Real-IP"); ip != "" {
		return ip
	}
	if ip := r.Header.Get("X-Forwarded-For"); ip != "" {
		// X-Forwarded-For may be "client, proxy1, proxy2" — take the first
		for i := 0; i < len(ip); i++ {
			if ip[i] == ',' {
				return ip[:i]
			}
		}
		return ip
	}
	// Fallback: strip port from RemoteAddr
	addr := r.RemoteAddr
	for i := len(addr) - 1; i >= 0; i-- {
		if addr[i] == ':' {
			return addr[:i]
		}
	}
	return addr
}

// HandleLogin wraps the base login with brute-force protection.
func (m *Manager) HandleLogin(w http.ResponseWriter, r *http.Request) {
	var req LoginRequest
	if err := decodeJSON(r, &req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}

	ip := realIP(r)

	// Pre-check rate limit (increments counter)
	retryAfter, err := m.checkLoginRateLimit(r.Context(), ip, req.Username)
	if err != nil {
		w.Header().Set("Retry-After", strconv.Itoa(retryAfter))
		w.Header().Set("X-RateLimit-Limit", strconv.Itoa(maxAttemptsIP))
		writeErr(w, http.StatusTooManyRequests, err.Error())
		return
	}

	result, loginErr := m.Login(r.Context(), req)
	if loginErr != nil {
		// Failed login — counter stays incremented
		writeErr(w, http.StatusUnauthorized, loginErr.Error())
		return
	}

	// Success — reset counters
	m.resetLoginRateLimit(r.Context(), ip, req.Username)

	writeJSON(w, http.StatusOK, result)
}
