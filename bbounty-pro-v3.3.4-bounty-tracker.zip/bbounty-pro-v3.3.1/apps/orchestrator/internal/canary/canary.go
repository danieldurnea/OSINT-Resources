// Package canary — honeypot endpoints care detectează recon pe platforma BBounty Pro.
//
// Concept: serverul înregistrează ~20 de URL-uri care arată ca vulnerabilități
// clasice (.env, .git/config, /admin, /wp-admin, etc.). Niciun user legitim
// nu accesează aceste path-uri. Orice hit = intenție de recon = posibil attacker.
//
// Comportament:
//   - Toate hit-urile sunt logate (IP, UA, headers, path, timestamp) în Redis
//     cu TTL de 7 zile pentru investigație ulterioară.
//   - Hit-urile sunt broadcast pe canalul "security" de WebSocket pentru
//     dashboard live.
//   - Dacă notifier-ul e configurat (Slack/Discord/Telegram), trimite alert.
//   - Auto-block: după AutoBlockThreshold hit-uri de la același IP în
//     AutoBlockWindow, IP-ul intră în blocklist Redis cu TTL AutoBlockTTL.
//     Middleware-ul BlockMiddleware respinge automat IP-urile blocate.
//
// Răspunsul către attacker: 404 plauzibil pentru toate path-urile, astfel
// încât atacatorul să nu știe că platforma are canary activ. Variante de
// răspuns "păcălitor" (ex: .env fake) se pot adăuga ulterior dacă e dorit
// (deception defense), dar default-ul e 404 pentru simplicitate.
//
// IP extraction: respectă header-ul X-Forwarded-For dacă există (Caddy +
// Cloudflare îl setează corect); altfel folosește RemoteAddr.

package canary

import (
	"context"
	"encoding/json"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// CanaryPaths — URL-uri capcană înregistrate. Selectate să acopere recon-ul
// clasic pe aplicații web: config leaks, framework admin panels, backup files,
// API doc leaks, cloud credential paths.
//
// IMPORTANT: aceste path-uri NU trebuie să intre în conflict cu rute reale ale
// orchestratorului. Toate path-urile de mai jos sunt verificate să nu se
// suprapună cu /auth, /api/v1, /healthz, /metrics, /ws etc. (rutele reale).
var CanaryPaths = []string{
	// Config leaks
	"/.env",
	"/.env.local",
	"/.env.production",
	"/config.json",
	"/config.yml",
	"/configuration.php",

	// VCS exposure
	"/.git/config",
	"/.git/HEAD",
	"/.gitignore",
	"/.svn/entries",

	// Admin panels (de evitat /admin direct — verificăm ce rute reale există)
	"/wp-admin/",
	"/wp-login.php",
	"/phpmyadmin/",
	"/administrator/",
	"/manager/html",

	// Backup files
	"/backup.zip",
	"/backup.sql",
	"/dump.sql",
	"/db.sql.gz",
	"/site-backup.tar.gz",

	// API doc / Spring Boot / cloud creds
	"/swagger.json",
	"/api-docs",
	"/actuator/env",
	"/actuator/health",
	"/.aws/credentials",
	"/.ssh/id_rsa",
	"/server-status",
	"/server-info",
}

// Hit reprezintă un acces la un canary endpoint.
type Hit struct {
	Timestamp time.Time         `json:"timestamp"`
	IP        string            `json:"ip"`
	UserAgent string            `json:"user_agent"`
	Path      string            `json:"path"`
	Method    string            `json:"method"`
	Referer   string            `json:"referer,omitempty"`
	Headers   map[string]string `json:"headers,omitempty"`
}

// Notifier — interfață minimă pentru a evita dependența circulară cu
// pachetul notify. Implementată de notify.Notifier.Send via wrapper.
type Notifier interface {
	NotifySecurityEvent(ctx context.Context, title, body string, fields map[string]any)
}

// Broadcaster — interfață pentru a transmite evenimente live pe WebSocket.
// Implementată de ws.Hub via wrapper.
type Broadcaster interface {
	BroadcastSecurityEvent(eventType string, payload map[string]any)
}

// Config controlează comportamentul canary.
type Config struct {
	// Redis key prefix pentru hit storage (default "canary:hits:")
	HitPrefix string
	// TTL pentru fiecare hit individual (default 7 zile)
	HitTTL time.Duration
	// Threshold de hit-uri/IP/fereastră înainte de auto-block (default 5)
	AutoBlockThreshold int
	// Fereastra pentru threshold (default 5 min)
	AutoBlockWindow time.Duration
	// TTL pentru IP-uri blocate (default 24h)
	AutoBlockTTL time.Duration
	// Redis key prefix pentru blocklist (default "canary:blocked:")
	BlockPrefix string
}

// DefaultConfig — valori sigure pentru producție.
func DefaultConfig() Config {
	return Config{
		HitPrefix:          "canary:hits:",
		HitTTL:             7 * 24 * time.Hour,
		AutoBlockThreshold: 5,
		AutoBlockWindow:    5 * time.Minute,
		AutoBlockTTL:       24 * time.Hour,
		BlockPrefix:        "canary:blocked:",
	}
}

// Service e handler-ul principal canary.
type Service struct {
	cfg         Config
	redis       *redis.Client
	notifier    Notifier
	broadcaster Broadcaster

	// metrics in-memory pentru /api/v1/admin/canary stats (rapid, fără DB hit)
	mu        sync.RWMutex
	totalHits int64
	hitsPerIP map[string]int64
	startedAt time.Time
}

// NewService creează un Service. notifier și broadcaster sunt opționale —
// dacă nu sunt setate, sistemul tot logează în Redis dar nu mai trimite
// notificări live.
func NewService(redisClient *redis.Client, cfg Config) *Service {
	if cfg.HitPrefix == "" {
		cfg = DefaultConfig()
	}
	return &Service{
		cfg:       cfg,
		redis:     redisClient,
		hitsPerIP: make(map[string]int64),
		startedAt: time.Now(),
	}
}

// SetNotifier atașează un notifier opțional pentru Slack/Discord alerts.
func (s *Service) SetNotifier(n Notifier) {
	s.notifier = n
}

// SetBroadcaster atașează un broadcaster opțional pentru WebSocket live events.
func (s *Service) SetBroadcaster(b Broadcaster) {
	s.broadcaster = b
}

// RegisterRoutes adaugă toate canary endpoints în router-ul Chi.
//
// Toate metodele HTTP (GET/POST/HEAD/PUT/DELETE) sunt acceptate per path —
// attacker-ii fac uneori HEAD înainte de GET. Toate cad pe același handler
// care logează și răspunde 404.
func (s *Service) RegisterRoutes(r chi.Router) {
	for _, path := range CanaryPaths {
		r.HandleFunc(path, s.handleHit)
	}
	log.Info().
		Int("count", len(CanaryPaths)).
		Msg("[canary] registered honeypot endpoints")
}

// handleHit e handler-ul partajat pentru toate canary endpoints.
func (s *Service) handleHit(w http.ResponseWriter, r *http.Request) {
	ip := extractClientIP(r)
	hit := Hit{
		Timestamp: time.Now().UTC(),
		IP:        ip,
		UserAgent: r.UserAgent(),
		Path:      r.URL.Path,
		Method:    r.Method,
		Referer:   r.Referer(),
		Headers:   selectInterestingHeaders(r),
	}

	// Async logging — nu blocăm răspunsul către attacker (vrem ca răspunsul
	// să fie rapid, ca să nu trezim suspiciuni cu latență anormală).
	go s.recordHit(r.Context(), hit)

	// Răspuns 404 generic. Plauzibil — exact ce ar răspunde un server normal
	// pentru un path inexistent.
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.WriteHeader(http.StatusNotFound)
	w.Write([]byte("404 page not found\n"))
}

// recordHit salvează hit-ul în Redis, actualizează contoarele, evaluează
// pragul de auto-block, alertează prin notifier/broadcaster.
func (s *Service) recordHit(ctx context.Context, hit Hit) {
	// 1. Persistă hit-ul în Redis (TTL 7 zile)
	if s.redis != nil {
		payload, err := json.Marshal(hit)
		if err == nil {
			key := s.cfg.HitPrefix + hit.Timestamp.Format("20060102150405") + ":" + hit.IP
			if err := s.redis.Set(ctx, key, payload, s.cfg.HitTTL).Err(); err != nil {
				log.Warn().Err(err).Msg("[canary] failed to persist hit in Redis")
			}
		}

		// 2. Counter per IP în fereastra de auto-block
		windowKey := s.cfg.HitPrefix + "count:" + hit.IP
		count, err := s.redis.Incr(ctx, windowKey).Result()
		if err == nil {
			// Setează expire doar la primul Incr (când count == 1)
			if count == 1 {
				s.redis.Expire(ctx, windowKey, s.cfg.AutoBlockWindow)
			}
			// Auto-block dacă a depășit threshold
			if count >= int64(s.cfg.AutoBlockThreshold) {
				s.blockIP(ctx, hit.IP, count)
			}
		}
	}

	// 3. In-memory metrics
	s.mu.Lock()
	s.totalHits++
	s.hitsPerIP[hit.IP]++
	s.mu.Unlock()

	// 4. Log structurat pentru audit (zerolog folosește deja JSON output)
	log.Warn().
		Str("event", "canary_hit").
		Str("ip", hit.IP).
		Str("path", hit.Path).
		Str("method", hit.Method).
		Str("ua", hit.UserAgent).
		Msg("[canary] honeypot endpoint accessed")

	// 5. Broadcast pe WebSocket pentru live dashboard
	if s.broadcaster != nil {
		s.broadcaster.BroadcastSecurityEvent("canary_hit", map[string]any{
			"ip":        hit.IP,
			"path":      hit.Path,
			"method":    hit.Method,
			"ua":        hit.UserAgent,
			"timestamp": hit.Timestamp.Format(time.RFC3339),
		})
	}

	// 6. Notificare externă (Slack/Discord) — rate-limited natural prin notifier
	if s.notifier != nil {
		s.notifier.NotifySecurityEvent(
			ctx,
			"🪤 Canary endpoint accessed",
			"Suspicious recon detected on BBounty Pro platform",
			map[string]any{
				"ip":     hit.IP,
				"path":   hit.Path,
				"ua":     hit.UserAgent,
				"method": hit.Method,
			},
		)
	}
}

// blockIP adaugă IP-ul în blocklist Redis cu TTL configurat.
func (s *Service) blockIP(ctx context.Context, ip string, hitCount int64) {
	if s.redis == nil {
		return
	}
	key := s.cfg.BlockPrefix + ip
	// SET NX (only if not exists) ca să nu resetăm TTL-ul dacă deja e blocat
	ok, err := s.redis.SetNX(ctx, key, hitCount, s.cfg.AutoBlockTTL).Result()
	if err != nil {
		log.Warn().Err(err).Str("ip", ip).Msg("[canary] failed to block IP")
		return
	}
	if ok {
		log.Warn().
			Str("event", "canary_auto_block").
			Str("ip", ip).
			Int64("hits", hitCount).
			Dur("ttl", s.cfg.AutoBlockTTL).
			Msg("[canary] auto-blocked IP due to threshold breach")

		if s.notifier != nil {
			s.notifier.NotifySecurityEvent(
				ctx,
				"🚫 IP auto-blocked (canary threshold)",
				"IP exceeded canary hit threshold and was auto-blocked",
				map[string]any{
					"ip":   ip,
					"hits": hitCount,
					"ttl":  s.cfg.AutoBlockTTL.String(),
				},
			)
		}
	}
}

// IsBlocked verifică dacă un IP e în blocklist. Folosit de BlockMiddleware.
func (s *Service) IsBlocked(ctx context.Context, ip string) bool {
	if s.redis == nil {
		return false
	}
	n, err := s.redis.Exists(ctx, s.cfg.BlockPrefix+ip).Result()
	if err != nil {
		// Fail-open dacă Redis e down — preferăm să lăsăm traffic legitim
		// să treacă decât să blocăm pe toată lumea când Redis pică.
		return false
	}
	return n > 0
}

// BlockMiddleware respinge request-urile de la IP-uri blocate. Atașează-l
// la nivelul de top al router-ului, înainte de toate celelalte middleware-uri.
func (s *Service) BlockMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip := extractClientIP(r)
		if s.IsBlocked(r.Context(), ip) {
			// 403 generic — nu spunem că e block-uit (info leak); spunem 403 ca
			// orice WAF clasic.
			w.WriteHeader(http.StatusForbidden)
			w.Write([]byte("Forbidden\n"))
			return
		}
		next.ServeHTTP(w, r)
	})
}

// Stats oferă o vedere rapidă a stării canary-ului pentru endpoint-ul admin.
type Stats struct {
	StartedAt       time.Time       `json:"started_at"`
	TotalHits       int64           `json:"total_hits"`
	UniqueIPs       int             `json:"unique_ips"`
	TopOffenders    []OffenderEntry `json:"top_offenders"`
	RegisteredPaths int             `json:"registered_paths"`
}

type OffenderEntry struct {
	IP   string `json:"ip"`
	Hits int64  `json:"hits"`
}

// GetStats returnează statistici în-memory + top 10 offenders.
func (s *Service) GetStats() Stats {
	s.mu.RLock()
	defer s.mu.RUnlock()

	// Top 10 offenders (sortat descrescător după hits)
	top := make([]OffenderEntry, 0, len(s.hitsPerIP))
	for ip, hits := range s.hitsPerIP {
		top = append(top, OffenderEntry{IP: ip, Hits: hits})
	}
	// Sortare simplă (in-place, len e mic; tipic <1000 IPs)
	for i := 0; i < len(top); i++ {
		for j := i + 1; j < len(top); j++ {
			if top[j].Hits > top[i].Hits {
				top[i], top[j] = top[j], top[i]
			}
		}
	}
	if len(top) > 10 {
		top = top[:10]
	}

	return Stats{
		StartedAt:       s.startedAt,
		TotalHits:       s.totalHits,
		UniqueIPs:       len(s.hitsPerIP),
		TopOffenders:    top,
		RegisteredPaths: len(CanaryPaths),
	}
}

// HandleAdminStats e endpoint-ul JSON pentru dashboard.
// Trebuie să fie sub middleware-ul de admin (auth + RequireAdmin) când
// e înregistrat în main.go.
func (s *Service) HandleAdminStats(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(s.GetStats())
}

// HandleAdminListHits returnează cele mai recente hit-uri din Redis.
// Limit implicit 100, max 500. Doar pentru admin.
func (s *Service) HandleAdminListHits(w http.ResponseWriter, r *http.Request) {
	if s.redis == nil {
		w.WriteHeader(http.StatusServiceUnavailable)
		w.Write([]byte(`{"error":"redis not configured"}`))
		return
	}

	// Scan Redis pentru chei canary:hits:* (ignorăm count: contoarele).
	// Limita 500 ca să nu blocheze Redis prea mult.
	var hits []Hit
	iter := s.redis.Scan(r.Context(), 0, s.cfg.HitPrefix+"2*", 500).Iterator()
	for iter.Next(r.Context()) {
		val, err := s.redis.Get(r.Context(), iter.Val()).Result()
		if err != nil {
			continue
		}
		var h Hit
		if json.Unmarshal([]byte(val), &h) == nil {
			hits = append(hits, h)
		}
		if len(hits) >= 500 {
			break
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{
		"hits":  hits,
		"count": len(hits),
	})
}

// extractClientIP — extrage IP-ul real al clientului respectând lanțul de
// proxy-uri (Cloudflare → Caddy → orchestrator).
//
// Ordine de precedență (cel mai de încredere primul, presupunând că Caddy
// e configurat corect să respingă header-ele forjate de client):
//  1. CF-Connecting-IP (Cloudflare original IP)
//  2. X-Real-IP (Caddy/nginx)
//  3. X-Forwarded-For (primul IP din chain)
//  4. RemoteAddr (TCP-level)
//
// NOTĂ DE SECURITATE: dacă orchestrator-ul rulează DIRECT expus (fără proxy),
// orice client poate forja CF-Connecting-IP sau X-Forwarded-For. Asigură-te
// că orchestrator-ul ascultă DOAR pe 127.0.0.1 sau în spatele Caddy.
func extractClientIP(r *http.Request) string {
	if ip := r.Header.Get("CF-Connecting-IP"); ip != "" {
		return strings.TrimSpace(ip)
	}
	if ip := r.Header.Get("X-Real-IP"); ip != "" {
		return strings.TrimSpace(ip)
	}
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		// X-Forwarded-For poate fi "ip1, ip2, ip3" — primul e clientul original
		if parts := strings.Split(xff, ","); len(parts) > 0 {
			return strings.TrimSpace(parts[0])
		}
	}
	// Fallback la RemoteAddr (format "ip:port")
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// selectInterestingHeaders — păstrează doar header-ele relevante pentru
// investigație. Excludem Authorization și Cookie (pot conține secrete) și
// header-ele nesemnificative (Accept-Encoding, Connection, etc).
func selectInterestingHeaders(r *http.Request) map[string]string {
	keep := []string{
		"Host",
		"Accept",
		"Accept-Language",
		"Referer",
		"Origin",
		"CF-Ray",
		"CF-IPCountry",
		"X-Forwarded-Proto",
		"X-Real-IP",
	}
	out := make(map[string]string, len(keep))
	for _, h := range keep {
		if v := r.Header.Get(h); v != "" {
			// Limităm dimensiunea ca să nu stocăm chestii uriașe
			if len(v) > 500 {
				v = v[:500] + "...[truncated]"
			}
			out[h] = v
		}
	}
	return out
}
