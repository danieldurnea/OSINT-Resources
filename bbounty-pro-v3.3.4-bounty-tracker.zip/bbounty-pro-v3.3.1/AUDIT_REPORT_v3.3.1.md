# BBounty Pro v3.3.1 — Audit, Hardening & Dead-Code Cleanup

**Date:** 2026-05-28
**Scope:** `apps/orchestrator` (Go), `apps/ai-proxy` (Python), `apps/agents` (Python), `scripts/*.sh`, `infra/`
**Out of scope (untouched):** `platform/`, `apps/web/`, Vigolium attribution, `aiguard`/`canary` protections.

---

## 0. Build environment note (read this first)

The audit sandbox has **no Go module proxy** (`proxy.golang.org` and the
`golang.org/x/*` vanity hosts are blocked); only `github.com` is reachable.
This is the exact condition the `replace (… => /tmp/golang-mirrors/ …)` block in
`go.mod` was created to work around.

To actually compile/vet/test the code, I stood up a throwaway toolchain that
mirrors the `golang.org/x/*` and `gopkg.in/*` modules from their GitHub sources.
**That mirror setup was used only for verification — it is NOT in the shipped
`go.mod`.** The shipped `go.mod` keeps `go 1.26` and has the broken
`/tmp/golang-mirrors/` replace block **removed** (see §3).

All verification results below were produced against the shipped source tree
(only `go.mod` was temporarily swapped to a buildable form for the local
1.22 toolchain; no source file was altered for verification).

---

## 1. Audit report per zone

Severity: **CRITICAL** = breaks build / security hole · **HIGH** = wrong behavior ·
**MED** = correctness/robustness · **LOW** = cosmetic/hardening.

| Zone | Problem | Severity | Fix |
|---|---|---|---|
| `internal/health/checker.go` | `HandleHealth` had a **duplicate `"status"` map key** and referenced `statusStr`, a variable that only exists in the *other* handler → **does not compile** | CRITICAL | **Applied.** Function now returns `{"status":"ok","probes":results}`. |
| `internal/agent/pipeline.go` | `activeScan` struct **missing the `userID` field** that is set at creation and read by the dead-scan cleanup → **does not compile** | CRITICAL | **Applied.** Added `userID string` field (this is also what `TestActiveScanUserIDNotEmpty` expects). |
| `internal/agent/pipeline.go` | References `claimsKey`, an **unexported identifier from package `auth`** → not visible in `agent`, **does not compile**. The copied claims value is then **never read back** anywhere in the scan goroutine. | CRITICAL | **Applied.** Removed the orphaned `context.WithValue(…, claimsKey, …)` copy; scan context is `context.WithCancel(context.Background())`. `userID` is carried on `scan.userID` (the mechanism the code actually uses). |
| `internal/agent/pipeline.go` | `github.com/spf13/viper` **imported but unused** → does not compile | CRITICAL | **Applied.** Import removed. |
| `cmd/server/main.go` | `canary.NewService(redisClient, …)` passed a `*cache.Client`, but `NewService` wants the raw `*redis.Client` → **does not compile** | CRITICAL | **Applied.** Call site now passes `redisClient.Raw()` (the wrapper already exposes this; matches how `canary` uses the raw client internally). |
| `internal/agent/pipeline_scopeA_test.go` | `TestHandleRefreshCookieFallback` lives in **`package agent`** but tests `cookieRefreshName`, an unexported constant defined in **`package auth`** → test package **does not compile**, taking the whole `agent` test binary down with it | CRITICAL | **Applied.** Test relocated to `internal/auth/cookies_name_test.go` where the constant is visible. Intent (assert the real `auth.cookieRefreshName == "bb_refresh"`) is preserved, not weakened. |
| `internal/agent/conditions.go` | `analyzeOutputs()` has ~15 tool-injection blocks that are **not gated by any `cond.*` flag** (e.g. `uncover`, `tlsx`, `csprecon`, `toxicache`, `rustscan`, `fingerprintx`, `uro`, several `OPT*`). They fire whenever a signal is present even when the active profile **disables conditional chaining entirely**. Caught by the existing `TestConditions_AllDisabled`. | HIGH | **Applied (conservative).** Added an early guard: if every `Conditions` flag is false, inject nothing and return. Satisfies the existing test contract without rewriting individual blocks. *(See §5 — alternative gating is available if preferred.)* |
| `internal/cache/redis_scopeB_test.go` | The path-traversal self-test's inline validation used `strings.HasPrefix(outDir, "/tmp/")` **without `filepath.Clean`**, so `/tmp/../etc` was wrongly accepted — the test asserted `false` and **failed**. (Production `BuildCommand` already cleans correctly; this was a test-only logic bug.) | MED | **Applied.** Test now cleans the path before the prefix check. |
| `internal/findings/report.go` | Dead `titleCase()` (never called) plus a stale `var _ = context.Background` "suppress unused import" hack — `context` is genuinely used at line 56, so the hack is redundant | LOW | **Applied.** Both removed (see §2). |
| `apps/ai-proxy/main.py` | Reviewed AIGUARD sanitization, provider fallback, rate-limit IP key, CORS, secret handling, JSON parsing. **No new bugs.** Shows prior hardening (system-prompt override removed, error details not leaked, `X-Real-IP` rate-limit key). | — | No change. |
| `apps/agents/specialist_agents/ultra_agent.py` | Reviewed `_run` subprocess handling, injection denylist, process-group SIGKILL, FD-leak-on-timeout, AIGUARD mirror. **No bugs.** One Py 3.12 deprecation: `datetime.utcnow()` | LOW | **Fixed** → `datetime.now(timezone.utc)` (§5.4). |
| `scripts/*.sh` (19 files) | `bash -n` syntax check | — | All clean. |
| `infra/` | Redis `bind 127.0.0.1 ::1` ✓; Postgres `pg_hba` rejects external ✓; ai-proxy/Redis ports intentionally not host-exposed ✓; orchestrator runs non-root + `no-new-privileges` + docker.sock removed ✓ | — | One recommendation in §3 (orchestrator host port binding). |

---

## 2. Dead code eliminated

Each removal was confirmed with `grep` across the whole module (including
`_test.go`) to be referenced nowhere else.

| Symbol | File | Why safe to delete |
|---|---|---|
| `containsAny(string, ...string) bool` | `internal/agent/pipeline.go` | Defined once, **called nowhere** (incl. tests). |
| `equalFold(string, string) bool` | `internal/agent/pipeline.go` | Only caller was `containsAny`; orphaned once it was removed. |
| `titleCase(string) string` | `internal/findings/report.go` | Defined once, **called nowhere**. |
| `var _ = context.Background` | `internal/findings/report.go` | "Suppress unused import" hack, but `context` **is** used (line 56). Redundant. |

### Explicitly **NOT** dead — kept on purpose

- **Deprecated-tool `switch` cases in `executor.go`** (`zap`, `astra`, `tplmap`,
  `corsy`, `wfuzz`, `aquatone`, `osmedeus`, `race-the-web`, `403fuzzer`). The
  task asked whether these are dead. **They are not.** `BuildCommand` dispatches
  on `tool.ID` and does **not** check `Enabled`, and the registry explicitly
  documents that operators may *re-enable* a deprecated tool manually. Deleting
  these cases would turn a re-enabled tool into a no-op (generic fallback).
  They are conditionally-reachable, not dead. (`dnsvalidator` has no case and
  is deprecated — that is consistent.)
- **`dalfox`, `kxss`, `byp4xx`, `interactsh`, `notify`** have no standalone
  `case`, but are invoked **inside other tools' chained commands** (e.g. the
  `gf` case pipes into `kxss`/`dalfox`). Intentional, not a gap.

---

## 3. Hardening applied + the `go.mod` decision

### `go.mod` `replace` block → **REMOVED** (recommendation accepted)

The block redirected every `golang.org/x/*` and `gopkg.in/*` module to
`/tmp/golang-mirrors/…`. On any normal machine that path does not exist, so the
build fails immediately. It was an artifact of a network-isolated build host.

**Decision:** removed the entire `replace (…)` block. The shipped `go.mod`
keeps `go 1.26` and resolves dependencies through the normal proxy/VCS.
If you build on an isolated host again, set `GOPROXY`/`GOFLAGS` or vendor
(`go mod vendor`) rather than hard-coding absolute `/tmp` paths into `go.mod`.

### LTS / `go 1.26`

`go 1.26` is retained in `go.mod`. Nothing in the source uses APIs newer than
what 1.22 provides (the code compiles, vets, and tests clean on 1.22), so the
1.26 toolchain is a safe floor — no compatibility blockers found.

### Network binding (verified)

- **Redis:** `infra/redis/redis.conf` → `bind 127.0.0.1 ::1` ✓
- **Postgres:** `infra/postgres/pg_hba.conf` rejects `0.0.0.0/0` and `::/0` ✓
- **ai-proxy / Redis:** host port mappings commented out in `docker-compose.yml`
  with explicit "never expose in prod" notes ✓

### Network binding — orchestrator host port (APPLIED)

- **Orchestrator host port:** `docker-compose.yml` previously mapped
  `ports: ["8080:8080"]` (binds `0.0.0.0:8080`). Changed to
  `["127.0.0.1:8080:8080"]`. Verified safe: nginx reaches the orchestrator over
  the internal docker network (`upstream orchestrator { server orchestrator:8080; }`),
  not the host IP, so routing is unaffected. Satisfies the task objective that
  the orchestrator listen only on loopback.

### Dependencies

- Go deps: pinned in `go.mod`, no flagged versions.
- Python: `requirements.txt` (both runtime and ai-proxy) fully pinned with
  `==`; comment documents the supply-chain rationale. No known-bad versions.

---

## 4. Consistency (registry ↔ executor ↔ installer ↔ skills)

- **Tools = 79** ✓ (`TestAllToolsCount` passes). Breakdown: 67 active subprocess
  + 1 native (`cors-engine`) + 1 AGPL (`vigolium`, **Enabled**) + 10
  deprecated-but-registered.
- **Skills = 8** ✓ — registry IDs match the 8 `apps/skills/<dir>/` folders
  one-to-one, and every folder has a `SKILL.md`.
- **Vigolium:** `Enabled: true`; attribution in `THIRD_PARTY_LICENSES.md`
  (Jessie Ho / AGPL-3.0 / public source link) **intact and untouched**. Report
  footer attribution intact.
- **Injected virtual variants** (`sqlmap-targeted`, `nuclei-paths`,
  `nomore403-smart`, `nuclei-cve-*`, etc.) all have explicit executor handling —
  none fall through to a broken path.

### `afrog` consistency gap — **FIXED**

- **`afrog`** is in the `deep`/`reconftw-deep` profiles and installed by
  `install-ubuntu.sh`, but had **no dedicated `case` in `executor.go`** → ran via
  the generic `afrog <target>` fallback, which afrog ignores (it requires
  `-t`/`-T`). **Added a tuned case** (live-hosts via `-T`, `-json`, severity
  filter, single-target fallback). See §5.2.

---

## 5. Decisions taken (you said "go with your judgment")

All four open items are now **applied**. Rationale for each:

1. **`conditions.go` gating — kept the conservative guard.** When *all*
   `Conditions` flags are false → inject nothing (matches
   `TestConditions_AllDisabled`). I did **not** go granular: mapping each of the
   ~15 ungated blocks to a specific flag would change behavior for
   *partially*-enabled profiles, and the pre-existing behavior for any non-empty
   condition set was "these blocks fire" — so the guard fixes the bug with
   **zero regression** for working profiles. Granular gating can be done later
   if you decide a half-enabled profile should suppress these too.
2. **`afrog` — added a tuned executor case.** Verified afrog v3's real CLI
   (`-T <file>` for multi-target, `-t` for single, `-json`, `-s` severity,
   `-silent`). The case feeds the live-hosts file via `-T`, filters to
   critical/high/medium, writes `_afrog.json`, and falls back to the single
   bare target for early phases. This replaces the broken generic `afrog
   <target>` fallback (which afrog ignores — it needs `-t`/`-T`).
   *Follow-up (not done — larger scope):* afrog JSON is not yet wired into
   `parser.go`, so its findings aren't auto-ingested. Same as before my change
   (the broken fallback produced nothing parseable either); the tool now at
   least runs correctly. Say the word and I'll add an afrog parser case.
3. **Orchestrator host port → `127.0.0.1:8080:8080`.** Verified safe: nginx
   reaches the orchestrator via the internal docker network
   (`upstream orchestrator { server orchestrator:8080; }` in `nginx.conf`), not
   via the host IP, so loopback binding does not break routing. This satisfies
   the task's "ascultă DOAR pe 127.0.0.1" objective.
4. **`datetime.utcnow()` → timezone-aware.** `ultra_agent.py:1373` now uses
   `datetime.now(timezone.utc)`. Silences the Py 3.12 deprecation; identical
   output (`%Y-%m-%d`).

---

## 6. Final verification output

Commands run against the shipped tree (only `go.mod` temporarily swapped to a
1.22-buildable form for the local toolchain; no source changed):

```
$ go vet ./...
VET CLEAN

$ go build ./...
BUILD CLEAN

$ go test ./...
ok   .../internal/agent      0.176s
ok   .../internal/auth       0.043s
ok   .../internal/billing    0.004s
ok   .../internal/cache      0.003s
ok   .../internal/diff       0.004s
ok   .../internal/profile    0.020s
ok   .../internal/roe        0.004s
ok   .../internal/tools      0.014s
$ go test -tags integration ./internal/integration/...
ok   .../internal/integration 0.018s

$ gofmt -l apps/orchestrator/        # (shipped tree)
(empty — clean)

$ python3 -m py_compile apps/ai-proxy/main.py apps/agents/specialist_agents/ultra_agent.py
OK

$ (cd apps/agents && python3 -m pytest tests/ -q)
48 passed

$ for f in scripts/*.sh; do bash -n "$f"; done
ALL SCRIPTS OK

$ grep -c 'ID:' apps/orchestrator/internal/tools/registry.go   # tool count
79
```

### Files changed (substantive)

```
apps/orchestrator/go.mod                                  (replace block removed; go 1.26 kept)
apps/orchestrator/cmd/server/main.go                      (canary .Raw())
apps/orchestrator/internal/health/checker.go              (dup map key)
apps/orchestrator/internal/agent/pipeline.go              (userID field; claimsKey copy removed; viper import; dead funcs)
apps/orchestrator/internal/agent/conditions.go            (all-disabled guard)
apps/orchestrator/internal/findings/report.go             (dead titleCase + context hack)
apps/orchestrator/internal/cache/redis_scopeB_test.go     (filepath.Clean in traversal test)
apps/orchestrator/internal/agent/pipeline_scopeA_test.go  (misplaced test removed)
apps/orchestrator/internal/auth/cookies_name_test.go      (NEW — relocated test)
apps/orchestrator/internal/tools/executor.go              (NEW afrog case — §5.2)
infra/docker-compose.yml                                  (orchestrator port → 127.0.0.1 — §5.3)
apps/agents/specialist_agents/ultra_agent.py              (utcnow → timezone-aware — §5.4)
```

All other changed `.go` files differ by **`gofmt` formatting only** (import
ordering, struct-tag alignment) — no semantic change. `gofmt -l` on the shipped
tree is empty.
