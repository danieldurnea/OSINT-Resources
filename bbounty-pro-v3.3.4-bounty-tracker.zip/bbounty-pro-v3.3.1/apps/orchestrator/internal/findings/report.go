package findings

// report.go — Report export handler for /api/v1/report/{scanID}/export
//
// Generates a professional Markdown report from Redis findings data.
// Format is compatible with HackerOne, Bugcrowd, and Intigriti submission templates.

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// HandleExport generates and streams a Markdown report for a scan.
// GET /api/v1/report/{scanID}/export?format=markdown|json
func (s *Store) HandleExport(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	format := r.URL.Query().Get("format")
	if format == "" {
		format = "markdown"
	}

	items, err := s.ListByScan(r.Context(), scanID)
	if err != nil || len(items) == 0 {
		http.Error(w, `{"error":"no findings for this scan"}`, http.StatusNotFound)
		return
	}

	switch format {
	case "json":
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="report-%s.json"`, scanID[:8]))
		writeJSON(w, http.StatusOK, items)

	case "markdown", "md":
		md := generateMarkdownReport(r.Context(), scanID, items)
		w.Header().Set("Content-Type", "text/markdown; charset=utf-8")
		w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="report-%s.md"`, scanID[:8]))
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(md))

	case "hackerone", "h1", "bugcrowd", "bc":
		// Platform-specific submission drafts (v3.3.4 Report Generator).
		platform, _ := ParseReportPlatform(format)
		md := GeneratePlatformReport(platform, items)
		w.Header().Set("Content-Type", "text/markdown; charset=utf-8")
		w.Header().Set("Content-Disposition",
			fmt.Sprintf(`attachment; filename="report-%s-%s.md"`, string(platform), scanID[:8]))
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(md))

	default:
		http.Error(w, `{"error":"format must be markdown, json, hackerone, or bugcrowd"}`, http.StatusBadRequest)
	}

	log.Info().Str("scan", scanID).Str("format", format).Int("findings", len(items)).Msg("report: exported")
}

// generateMarkdownReport creates a professional Markdown security report.
func generateMarkdownReport(ctx context.Context, scanID string, items []*Finding) string {
	now := time.Now().UTC()

	// Sort: critical → high → medium → low → info
	sevOrder := map[Severity]int{
		SeverityCritical: 0,
		SeverityHigh:     1,
		SeverityMedium:   2,
		SeverityLow:      3,
		SeverityInfo:     4,
	}
	sort.Slice(items, func(i, j int) bool {
		oi := sevOrder[items[i].Severity]
		oj := sevOrder[items[j].Severity]
		if oi != oj {
			return oi < oj
		}
		return items[i].CreatedAt.Before(items[j].CreatedAt)
	})

	// Count by severity
	counts := map[Severity]int{}
	for _, f := range items {
		counts[f.Severity]++
	}
	submittable := 0
	for _, f := range items {
		if f.Status == StatusNew || f.Status == StatusConfirmed {
			submittable++
		}
	}

	var b strings.Builder

	// ── Header ────────────────────────────────────────────────────────────────
	b.WriteString("# Security Assessment Report\n\n")
	b.WriteString(fmt.Sprintf("**Scan ID:** `%s`  \n", scanID))
	b.WriteString(fmt.Sprintf("**Generated:** %s  \n", now.Format("2006-01-02 15:04:05 UTC")))
	b.WriteString(fmt.Sprintf("**Tool:** BBounty Pro v3.3-zen  \n\n"))

	// ── Executive Summary ─────────────────────────────────────────────────────
	b.WriteString("---\n\n## Executive Summary\n\n")
	b.WriteString(fmt.Sprintf("This assessment identified **%d total findings** across the target scope.\n\n", len(items)))

	b.WriteString("| Severity | Count |\n")
	b.WriteString("|----------|-------|\n")
	for _, sev := range []Severity{SeverityCritical, SeverityHigh, SeverityMedium, SeverityLow, SeverityInfo} {
		if c := counts[sev]; c > 0 {
			b.WriteString(fmt.Sprintf("| %s | %d |\n", sevEmoji(sev)+strings.Title(string(sev)), c))
		}
	}
	b.WriteString(fmt.Sprintf("\n**%d findings** are confirmed and ready for submission.\n\n", submittable))

	// ── Findings ──────────────────────────────────────────────────────────────
	b.WriteString("---\n\n## Findings\n\n")

	for i, f := range items {
		if f.Severity == SeverityInfo {
			continue // skip info in main section
		}

		b.WriteString(fmt.Sprintf("### %d. %s\n\n", i+1, f.Title))
		b.WriteString(fmt.Sprintf("| Field | Value |\n"))
		b.WriteString(fmt.Sprintf("|-------|-------|\n"))
		b.WriteString(fmt.Sprintf("| **Severity** | %s%s |\n", sevEmoji(f.Severity), strings.Title(string(f.Severity))))
		b.WriteString(fmt.Sprintf("| **Category** | %s |\n", f.Category))
		b.WriteString(fmt.Sprintf("| **Status** | %s |\n", string(f.Status)))
		b.WriteString(fmt.Sprintf("| **Source** | %s |\n", f.Source))
		if f.CVSS != nil {
			b.WriteString(fmt.Sprintf("| **CVSS Score** | %.1f |\n", *f.CVSS))
		}
		if f.CVSSVector != "" {
			b.WriteString(fmt.Sprintf("| **CVSS Vector** | `%s` |\n", f.CVSSVector))
		}
		b.WriteString(fmt.Sprintf("| **Discovered** | %s |\n", f.CreatedAt.Format("2006-01-02 15:04")))
		b.WriteString("\n")

		b.WriteString(fmt.Sprintf("**URL:** `%s`\n\n", f.URL))

		if f.Parameter != "" {
			b.WriteString(fmt.Sprintf("**Parameter:** `%s`\n\n", f.Parameter))
		}

		if f.Payload != "" {
			b.WriteString("**Payload:**\n```\n")
			b.WriteString(f.Payload)
			b.WriteString("\n```\n\n")
		}

		if f.Response != "" {
			preview := f.Response
			if len(preview) > 500 {
				preview = preview[:500] + "\n...(truncated)"
			}
			b.WriteString("**Evidence:**\n```\n")
			b.WriteString(preview)
			b.WriteString("\n```\n\n")
		}

		if f.AIAnalysis != "" {
			b.WriteString("**AI Triage:**\n> ")
			b.WriteString(strings.ReplaceAll(f.AIAnalysis, "\n", "\n> "))
			b.WriteString("\n\n")
		}

		if len(f.Tags) > 0 {
			b.WriteString(fmt.Sprintf("**Tags:** %s\n\n", strings.Join(f.Tags, ", ")))
		}

		b.WriteString("---\n\n")
	}

	// ── Informational ─────────────────────────────────────────────────────────
	infoItems := []*Finding{}
	for _, f := range items {
		if f.Severity == SeverityInfo {
			infoItems = append(infoItems, f)
		}
	}
	if len(infoItems) > 0 {
		b.WriteString("## Informational Findings\n\n")
		for _, f := range infoItems {
			b.WriteString(fmt.Sprintf("- **%s** — `%s` (%s)\n", f.Title, f.URL, f.Source))
		}
		b.WriteString("\n")
	}

	// ── Footer ────────────────────────────────────────────────────────────────
	b.WriteString("---\n\n")
	b.WriteString("*Generated by [BBounty Pro v3.3-zen](https://github.com/your-org/bbounty-pro)*  \n")
	b.WriteString("*Authorized security testing only — all findings must be reported responsibly.*\n")

	return b.String()
}

func sevEmoji(sev Severity) string {
	switch sev {
	case SeverityCritical:
		return "🔴 "
	case SeverityHigh:
		return "🟠 "
	case SeverityMedium:
		return "🟡 "
	case SeverityLow:
		return "🟢 "
	default:
		return "⚪ "
	}
}
