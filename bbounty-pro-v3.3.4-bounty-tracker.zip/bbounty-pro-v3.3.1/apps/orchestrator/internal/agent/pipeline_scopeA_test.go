package agent

import (
	"context"
	"sync"
	"testing"
	"time"
)

// TestUserIDStoredInActiveScan verifies Fix 1:
// userID must be stored in activeScan.userID, not retrieved from ctx
// (ctx.Value returns nil after context.WithCancel(context.Background()))
func TestUserIDStoredInActiveScan(t *testing.T) {
	scan := &activeScan{
		userID:    "user-123",
		status:    StatusRunning,
		startedAt: time.Now(),
	}
	if scan.userID == "" {
		t.Fatal("activeScan.userID must be set at creation")
	}
	if scan.userID != "user-123" {
		t.Fatalf("expected user-123, got %s", scan.userID)
	}
}

// TestContextValueLostAfterBackground verifies WHY Fix 1 is needed:
// context.WithCancel(context.Background()) loses values from parent request ctx.
func TestContextValueLostAfterBackground(t *testing.T) {
	// Simulate request context with userID
	reqCtx := context.WithValue(context.Background(), "userID", "user-abc")

	// This is what HandleStart does — loses userID!
	scanCtx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Value is NOT propagated
	val := scanCtx.Value("userID")
	if val != nil {
		t.Error("expected userID to be nil in scan context (Background parent)")
	}

	// Value IS in request context
	reqVal := reqCtx.Value("userID")
	if reqVal != "user-abc" {
		t.Errorf("expected user-abc in request context, got %v", reqVal)
	}
}

// TestStopJanitorChannel verifies Fix 2:
// deadScanJanitor must stop when stopJanitor channel is closed.
func TestStopJanitorChannel(t *testing.T) {
	stopCh := make(chan struct{})
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()

	stopped := make(chan bool, 1)

	// Simulate janitor loop
	go func() {
		for {
			select {
			case <-stopCh:
				stopped <- true
				return
			case <-ticker.C:
				// do nothing
			}
		}
	}()

	// Close stop channel
	time.Sleep(50 * time.Millisecond)
	close(stopCh)

	select {
	case <-stopped:
		// pass — janitor stopped correctly
	case <-time.After(500 * time.Millisecond):
		t.Fatal("deadScanJanitor did not stop after stopJanitor channel closed")
	}
}

// TestActiveScanConcurrentAccess verifies Lock() patterns are safe
// for concurrent reads on activeScan fields.
func TestActiveScanConcurrentAccess(t *testing.T) {
	scan := &activeScan{
		status:    StatusRunning,
		startedAt: time.Now(),
		userID:    "user-xyz",
	}

	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			scan.mu.Lock()
			_ = scan.status
			_ = scan.userID
			scan.mu.Unlock()
		}()
	}
	wg.Wait()
}

// TestActiveScanUserIDNotEmpty verifies that userID field exists on activeScan.
func TestActiveScanUserIDNotEmpty(t *testing.T) {
	scan := &activeScan{
		req:       ScanRequest{Target: "example.com"},
		status:    StatusQueued,
		startedAt: time.Now(),
		userID:    "test-user-123",
	}
	if scan.userID == "" {
		t.Fatal("userID must not be empty after creation with non-empty userID")
	}
}

// TestScanContextPropagation verifies Fix 4:
// Scan context created with WithValue preserves claims key.
func TestScanContextPropagation(t *testing.T) {
	type claimsKeyType string
	const ck claimsKeyType = "claims"

	reqCtx := context.WithValue(context.Background(), ck, "test-claims")
	baseCtx := context.WithValue(context.Background(), ck, reqCtx.Value(ck))
	scanCtx, cancel := context.WithCancel(baseCtx)
	defer cancel()

	if scanCtx.Value(ck) != "test-claims" {
		t.Error("claims must propagate into scan context via WithValue")
	}
}
