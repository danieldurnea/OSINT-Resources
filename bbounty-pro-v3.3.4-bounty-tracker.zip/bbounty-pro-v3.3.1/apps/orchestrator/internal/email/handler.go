package email

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/rs/zerolog/log"
)

const resetTokenTTL = 6 * time.Hour

// ResetStore manages password reset tokens in Redis.
type ResetStore struct {
	cache *cache.Client
}

func NewResetStore(c *cache.Client) *ResetStore {
	return &ResetStore{cache: c}
}

func (rs *ResetStore) keyForToken(token string) string {
	return "pwd:reset:token:" + token
}

// CreateToken generates a secure reset token for the given email.
// Stores email → token mapping with 6h TTL.
func (rs *ResetStore) CreateToken(ctx context.Context, email, username string) (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	token := hex.EncodeToString(b)

	data, _ := json.Marshal(map[string]string{
		"email":    email,
		"username": username,
	})

	if err := rs.cache.Raw().Set(ctx,
		rs.keyForToken(token), data, resetTokenTTL,
	).Err(); err != nil {
		return "", err
	}

	return token, nil
}

// ValidateToken verifies the token is valid and returns the associated email.
// Deletes the token after validation (single-use).
func (rs *ResetStore) ValidateToken(ctx context.Context, token string) (email, username string, err error) {
	key := rs.keyForToken(token)
	raw, err := rs.cache.Raw().Get(ctx, key).Result()
	if err != nil {
		return "", "", err
	}

	var data map[string]string
	if err := json.Unmarshal([]byte(raw), &data); err != nil {
		return "", "", err
	}

	// Single-use: delete immediately after validation
	rs.cache.Raw().Del(ctx, key)

	return data["email"], data["username"], nil
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

// Handler combines email service + reset store for HTTP handling.
type Handler struct {
	svc        *Service
	resetStore *ResetStore
	// userLookup is injected from auth package to find user by email
	findUserByEmail func(ctx context.Context, email string) (id, username string, err error)
	// updatePassword is injected from auth package
	updatePassword func(ctx context.Context, userID, newPassword string) error
}

func NewHandler(
	svc *Service,
	resetStore *ResetStore,
	findUserByEmail func(ctx context.Context, email string) (id, username string, err error),
	updatePassword func(ctx context.Context, userID, newPassword string) error,
) *Handler {
	return &Handler{
		svc:             svc,
		resetStore:      resetStore,
		findUserByEmail: findUserByEmail,
		updatePassword:  updatePassword,
	}
}

// HandleForgotPassword initiates the password reset flow.
// POST /auth/forgot-password
// Body: {"email": "user@example.com"}
//
// Always returns 200 regardless of whether email exists —
// prevents user enumeration.
func (h *Handler) HandleForgotPassword(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Email string `json:"email"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid request"}`, http.StatusBadRequest)
		return
	}

	req.Email = strings.ToLower(strings.TrimSpace(req.Email))
	if req.Email == "" {
		http.Error(w, `{"error":"email required"}`, http.StatusBadRequest)
		return
	}

	// Always return 200 — prevents email enumeration
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(`{"message":"If that email exists, a reset link has been sent."}`))

	// Process in background so response is instant
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()

		userID, username, err := h.findUserByEmail(ctx, req.Email)
		if err != nil || userID == "" {
			// L-1 (v3.3.4): do not log the email (PII). The address may not even
			// belong to a user; log only the event.
			log.Debug().Msg("[email] forgot-password: no matching user — no email sent")
			return
		}

		token, err := h.resetStore.CreateToken(ctx, req.Email, username)
		if err != nil {
			log.Error().Err(err).Msg("[email] forgot-password: failed to create token")
			return
		}

		if err := h.svc.SendForgotPassword(ctx, req.Email, username, token); err != nil {
			log.Error().Err(err).Str("user", userID).Msg("[email] forgot-password: send failed")
			return
		}

		log.Info().Str("user", userID).Msg("[email] password reset sent")
	}()
}

// HandleResetPassword processes the reset token and updates the password.
// POST /auth/reset-password
// Body: {"token": "...", "password": "..."}
func (h *Handler) HandleResetPassword(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Token    string `json:"token"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid request"}`, http.StatusBadRequest)
		return
	}

	if req.Token == "" || req.Password == "" {
		http.Error(w, `{"error":"token and password required"}`, http.StatusBadRequest)
		return
	}

	if len(req.Password) < 8 {
		http.Error(w, `{"error":"password must be at least 8 characters"}`, http.StatusBadRequest)
		return
	}

	ctx := r.Context()

	// Validate token (single-use, 6h expiry)
	email, _, err := h.resetStore.ValidateToken(ctx, req.Token)
	if err != nil {
		http.Error(w, `{"error":"invalid or expired reset token"}`, http.StatusBadRequest)
		return
	}

	// Find user by email
	userID, _, err := h.findUserByEmail(ctx, email)
	if err != nil || userID == "" {
		http.Error(w, `{"error":"user not found"}`, http.StatusBadRequest)
		return
	}

	// Update password
	if err := h.updatePassword(ctx, userID, req.Password); err != nil {
		log.Error().Err(err).Str("user", userID).Msg("[email] reset-password: update failed")
		http.Error(w, `{"error":"failed to update password"}`, http.StatusInternalServerError)
		return
	}

	log.Info().Str("user", userID).Msg("[email] password reset successful")

	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte(`{"message":"Password updated successfully. You can now log in."}`))
}
