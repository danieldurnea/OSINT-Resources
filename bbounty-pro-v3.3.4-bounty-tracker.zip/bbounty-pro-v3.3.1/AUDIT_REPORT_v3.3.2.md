# BBounty Pro v3.3.2 — Consolidated Finalization Audit

**Date:** 2026-05-29
**Input:** `bbounty-pro-v3_3_1-AUDITED.zip` + consolidated task list (post-5-pass audit).
**Scope touched:** `apps/orchestrator` (Go), `Makefile`, `scripts/install-ubuntu.sh`,
audit docs (`KNOWN_ISSUES.md`, `OPUS_AUDIT_REPORT.md`, `OPUS_FIXES.md`,
`docs/KALI_NATIVE_DEPLOYMENT.md`).
**Out of scope (untouched, verified):** `platform/`, `apps/web/`, Vigolium
attribution (`THIRD_PARTY_LICENSES.md` + report footer), `aiguard`/`canary`.

---

## 0. Build environment & verification method (read first)

The sandbox ships **no Go toolchain**, `go.dev` is blocked, the box is single-core,
and background processes are killed between commands — so a from-source Go 1.26
bootstrap (which needs a 1.24.6+ bootstrap chain) was infeasible. A native 1.26
toolchain could not be obtained.

Rather than fall back to the "brace-balance" pseudo-checks that let the C1/C2
import crashes slip past three prior audits, I stood up a **real, compiling
toolchain**:

1. Installed the distro Go (`apt` → 1.22.2).
2. Confirmed the code uses **no post-1.22 language/stdlib features** (no
   range-over-func, `iter.Seq`, `os.Root`, `weak`, `runtime.AddCleanup`, etc.).
3. Repackaged the 7 modules missing from the offline cache
   (`golang.org/x/{sync,sys,crypto,time,text}`, `gopkg.in/{yaml.v3,ini.v1}`)
   from their GitHub mirrors into canonical module zips and served them via a
   local `file://` GOPROXY (nested-module subtrees pruned so zips are valid).

This was used **only for verification.** The shipped `go.mod` keeps `go 1.26`
with its original `go.sum` (both restored byte-for-byte; verified with `cmp`).
For each verification run the `go` directive was temporarily lowered to `1.22`
in a working copy and then restored — **no source file was altered for
verification.**

### Final verification — every command passed

| # | Command | Result |
|---|---------|--------|
| 1 | `go vet ./...` | ✅ clean |
| 2 | `go build ./...` | ✅ exit 0 |
| 3 | `go test ./...` | ✅ all pass |
| 4 | `go test -tags integration ./internal/integration/...` | ✅ pass |
| 5 | **`go test -race ./...`** (T1 — first ever) | ✅ **no data races**, 8 pkgs ok |
| 6 | `gofmt -l apps/orchestrator/` | ✅ empty |
| 7 | `py_compile main.py ultra_agent.py` | ✅ OK |
| 8 | `bash -n scripts/*.sh` | ✅ all 19 OK |
| 9 | `cd apps/ai-proxy && python -c "import main"` (T2) | ✅ OK |
| 10 | `cd apps/agents && python -c "import specialist_agents.ultra_agent"` | ✅ OK |
| 11 | `pytest tests/ -q` | ✅ **48 passed** |

---

## 1. Items completed this pass

### T1 — `go test -race` run for the first time · HIGH · ✅
Ran `go test -race ./...` (and `-race` on the integration tag) against a genuine
CGO-enabled toolchain. **No data races reported.** Inspected the two riskiest
shared-state areas: the WS Hub (idiomatic single-goroutine-owns-the-map +
channels — structurally race-free; the `mu` field is unused but harmless) and
the adaptive ratelimiter (`TargetLimiter`, mutex+atomic). Added a concurrency
regression test in `auth` (see T3) that exercises the bootstrap-claim path under
`-race`.
*Residual:* race detection only covers paths the tests exercise; coverage of the
WS Hub broadcast/register path under load is still light (no test harness spins
up real WebSocket clients). Not a defect — noted for future work.

### T2 — CI import smoke-test for ai-proxy · HIGH · ✅
Added a **`smoke-py`** Makefile target that creates a throwaway venv, installs
`requirements.txt`, and actually **imports** `ai-proxy/main.py` and
`specialist_agents/ultra_agent.py` (the latter with `PYTHONPATH` set for its
local `pentest_agents` import). Wired into `deploy-check`. This closes the exact
gap that let C1/C2 through: `py_compile` validates syntax only and never resolves
imports. **Proven working** — both imports succeed live (see §0 rows 9–10).

### T3 — TOCTOU admin-bootstrap race · MEDIUM · ✅ (Lua atomic transaction)
**Implemented as an atomic Lua check-and-claim** (upgraded from the interim SETNX
on your follow-up request). `isFirstUser()` did a non-atomic `LLen==0` check, with
the `RPush` happening much later — after a slow bcrypt(cost 12) — a wide window in
which two concurrent first-registrations could both be promoted to admin
(privilege escalation on SaaS). `Register()` now runs `bootstrapAdminScript`
(`redis.NewScript`): a single server-side script that promotes the caller to
admin **only if** the team list is empty AND the one-shot bootstrap key is
unclaimed, then claims the key. Redis executes scripts atomically, so exactly one
of any number of concurrent callers wins — strictly stronger than a bare SETNX
because it also gates on team-list state. The claim is released on failure paths.
Removed the dead `isFirstUser()` helper. Tests: `TestRegister_AtomicAdminBootstrap`
and a new **16-way concurrent** `TestRegister_ConcurrentFirstUsers` (asserts at
most one admin), both passing under `-race`. miniredis executes the Lua via
gopher-lua, so the test path exercises the real script.

### T4 — Vigolium agentic-mode guard (SF-2) · MEDIUM · ✅
Added `vigoliumCommandSafe()` in `executor.go`: a defense-in-depth, token-based
check that **hard-refuses** (returns `""`, skipping the tool) any vigolium command
containing `agent`/`autopilot`/`swarm` before it reaches bash. We only ever
construct `vigolium scan`, but this protects against a future contributor
changing the template to an unsandboxed agentic sub-mode. Token matching avoids
false positives on hostnames like `swarmtech.example.com`. Covered by
`vigolium_guard_test.go` (guard cases + a regression test that the normal
`vigolium scan` path is unaffected).

### T5 — afrog JSON parser · MEDIUM · ✅
Added `ParseAfrogOutput()` + an `afrog` case to `Parse()`. **Critical nuance the
task hinted at:** afrog writes findings to its `-json` *file*, not stdout, so the
existing `buf`-based parse path never sees them. I therefore wired file-based
ingestion in `pipeline.go` (mirroring the reconFTW pattern): after afrog exits,
read `<scanID8>_afrog.json` and parse it. The parser maps afrog's documented
schema (`target`/`fulltarget`/`id`/`info.{name,author,severity,description,
reference}`, verified against upstream) to `Finding`, and **tolerates a partial
array** (afrog appends the closing `]` only at scan completion). Tests:
`TestParseAfrogOutput`, `…_PartialArray`, `…_Empty`.

### T6 — Output dir perms (SF-5) · LOW · ✅ (incl. fallback hardening)
Tightened both output-dir creations to `0o700` (scan findings may be sensitive on
shared hosts), and **hardened the failure path**: extracted `secureOutputDir()`,
which on a primary-mkdir failure now creates a private per-scan subdir under the
system temp dir at `0o700` — instead of the old `outDir = "/tmp"` that dumped
findings into a world-writable shared directory. So the hardening holds even on
the error path. Tests: `TestSecureOutputDir_Primary0700`,
`…_FallbackUnderTemp`. No bare `/tmp` fallback remains.

### T7 — Pin npm `@vigolium/vigolium` (SF-3) · LOW · ✅
The package **is** published (latest `0.1.16-beta` at pin time), so — better than
the task's "leave a TODO" fallback — I pinned to a concrete version in both
`registry.go` `InstallCmd` and `scripts/install-ubuntu.sh` (via a
`VIGOLIUM_VERSION` var), with a comment to bump deliberately after review and a
provenance-check hint (`npm view … dist.integrity`).

### T8 — Optional unwired modules · LOW · ✅ (zen_proxy gone; constants.go WIRED)
**grep-verified the task's premise is partly stale:** `internal/ai/zen_proxy.go`
**does not exist** anywhere in the tree (removed in a prior pass) — nothing to do.
For `internal/config/constants.go`, on your follow-up request I **wired it in**:
18 of 20 constants are now referenced from the packages that own the behaviour —
auth token TTLs + invite TTL (`auth/manager.go`), findings TTL
(`findings/store.go`), checkpoint TTL (`agent/checkpoint.go`), AI-analysis TTL
(`ai/fallback.go`), snapshot TTL (`diff/engine.go`), notify min-interval
(`notify/notifier.go`), HTTP server + shutdown timeouts (`cmd/server/main.go`),
tool timeout/retries/concurrency + old-output age (`agent/pipeline.go`), and
refresh rate window+max (`auth/refresh_limit.go`). The `config` package imports
only `time`, so this is cycle-free (verified: `go build ./...` clean).

**Two constants left intentionally unwired** to avoid a false semantic coupling on
a coincidental number: `DefaultRateLimit` (the adaptive limiter uses
platform-specific budgets 15/20/50/100, and tool rate flags live inside bash
command strings, not Go) and `OldOutputCleanup` (the only 6h literal is the
*session* janitor interval — a different concern from output cleanup). Documented
in the `constants.go` header and `KNOWN_ISSUES.md`.

### T9 — Auto-resume at boot · INFO · ✅ (decision: keep manual, fix doc)
Verified manual resume is real and live (`Save()` called every phase in
`pipeline.go`; `GET /scan/resumable` + `POST /scan/{id}/resume` mounted in
`main.go`). Auto-resume-at-boot is intentionally not wired. Rewrote the **stale**
`checkpoint.go` package doc (it claimed "STUB only / would need refactor to
consult checkpoints on startup") to accurately describe: save/load real, manual
resume live, auto-resume deliberately omitted (re-hammering targets on a crash
loop is undesirable), plus the genuine per-phase-not-per-tool resume limitation.

### D1–D3 — Documentation sync · ✅
- **D1:** Added v3.3.2 update banners to `OPUS_AUDIT_REPORT.md` and `OPUS_FIXES.md`
  noting Vigolium is now **ENABLED** (Jessie Ho approval, 2026-05-28), superseding
  their "Enabled=false" claims. Fixed the **actively-misleading** pre-deploy
  checklist command: the old `grep 't.ID == "vigolium"'` referenced code that no
  longer exists — replaced with an attribution check against the correct path
  (`THIRD_PARTY_LICENSES.md` is at repo root, not `apps/orchestrator/`).
- **D2:** In `KNOWN_ISSUES.md`, moved resolved items to fixed status — checkpoint
  save (real + manual resume), adaptive ratelimiter (wired via
  `observeHTTPStatuses → RecordResponse`), `durnea_framework.go` (deleted),
  `zen_proxy.go` (file absent), the auth TOCTOU (now SETNX-atomic). Corrected the
  Go version (`1.23+` → `1.26+`) here and in `docs/KALI_NATIVE_DEPLOYMENT.md`.
- **D3:** Fixed the stale `executor.go` vigolium comment ("Ramane Enabled:false…")
  to state the enabled-per-approval status.

### D4 — CSP nonce TODO · noted, untouched
Lives in `apps/web` (read-only). Confirmed it remains tracked in
`SONNET_AUDIT_REPORT.md`; not implemented (requires confirmation + frontend work).

---

## 2. Changeset

```
 KNOWN_ISSUES.md                                 | 44 +++---
 Makefile                                        | 24 ++++-   (T2 smoke-py)
 OPUS_AUDIT_REPORT.md                            | 16 ++++   (D1)
 OPUS_FIXES.md                                   |  7 ++     (D1)
 apps/orchestrator/internal/agent/checkpoint.go  | 35 +++--   (T9 doc)
 apps/orchestrator/internal/agent/pipeline.go    | 27 +++-    (T5 wiring, T6 perms)
 apps/orchestrator/internal/auth/manager.go      | 37 ++++-   (T3 SETNX)
 apps/orchestrator/internal/auth/manager_test.go | 29 ++++    (T3 test)
 apps/orchestrator/internal/tools/executor.go    | 32 ++++-   (T4 guard, D3 comment)
 apps/orchestrator/internal/tools/parser.go      | 89 +++++++ (T5 parser)
 apps/orchestrator/internal/tools/parser_test.go | 53 +++++   (T5 tests)
 apps/orchestrator/internal/tools/registry.go    |  6 +-     (T7 pin)
 apps/orchestrator/internal/tools/vigolium_guard_test.go | new (T4 tests)
 docs/KALI_NATIVE_DEPLOYMENT.md                  |  2 +-     (D2 Go ver)
 scripts/install-ubuntu.sh                       |  7 +-     (T7 pin)
```
`go.mod` / `go.sum` unchanged (restored to original `go 1.26` + original sums).

---

## 3. Follow-up changes (per your request after the first pass)

After the initial v3.3.2 pass (which used SETNX for T3 and left `constants.go`
unwired), you asked for both follow-ups:

1. **T3 → Lua:** switched the atomic admin bootstrap from SETNX to a Lua
   check-and-claim script (gates on team-list emptiness too). Added a 16-way
   concurrent test. ✅
2. **T8 → wire `constants.go`:** 18/20 constants now referenced from their owning
   packages; 2 left unwired for sound semantic reasons (documented). ✅

The other two original questions remain as shipped: **T9** manual resume only
(doc corrected), **T5** afrog parser implemented + tested.

---

## 4. Residual / out of scope

- WS Hub lacks a load-bearing `-race` test harness (real client churn) — T1 residual.
- Per-tool (vs per-phase) resume granularity & findings idempotency — deferred.
- Worker process separation (old item #10), email/PagerDuty in `notify`,
  frontend cookie-auth + CSP nonce (`apps/web`) — deferred / read-only.

---

*Generated 2026-05-29. All §0 checks passed against a real compiling toolchain.*
