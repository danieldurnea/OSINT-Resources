# BBounty Pro v3.3.4 — Curated Payload Set Integration

**Date:** 2026-05-29
**Reference:** swisskyrepo/PayloadsAllTheThings (curated subset, NOT a full import)
**Scope touched:** new `internal/payloads/` package (Go + embedded wordlists) +
one profile flag + opt-in pipeline wiring + attribution. **Untouched:** Go deps,
`platform/`, `apps/web/`, infra.

---

## 0. Verification — all green

| Check | Result |
|---|---|
| `go vet ./...` | ✅ |
| `go build ./...` | ✅ |
| `go test ./...` | ✅ |
| new `payloads` tests (3) + runtime embed check | ✅ |
| `go test -race ./...` | ✅ 0 races, **11 pkgs** (payloads added) |
| `gofmt -l` | ✅ clean |
| `py_compile` / `bash -n` | ✅ |
| `go.mod`/`go.sum` | ✅ pristine, go 1.26 |

---

## 1. The decision: curated, NOT the full corpus

You asked whether importing the full PayloadsAllTheThings list would slow the
tools — **yes, it would**, badly. Fuzzing cost is one HTTP request per payload, so
thousands of payloads × hundreds of URLs = millions of requests per vuln class:
hours-long scans, hammered targets, and a flood of false positives. PayloadsAllTheThings
is also a *documentation* repo (Markdown), not a drop-in payload library.

So per your choices (all 7 categories, ~50 each), I hand-selected a **curated
high-signal set — 362 payloads total**, including WAF-bypass variants, the kind
that actually find bugs:

| Category | Count | File |
|---|---|---|
| XSS | 52 | `lists/xss.txt` |
| SQLi | 57 | `lists/sqli.txt` |
| SSRF | 51 | `lists/ssrf.txt` |
| LFI / path traversal | 50 | `lists/lfi.txt` |
| Open redirect | 49 | `lists/redirect.txt` |
| Command injection | 55 | `lists/cmdi.txt` |
| XXE | 48 | `lists/xxe.txt` |
| **Total** | **362** | |

## 2. Both formats, as requested

- **Go package** `internal/payloads/` — wordlists `go:embed`-ed into the binary;
  accessors `Get(cat)`, `All()`, `Count`, `Total`, `ParseCategory`, `WriteWordlists`.
  Verified the embed loads at runtime (362 payloads).
- **On-disk wordlists** — `WriteWordlists()` materialises them into the scan dir as
  `payloads_<cat>.txt` so disk-based fuzzers (ffuf, dalfox, nuclei-fuzz) can use them.

## 3. Opt-in wiring (default behaviour unchanged)

New profile condition `custom_payloads` (default OFF). When enabled, at scan start
the pipeline writes the 7 wordlists into the scan's output dir and broadcasts a
`payloads_ready` event. Tools can then reference them. Nothing changes for existing
profiles that don't set the flag.

Enable in a profile TOML:
```toml
[conditions]
custom_payloads = true
```

## 4. Performance note (your original question, answered)

- **Memory:** negligible — 362 short strings (~30 KB) embedded in the binary.
- **Scan time:** controlled — the whole point of curating to ~50/category is that
  fuzzing stays fast. With all 7 categories that's 362 requests per URL tested,
  versus tens of thousands with the full corpus. You can trim further per category
  by editing the `.txt` files.
- **No new dependencies**, no change to the default scan path.

## 5. Ethics

Payload sets are for **authorized testing only** — the package doc and attribution
both state this, consistent with the platform's `roe`/`aiguard`/`canary` posture.

---

*Generated 2026-05-29. Curated 362-payload set (7 categories) integrated as an*
*embedded Go package + opt-in on-disk wordlists; all verification green; zero new*
*deps; default scans unchanged. Curated with reference to PayloadsAllTheThings (attributed).*
