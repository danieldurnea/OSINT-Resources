# BBounty Pro v3.3.1

> **Professional Bug Bounty Automation Platform** — Self-hosted, VPS-only.  
> Go orchestrator · Python AI agent · Next.js 15 dashboard · **46 tools** · 34 pipeline optimizations · Claude Sonnet 4.6 + Gemini AI

[![go build](https://img.shields.io/badge/go%20build-passing-54b35f?style=flat-square)](/apps/orchestrator)
[![go test -race](https://img.shields.io/badge/go%20test%20-race-passing-54b35f?style=flat-square)](/apps/orchestrator)
[![tools](https://img.shields.io/badge/tools-46%2F46-00e5cc?style=flat-square)](/apps/orchestrator/internal/tools/registry.go)
[![audits](https://img.shields.io/badge/audits-Scope--E%2FF%2FG-7c6aff?style=flat-square)](/SONNET_AUDIT_REPORT.md)
[![license](https://img.shields.io/badge/license-MIT-7c6aff?style=flat-square)](/LICENSE)

---

## What it does

BBounty Pro automates the full bug bounty workflow — from subdomain enumeration to submission-ready report — on your own VPS. No data sent to third parties (except AI API calls to Anthropic/Google).

```
subfinder → puredns → httpx → [46 tools parallel] → Claude Sonnet 4.6 → H1/Bugcrowd report
```

Every tool receives the correct input from the previous tool. No hardcoded paths. No generic targets. 34 conditional chains based on what's actually found.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│         nginx (TLS 1.3, HSTS, nonce-based CSP, rate limit)           │
└─────────────────────────┬────────────────────────────────────────────┘
                          │
        ┌─────────────────┴─────────────────┐
        │                                   │
┌───────▼─────────┐               ┌─────────▼──────────────────────────┐
│  Next.js 15.2.4 │               │  Go Orchestrator (port 8080)       │
│  React 19       │               │                                    │
│  Tailwind 3.4   │◄──WebSocket───│  ├─ 46-tool registry               │
│                 │               │  ├─ BuildCommand executor           │
│  • Live terminal│               │  ├─ 34 conditional chains           │
│  • Findings tab │               │  ├─ ROE Gate + SafeTarget()         │
│  • Arsenal grid │               │  ├─ Asset DB + diff engine          │
│  • Diff viewer  │               │  ├─ Native CORS engine (7 vectors)  │
│  • AI Agent tab │               │  ├─ Stripe billing + scan limits    │
│  • Reports tab  │               │  └─ JWT + CSRF + httpOnly cookies   │
└─────────────────┘               └─────────┬──────────────────────────┘
                                            │
                   ┌────────────────────────┼────────────────────┐
                   │                        │                    │
        ┌──────────▼──────────┐  ┌──────────▼──────┐  ┌────────▼────────┐
        │  Python Ultra Agent │  │  FastAPI AI Proxy│  │  Redis 7.4      │
        │  ultra_agent.py     │  │  port 8001       │  │  + PostgreSQL   │
        │                     │  │                  │  │                 │
        │  9 modules parallel │  │  Claude primary  │  │  Findings 72h   │
        │  Phase 1: recon     │  │  Gemini fallback │  │  Sessions       │
        │  Phase 2: report    │  │                  │  │  Diff snapshots │
        │                     │  │  Rate limits:    │  │  Brain storage  │
        │  • 48 secret pats   │  │  /chat 60/min    │  │                 │
        │  • 15 always-on HTTP│  │  /analyze 20/min │  │  requirepass    │
        │  • API security mod │  │  /messages 30/min│  │  FLUSHALL off   │
        │  • cariddi processor│  │  global 100/min  │  │  maxmemory 25%  │
        │  • interactsh OOB   │  │                  │  │  AOF everysec   │
        │  • vigolium DAST    │  │                  │  │                 │
        │  • notify (Telegram)│  │                  │  │                 │
        │  • bountyplz submit │  │                  │  │                 │
        └─────────────────────┘  └──────────────────┘  └─────────────────┘
```

---

## 46 Integrated Tools

### Phase RECON (parallel)
`subfinder` · `assetfinder` · `dnsx` · `puredns` · `alterx` · `bbot` · `chaos-client` · `katana` · `cariddi` · `gitleaks` · `trufflehog` · `whatweb` · `wafw00f`

### Phase ENUMERATION (parallel)
`httpx` · `naabu` · `hakrawler` · `gospider` · `gf` · `kxss` · `waybackurls` · `gau` · `aquatone` · `gowitness` · `subzy` · `subjack` · `interactsh-client` · `asnmap`

### Phase SCANNING (parallel)
`nuclei` · **`vigolium`** · `dalfox` · `ffuf` · `feroxbuster` · `wfuzz` · `nikto` · `arjun` · `sqlmap` · `tplmap` · `graphw00f` · `graphql-cop` · `nomore403` · `403fuzzer` · `crlfuzz` · `afrog` · `kiterunner` · `vulnapi` · `astra` · `zap` · `cors-engine` · `ffuf-vhost`

### Phase EXPLOITATION (serial)
`jwt-tool` · `ssrfmap` · `smuggler` · `commix` · `xsstrike` · `corsy` · `linkfinder` · `secretfinder` · `race-the-web` · `wpscan` · `bbounty-agent`

### Special — External Orchestrators
`reconFTW` — unified recon pipeline with dedicated output parser in the platform

### Native Go (no subprocess)
`cors-engine` — 7 CORS vectors: origin reflection, null, subdomain spoof, HTTP downgrade, preflight bypass, wildcard, credentials+reflection

> **vigolium** (AGPL-3.0) — High-fidelity DAST scanner with 251+ modules covering OWASP Top 10, IDOR/BOLA, OAST blind detection, SPA/browser crawl via Chromium CDP. Only native scan mode (`vigolium scan`) is exposed in the pipeline — agent/swarm/autopilot modes are excluded (run unsandboxed per vigolium's SECURITY.md).

---

## Pipeline Optimizations — 34 Active

### Core 17 chains

| Chain | Trigger | Effect |
|-------|---------|--------|
| subfinder → puredns → httpx | always | Wildcard DNS filter, -50% traffic |
| gf xss → kxss → dalfox | XSS params found | dalfox on 20% URLs only |
| httpx tech → nuclei tagged | tech detected | Relevant templates only |
| httpx 401/403 → nomore403 | 403 found | Exact URLs |
| nuclei SQLi → sqlmap-targeted | SQLi confirmed | Exact param |
| katana JS → trufflehog-js | JS files found | Secrets in live bundles |
| ffuf paths → nuclei-paths | 200/301 found | Misconfiguration scan |
| wafw00f WAF → nuclei-waf-bypass | WAF detected | Bypass headers auto |
| nuclei SSRF → ssrfmap-targeted | SSRF confirmed | Exact URL + param |
| crlfuzz CRLF → smuggler | CRLF found | Same host smuggling |
| waybackurls/gau → ffuf-custom | URLs discovered | Historical wordlist |
| dalfox/nuclei XSS → notify | XSS confirmed | Telegram instant |
| httpx version → nuclei-cve-{tech} | Version detected | CVE-specific templates |
| subzy takeover → notify | Takeover found | Telegram instant |
| gitleaks/trufflehog → notify | Secret found | Telegram instant |
| naabu ports → nuclei port-specific | Non-standard port | Port-targeted scan |
| nuclei Critical → bountyplz | Critical confirmed | Auto-submit H1/Bugcrowd |

### API Security chains (5)

| Chain | Trigger | Effect |
|-------|---------|--------|
| katana JS paths → kiterunner | API endpoints found | 20k Swagger route bruteforce |
| swaggerspy spec → astra + kiterunner | OpenAPI spec found | Full API security trio |
| wafw00f WAF → gotestwaf + notify | WAF + API detected | Bypass test + alert |
| graphw00f → kiterunner + vulnapi + graphql-cop | GraphQL found | Full GraphQL audit |
| httpx tech (FastAPI/Django/Spring) → vulnapi | Framework detected | OWASP API Top 10 auto |

### Additional chains (12)

| Chain | Trigger | Effect |
|-------|---------|--------|
| naabu port 9200 → nuclei elastic | Elasticsearch found | Elastic templates |
| arjun 3+ params → vulnapi | Rich API endpoint | OWASP risk assessment |
| kiterunner routes → nuclei + dalfox + sqlmap | API routes found | Full chain |
| vulnapi High/Critical → notify | OWASP finding | Telegram instant |
| astra SQLi confirmed → sqlmap targeted | SQLi confirmed | Exact exploitation |
| hakrawler JS → linkfinder → nuclei | JS files found | Endpoint + scan |
| gospider JS → secretfinder → notify | JS crawled | Secret cross-validation |
| dnsx CNAME → subzy → notify | CNAME found | Takeover check instant |
| feroxbuster /api* 200 → astra + nuclei | API path found | Injection test |
| metagoofil usernames → hydra | Users from metadata | SSH/FTP brute force |
| porch-pirate Postman → kiterunner + nuclei | Postman collection | Internal API routes |
| vigolium HIGH/CRITICAL → notify | DAST finding | Telegram instant |

---

## Quick Start

### Prerequisites

- Ubuntu 22.04 or 24.04 LTS
- 4+ GB RAM, 50+ GB disk
- Go 1.22+, Node.js 20+, Python 3.11+
- Domain with DNS pointed to VPS (for TLS)

### Install

```bash
# 1. Clone
git clone https://github.com/your-org/bbounty-pro.git /opt/bbounty-pro
cd /opt/bbounty-pro

# 2. Install all 46 tools (Ubuntu 22/24 — takes 10-20 min)
sudo bash scripts/install-ubuntu.sh

# 3. Copy environment template
cp .env.example .env
# Edit .env: ANTHROPIC_API_KEY, JWT_SECRET (≥32 chars), FRONTEND_URL, REDIS_URL

# 4. Start infrastructure
docker compose up -d postgres redis

# 5. Build orchestrator
cd apps/orchestrator
go build -ldflags="-X '.../health.Version=3.3.1'" -o ../../dist/orchestrator ./cmd/server

# 6. Install AI proxy dependencies
cd ../../apps/ai-proxy
pip install -r requirements.txt --break-system-packages

# 7. Build frontend
cd ../web
npm ci && npm run build
```

### Configure

```bash
# Minimum required env vars
ANTHROPIC_API_KEY=sk-ant-...          # Claude Sonnet 4.6
JWT_SECRET=your-32-char-secret-here   # ≥32 chars
REDIS_URL=redis://localhost:6379
FRONTEND_URL=https://your-domain.com
ENV=production                         # enables Secure cookies, bcrypt cost 12

# Optional
DATABASE_URL=postgresql://...          # enables PostgreSQL findings sync
SHODAN_API_KEY=...                     # threat intel
BOUNTYPLZ_PLATFORM=hackerone          # auto-submit
BOUNTYPLZ_LIVE=0                      # set 1 to actually submit
```

### Harden

```bash
# OS hardening (UFW, fail2ban, SSH, sysctl)
sudo bash scripts/secure-platform.sh

# Redis hardening
sudo bash scripts/harden-redis.sh

# Set domain + nginx + certbot TLS
sudo bash scripts/set-domain.sh your-domain.com
```

### Launch

```bash
# Start all services
./dist/orchestrator &
cd apps/ai-proxy && uvicorn main:app --port 8001 &
cd apps/web && npm start &
```

### First Scan

```bash
# Via UI: open https://your-domain.com
# Via API:
curl -X POST https://your-domain.com/api/v1/scan/start \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-CSRF-Token: $CSRF" \
  -d '{"target":"target.com","profile":"quick"}'
```

---

## Scan Profiles

| Profile | Tools | Est. Time | Best for |
|---------|-------|-----------|----------|
| `quick` | 5 | 10–15 min | Initial triage, large scope |
| `stealth` | 9 | 20–40 min | Low-noise, passive-first, WAF-safe |
| `api` | 22 | 45–90 min | REST/GraphQL, JWT, IDOR |
| `deep` | 46 | 2–4 hours | Focused target, private programs |
| `reconftw-deep` | hybrid | 1.5–3 hours | reconFTW recon + granular exploitation |
| `wordpress` | dedicated | 30–60 min | WordPress targets |
| `osmedeus` | dedicated | varies | Osmedeus pipeline |

---

## AI Integration

### Claude Sonnet 4.6 (primary)
- Model: `claude-sonnet-4-20250514`
- Critical/High findings: deep analysis via Claude Code CLI (`claude --print`)
- Auto-generates: severity validation, CVSS 3.1 vector, business impact, PoC, submission-ready Markdown report
- Full report: HackerOne/Bugcrowd compatible Markdown via Claude Code

### Gemini (fallback)
- Automatic fallback when Claude is unavailable or rate-limited
- Same API interface via `apps/ai-proxy/main.py`

### 9 Skill Modules (apps/skills/)
`web-audit` · `api-security` · `cloud-security` · `network-security` · `bug-bounty` · `osint` · `red-team` · `exploit-dev` · `report-writing`

### Cost estimate
| Usage | Approx. cost |
|-------|-------------|
| 1 quick scan | ~$0.02 |
| 1 deep scan | ~$0.15 |
| 100 scans/month | ~$5–15 |

---

## Security Features

| Feature | Implementation |
|---------|---------------|
| Authentication | JWT (15 min) + refresh (7 days) in HttpOnly cookies |
| 2FA | TOTP (RFC 6238) |
| CSRF | Double-submit + `crypto/subtle.ConstantTimeCompare` |
| Password hashing | bcrypt cost 12 (~300ms) |
| CSP | Nonce-based via nginx — no `unsafe-inline` |
| TLS | 1.3 only, HSTS |
| Subprocess env | Explicit 12-var allowlist — no secrets passed to tools |
| Shell injection | 15-pattern pre-compiled regex + `SafeTarget()` strict validator |
| Brain storage | `/var/lib/bbounty/brain/` chmod 700, path traversal guard |
| Rate limiting | slowapi on AI proxy, nginx on all endpoints |
| `.env` protection | `.env.*` wildcard in `.gitignore` |

See [SONNET_AUDIT_REPORT.md](SONNET_AUDIT_REPORT.md) for full audit history (Scope-E, Scope-F, Scope-G).

---

## Scan Limits (per plan)

Configure via Stripe in `apps/orchestrator/internal/billing/billing.go`:

| Plan | Scans/month | Parallel | Profile |
|------|-------------|----------|---------|
| Free | 3 | 1 | quick only |
| Pro | 100 | 3 | all |
| Team | unlimited | 10 | all |

---

## Continuous Monitoring

```bash
# Daily recon cron (delta detection — new subdomains, new vulns)
0 2 * * * sudo bash /opt/bbounty-pro/scripts/daily-recon.sh TARGET.COM

# daily-recon.sh runs:
# 1. subfinder + httpx (new subdomains)
# 2. nuclei on new hosts (critical/high templates)
# 3. vigolium DAST on new hosts (lite strategy)
# 4. Delta diff vs yesterday
# 5. Telegram/Slack notification if findings
```

---

## Tests

```bash
# Go — unit + race
cd apps/orchestrator
go test -race ./...

# Go — specific packages
go test -race ./internal/auth/...
go test -race ./internal/agent/...
go test -race ./internal/roe/...

# Python — 25 tests
cd apps/agents
python3 -m pytest tests/ -v

# Python — syntax check all agents
python3 -W error -m py_compile apps/agents/specialist_agents/ultra_agent.py
python3 -W error -m py_compile apps/ai-proxy/main.py
python3 -W error -m py_compile apps/agents/pentest_agents/*.py

# Frontend — typecheck
cd apps/web && npx tsc --noEmit
```

---

## Scripts Reference

| Script | Purpose |
|--------|---------|
| `install-ubuntu.sh` | Install all 46 tools on Ubuntu 22/24 (includes vigolium via npm) |
| `fix-failed-tools.sh` | Retry failed tool installs |
| `daily-recon.sh` | Automated daily recon with delta detection + vigolium DAST on new hosts |
| `recon-pipeline.sh` | Full manual pipeline |
| `health-check.sh` | Verify all services are up |
| `preflight-check.sh` | Pre-deploy checklist |
| `secure-platform.sh` | OS hardening (UFW, fail2ban, SSH, sysctl) |
| `harden-redis.sh` | Redis production config |
| `backup-encrypted.sh` | AES-256-CBC backup of Redis RDB + PostgreSQL dump |
| `set-domain.sh` | Configure domain + nginx + certbot TLS |
| `new-program.sh` | Create workspace for a new bug bounty program |
| `bench.sh` | Benchmark tools on test target |
| `check-nginx-cve.sh` | Check nginx version for known CVEs |
| `install-kali-native.sh` | ⚠️ DEPRECATED — use `install-ubuntu.sh` |
| `install-reconftw.sh` | Install reconFTW separately if needed |

---

## Directory Structure

```
bbounty-pro/
├── apps/
│   ├── orchestrator/          # Go backend (port 8080)
│   │   ├── cmd/server/        # Entry point + route registration
│   │   └── internal/
│   │       ├── agent/         # Pipeline engine + conditions
│   │       ├── auth/          # JWT, TOTP, CSRF, cookies
│   │       ├── billing/       # Stripe integration
│   │       ├── cors/          # Native CORS engine
│   │       ├── diff/          # Scan comparison engine
│   │       ├── findings/      # Redis + PostgreSQL store
│   │       ├── profile/       # Scan profiles (.toml)
│   │       ├── roe/           # Rules of Engagement gate
│   │       ├── tools/         # Registry, executor, parsers
│   │       └── ...
│   ├── ai-proxy/              # Python FastAPI (port 8001)
│   │   ├── main.py            # Routes, rate limits, providers
│   │   └── requirements.txt
│   ├── agents/                # Python agent layer
│   │   ├── specialist_agents/
│   │   │   └── ultra_agent.py # Main agent (v3.3.1-ULTRA)
│   │   └── pentest_agents/    # brain, chain_builder, circuit_breaker...
│   ├── skills/                # 9 AI skill modules (SKILL.md files)
│   └── web/                   # Next.js 15.2.4 frontend
│       ├── app/               # App router pages
│       ├── components/        # Arsenal, Findings, Terminal, Diff...
│       └── lib/               # API client, store, utils
├── infra/
│   ├── nginx/nginx.conf       # TLS 1.3, nonce-CSP, rate limits
│   ├── postgres/              # init.sql, pg_hba.conf
│   ├── redis/redis.conf       # Hardened config
│   ├── docker-compose.yml     # Production stack
│   └── docker-compose.dev.yml # Dev stack (gitignored)
├── scripts/                   # Operational scripts (see table above)
├── docs/
│   ├── openapi.yaml           # Full API spec
│   ├── VPS_DEPLOYMENT.md
│   └── KALI_NATIVE_DEPLOYMENT.md
├── SONNET_AUDIT_REPORT.md     # Security audit history (Scope-E/F/G)
├── AUDIT_FIXES.md             # Previous audit fix log
├── HARDENING_REPORT.md        # Hardening history
├── KNOWN_ISSUES.md            # Architectural debt + first-run checklist
├── CHANGELOG.md
├── .env.example               # All env vars documented
└── Makefile                   # build, vet, test-race, deploy-check
```

---

## Audit History

Three security audit passes completed by Claude Sonnet 4.6:

| Pass | Key findings | Status |
|------|-------------|--------|
| **Scope-E** | CSRF bypass, AI proxy no rate limit, CSP unsafe-inline, shell injection regex broken (`\x08` bug), .gitignore incomplete | ✅ All fixed |
| **Scope-F** | Vigolium integration: AGPL-3.0 legal review required, agent mode excluded (unsandboxed), supply chain via npm | ✅ Documented + mitigated |
| **Scope-G** | Vigolium fully wired: executor BuildCommand, profile .toml, DAST badge + AGPL warning in UI, daily-recon integration | ✅ Complete |

Full report: [SONNET_AUDIT_REPORT.md](SONNET_AUDIT_REPORT.md)

---

## Legal

- BBounty Pro: MIT License
- **vigolium**: AGPL-3.0 — invoked as subprocess. Legal review recommended before offering as hosted SaaS (AGPL §13 network use clause). Self-hosted personal use: no issue.
- All other tools: respective open-source licenses (see `THIRD_PARTY_NOTICES.md` equivalent in each tool's repo)
- **Use only on systems you own or have explicit written authorization to test.**
