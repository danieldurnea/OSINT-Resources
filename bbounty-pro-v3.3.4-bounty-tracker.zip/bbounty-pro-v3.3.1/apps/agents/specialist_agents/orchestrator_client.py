"""
orchestrator_client.py — HTTP client that POSTs agent findings to the
BBounty Pro Go orchestrator's /api/v1/findings endpoint.

Usage:
    from orchestrator_client import OrchestratorClient, AgentFinding

    client = OrchestratorClient()  # reads BBOUNTY_API + BBOUNTY_TOKEN from env
    client.post_finding(AgentFinding(
        scan_id   = os.environ["SCAN_ID"],
        title     = "SQL Injection in /api/users",
        url       = "https://target.com/api/users?id=1",
        severity  = "high",
        category  = "sqli",
        parameter = "id",
        payload   = "1' OR '1'='1",
        source    = "agent.py",
        ai_analysis = "Error-based SQLi confirmed. Submit as P2.",
    ))

Environment variables:
    BBOUNTY_API    — orchestrator base URL (default: http://127.0.0.1:8080)
    SCAN_ID        — scan UUID (injected by pipeline when spawning agents)
"""

from __future__ import annotations

import logging
import os
import time
import urllib.request
import urllib.error
import json
from dataclasses import dataclass, field, asdict
from typing import Optional

log = logging.getLogger(__name__)


@dataclass
class AgentFinding:
    scan_id:     str
    title:       str
    url:         str
    severity:    str          # "critical" | "high" | "medium" | "low" | "info"
    category:    str          # "sqli" | "xss" | "ssrf" | "rce" | ...
    source:      str          # which agent/tool discovered it
    parameter:   str   = ""
    payload:     str   = ""
    response:    str   = ""
    ai_analysis: str   = ""
    tags:        list  = field(default_factory=list)
    cvss:        Optional[float] = None
    cvss_vector: str   = ""


class OrchestratorClient:
    """Thin HTTP client to push agent findings to the BBounty Pro orchestrator.

    Retries up to 3 times on transient errors with exponential backoff.
    Fails silently after max retries — agents should never crash because
    the orchestrator is temporarily unreachable.
    """

    def __init__(
        self,
        base_url: str | None = None,
        timeout:  int        = 10,
        max_retries: int     = 3,
    ):
        self.base_url    = (base_url or os.getenv("BBOUNTY_API", "http://127.0.0.1:8080")).rstrip("/")
        self.timeout     = timeout
        self.max_retries = max_retries

    def post_finding(self, finding: AgentFinding) -> bool:
        """POST a single finding. Returns True on success."""
        payload = self._build_payload(finding)
        return self._post("/api/v1/findings", payload)

    def post_findings(self, findings: list[AgentFinding]) -> int:
        """POST multiple findings. Returns count of successful posts."""
        ok = 0
        for f in findings:
            if self.post_finding(f):
                ok += 1
        return ok

    def health(self) -> bool:
        """Check orchestrator connectivity."""
        try:
            req = urllib.request.Request(
                f"{self.base_url}/healthz",
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return resp.status == 200
        except Exception:
            return False

    # ── Internal ──────────────────────────────────────────────────────────────

    def _build_payload(self, f: AgentFinding) -> dict:
        d = asdict(f)
        # Map Python field names to API field names
        d["scan_id"]     = f.scan_id
        d["ai_analysis"] = f.ai_analysis
        d["cvss_vector"] = f.cvss_vector
        if f.cvss is None:
            d.pop("cvss", None)
        return d

    def _post(self, path: str, payload: dict) -> bool:
        url  = self.base_url + path
        data = json.dumps(payload).encode("utf-8")

        for attempt in range(self.max_retries):
            try:
                req = urllib.request.Request(
                    url,
                    data=data,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    if resp.status in (200, 201, 202):
                        log.debug("orchestrator: finding posted (%s)", payload.get("title", "?"))
                        return True
                    log.warning("orchestrator: unexpected status %d", resp.status)
                    return False

            except urllib.error.HTTPError as e:
                log.warning("orchestrator: HTTP %d on attempt %d — %s", e.code, attempt+1, path)
                if e.code < 500:
                    return False   # 4xx — don't retry
            except urllib.error.URLError as e:
                log.warning("orchestrator: connection error attempt %d — %s", attempt+1, e.reason)
            except Exception as e:
                log.warning("orchestrator: unexpected error attempt %d — %s", attempt+1, e)

            if attempt < self.max_retries - 1:
                time.sleep(2 ** attempt)  # 1s, 2s, 4s

        log.error("orchestrator: failed to post finding after %d attempts", self.max_retries)
        return False


def findings_from_agent_results(
    results:  list[dict],
    scan_id:  str,
    source:   str,
) -> list[AgentFinding]:
    """Convert agent result dicts (format_finding output) to AgentFinding objects.

    Handles the existing agent.py format_finding() dict structure.
    """
    out = []
    for r in results:
        if not isinstance(r, dict):
            continue
        sev_map = {
            "CRITICAL": "critical",
            "HIGH":     "high",
            "MEDIUM":   "medium",
            "LOW":      "low",
            "INFO":     "info",
        }
        raw_sev = str(r.get("severity", "medium")).upper()
        sev = sev_map.get(raw_sev, "medium")

        out.append(AgentFinding(
            scan_id    = scan_id,
            title      = r.get("title", r.get("name", "Unknown finding")),
            url        = r.get("url", r.get("location", "")),
            severity   = sev,
            category   = r.get("category", r.get("cwe", "misc")).lower(),
            source     = source,
            parameter  = r.get("parameter", ""),
            payload    = r.get("payload", ""),
            response   = str(r.get("evidence", ""))[:2000],
            ai_analysis= r.get("description", r.get("remediation", "")),
            tags       = r.get("tags", []),
        ))
    return out
