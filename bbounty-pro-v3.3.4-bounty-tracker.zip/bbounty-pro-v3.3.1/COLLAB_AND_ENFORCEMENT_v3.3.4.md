# BBounty Pro — Scope Enforcement + Collaboration v3.3.4

Two things in this drop: (A) hard scope enforcement at scan start, and (B) the
Collaboration module (share scan results with team hunters).

## A) Scope enforcement hook (hardening)

Previously a scan validated against whatever scope the client sent. Now, if the
request includes `program_id` (a saved Scope Manager program), the orchestrator
**loads that program's scope server-side** and validates against it — a client
can't bypass scope by sending an empty/forged list.

- `ScanRequest` gained `program_id` (optional).
- `HandleStart` resolves the saved program (via a `scopeResolver` interface →
  `scope.Store.ResolveScope`) and overrides `req.Scope/Excluded` before the ROE
  `Validate`. Backward-compatible: no `program_id` → behaves exactly as before.

## B) Collaboration — `internal/collab/`

- **`store.go`** — per-scan share set (`collab:share:<scanID>:members`) + reverse
  index (`collab:with:<userID>`) for "shared with me". Owner-only management.
- **`handlers.go`** — endpoints:
  - `POST   /api/v1/collab/{scanID}/share`  `{"username":"bob"}` (owner shares)
  - `DELETE /api/v1/collab/{scanID}/share/{userID}` (owner revokes)
  - `GET    /api/v1/collab/{scanID}/members`
  - `GET    /api/v1/collab/shared-with-me`
- **Access integration** — the findings store now consults an optional
  `sharedAccess` checker, so a user a scan is shared with can view its findings
  (owner-only otherwise). Single source of truth: ownership stays in Redis
  `scan:owner:`, sharing is additive on top.
- Share-by-username resolves through `auth:uname:<name>` → user id.

### Frontend
- `components/collab/ShareScan.tsx` — a compact, embeddable panel (`<ShareScan
  scanID={id} />`): share by username, see members, revoke. Terminal aesthetic.
- `collabAPI` added to `lib/api-client.ts`.

## Verified
vet ✅ · build ✅ · test ✅ (collab tests + existing) · -race 0 races / 16 pkgs ✅ ·
gofmt ✅ · go.mod pristine (1.26). Frontend: api-client strict-typechecks clean;
ShareScan TSX valid.

## Security notes (honest)
- Sharing is **read-only** (view findings); shared users can't manage the scan.
- Only the owner can grant/revoke (enforced server-side via the ownership check).
- The shared-access check is consulted on the findings list endpoint; if you have
  other per-scan endpoints (stream/export) you want shared too, wire the same
  `collabStore.CanAccess` there — I kept the change surgical to the list endpoint.
- Couldn't run the Next build here (no npm registry) — run npm install && build.

## Roadmap
1.✅ Report Generator 2.✅ Hunter Dashboard 3.✅ Scope Manager 4.✅ Collaboration
   + ✅ scope hard-enforcement
Next: Vulnerability DB (findings store + false-positive learning).
