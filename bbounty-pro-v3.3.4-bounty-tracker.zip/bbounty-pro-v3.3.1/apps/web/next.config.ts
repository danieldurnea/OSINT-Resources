import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    turbo: {
      // Turbopack rules for optimal builds
      rules: {
        "*.svg": {
          loaders: ["@svgr/webpack"],
          as: "*.js",
        },
      },
    },
    // Server Components optimizations
    serverComponentsExternalPackages: ["@node-rs/argon2"],
    optimizePackageImports: [
      "lucide-react",
      "@radix-ui/react-icons",
      "recharts",
    ],
  },

  // Standalone output for minimal Docker image
  output: "standalone",

  // Compiler optimizations
  compiler: {
    removeConsole: process.env.NODE_ENV === "production",
  },

  // Headers for security + performance
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-DNS-Prefetch-Control", value: "on" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          // SE-C2-FIX: CSP moved to nginx (nonce-based, see infra/nginx/nginx.conf).
          // next.config.ts previously emitted script-src 'unsafe-eval' 'unsafe-inline'
          // which overrode the nginx nonce-CSP fix. Headers removed here so nginx is
          // the single authoritative source of Content-Security-Policy.
          // TODO: wire Next.js middleware to propagate nonce from X-Request-ID header
          // into <script nonce="..."> tags once Turbopack nonce support is stable.
        ],
      },
      {
        // Cache static assets aggressively
        source: "/static/(.*)",
        headers: [
          {
            key: "Cache-Control",
            value: "public, max-age=31536000, immutable",
          },
        ],
      },
    ];
  },

  // Rewrites — proxy API calls to Go orchestrator in dev
  async rewrites() {
    return [
      {
        source: "/api/v1/:path*",
        destination: `${process.env.ORCHESTRATOR_URL || "http://localhost:8080"}/api/v1/:path*`,
      },
      {
        source: "/ws/:path*",
        destination: `${process.env.ORCHESTRATOR_URL || "http://localhost:8080"}/ws/:path*`,
      },
    ];
  },

  images: {
    formats: ["image/avif", "image/webp"],
    minimumCacheTTL: 86400,
  },

  // Bundle analyzer in analyze mode
  ...(process.env.ANALYZE === "true" && {
    webpack(config: any) {
      const { BundleAnalyzerPlugin } = require("webpack-bundle-analyzer");
      config.plugins.push(new BundleAnalyzerPlugin({ analyzerMode: "static" }));
      return config;
    },
  }),
};

export default nextConfig;
