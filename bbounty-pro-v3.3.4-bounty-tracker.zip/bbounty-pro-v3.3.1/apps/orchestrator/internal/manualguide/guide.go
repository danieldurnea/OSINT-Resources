// Package manualguide generates a target-tailored manual bug-bounty testing
// checklist after the automated pipeline finishes. It complements automation
// with the steps that need human judgement (business logic, IDOR with two
// accounts, auth bypass, etc.), adapting sections to the technologies and WAF
// detected during the scan.
//
// The guide CONTENT (checklist structure and tips) is adapted from
// github.com/abdullah89255/Advanced-Bug-Bounty-Reconnaissance-Tool (MIT,
// `bugbounty.py` manual-guide generator). Reused under the MIT License; see
// THIRD_PARTY_LICENSES.md. Ported to Go and restructured to consume BBounty
// Pro's scan signals. All techniques are for AUTHORIZED testing only.
package manualguide

import (
	"fmt"
	"sort"
	"strings"
	"time"
)

// Signals are the inputs the generator adapts to.
type Signals struct {
	Domain        string
	BaseURL       string
	Technologies  []string // e.g. ["WordPress", "nginx", "PHP"]
	WAF           string   // "" or "Unknown" if none detected
	FindingCategs []string // categories already found by automation (to flag follow-ups)
}

// Generate returns the full manual-testing guide as plain text (markdown-ish).
// It is deterministic given the same signals (sorted/normalised), so it is easy
// to test and diff.
func Generate(s Signals) string {
	base := s.BaseURL
	if base == "" {
		base = "https://" + s.Domain
	}

	var b strings.Builder
	w := func(format string, a ...any) { fmt.Fprintf(&b, format, a...) }

	w("# Manual Bug Bounty Guide — %s\n", s.Domain)
	w("_Generated %s · for AUTHORIZED testing within program scope only._\n\n",
		time.Now().UTC().Format("2006-01-02 15:04 UTC"))

	if len(s.Technologies) > 0 {
		w("Detected stack: %s\n", strings.Join(dedupeSorted(s.Technologies), ", "))
	}
	if s.WAF != "" && !strings.EqualFold(s.WAF, "unknown") {
		w("WAF/CDN: %s\n", s.WAF)
	}
	w("\n")

	// Static core sections (always included).
	b.WriteString(sectionAuth)
	b.WriteString(sectionIDOR)
	b.WriteString(strings.ReplaceAll(sectionSQLi, "{base}", base))
	b.WriteString(sectionXSS)
	b.WriteString(sectionSSRF)
	b.WriteString(sectionFileUpload)
	b.WriteString(sectionAPI)
	b.WriteString(sectionBusinessLogic)
	b.WriteString(strings.ReplaceAll(sectionSensitiveData, "{domain}", s.Domain))

	// Target-specific section.
	w("\n## 10. Specific to this target\n")

	techGuide := technologyTips(s.Technologies, base, s.Domain)
	if techGuide != "" {
		b.WriteString(techGuide)
	} else {
		w("- No CMS/framework-specific tips matched the detected stack; rely on the generic sections above.\n")
	}

	if s.WAF != "" && !strings.EqualFold(s.WAF, "unknown") {
		w("\n### WAF (%s) — legitimate, low-noise considerations\n", s.WAF)
		b.WriteString(wafTips)
	}

	// Follow-ups based on what automation already flagged.
	if fu := followUps(s.FindingCategs); fu != "" {
		w("\n### Prioritised follow-ups (based on automated findings)\n")
		b.WriteString(fu)
	}

	b.WriteString(strings.ReplaceAll(sectionReporting, "{base}", base))
	return b.String()
}

// technologyTips returns CMS/framework-specific tips for any detected tech.
func technologyTips(techs []string, base, domain string) string {
	var b strings.Builder
	joined := strings.ToLower(strings.Join(techs, " "))
	if strings.Contains(joined, "wordpress") {
		fmt.Fprintf(&b, `### WordPress
- User enumeration: %s/wp-json/wp/v2/users (harvest usernames)
- Plugin/theme CVEs: check versions under /wp-content/plugins/ and /wp-content/themes/
- xmlrpc.php: check if enabled (amplification / pingback SSRF)
- Run the automated wpscan result against known plugin CVEs before manual work
`, base)
	}
	if strings.Contains(joined, "laravel") {
		b.WriteString(`### Laravel
- Check for exposed .env (DB creds, APP_KEY) and /telescope, /horizon dashboards
- Debug mode: trigger an error → Ignition/Whoops stack trace (CVE-2021-3129 RCE if old)
- APP_KEY leak → decrypt/forge session cookies
`)
	}
	if strings.Contains(joined, "django") {
		b.WriteString(`### Django
- DEBUG=True exposes settings/stack traces — try forcing an error
- /admin/ default path; test SSO/weak creds within scope
- Check for unauthenticated DRF endpoints (/api/) and object-level permission gaps
`)
	}
	if strings.Contains(joined, "drupal") {
		b.WriteString(`### Drupal
- CHANGELOG.txt / version → known SA-CORE advisories
- /user/register, /admin paths; check for Drupalgeddon-class issues on old versions
`)
	}
	return b.String()
}

// followUps maps already-found categories to recommended manual deep-dives.
func followUps(categs []string) string {
	seen := map[string]bool{}
	var b strings.Builder
	for _, c := range categs {
		c = strings.ToLower(c)
		if seen[c] {
			continue
		}
		seen[c] = true
		switch {
		case strings.Contains(c, "xss"):
			b.WriteString("- XSS already flagged → confirm impact: cookie theft, account takeover, CSP context.\n")
		case strings.Contains(c, "sqli") || strings.Contains(c, "sql"):
			b.WriteString("- SQLi already flagged → confirm DB read/extraction within scope; check second-order.\n")
		case strings.Contains(c, "ssrf"):
			b.WriteString("- SSRF already flagged → test cloud metadata + internal port reachability.\n")
		case strings.Contains(c, "idor"):
			b.WriteString("- IDOR already flagged → enumerate adjacent object IDs with two accounts.\n")
		case strings.Contains(c, "secret"):
			b.WriteString("- Secrets found (DSL) → validate scope/impact of leaked keys; check for live access.\n")
		case strings.Contains(c, "redirect"):
			b.WriteString("- Open redirect flagged → chain to OAuth token theft / SSRF where possible.\n")
		}
	}
	return b.String()
}

func dedupeSorted(in []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, v := range in {
		v = strings.TrimSpace(v)
		if v == "" || seen[strings.ToLower(v)] {
			continue
		}
		seen[strings.ToLower(v)] = true
		out = append(out, v)
	}
	sort.Strings(out)
	return out
}
