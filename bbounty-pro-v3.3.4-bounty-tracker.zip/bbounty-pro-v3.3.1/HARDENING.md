# HARDENING.md — BBounty Pro v3.3-zen
Generated: 2026-05-12

## Checklist OWASP ASVS L2

### Secrets & Config
- ✅ No secrets in code — all via env vars (`cmd/server/main.go:109`)
- ✅ Fail fast on missing JWT_SECRET at startup (`cmd/server/main.go:109-111`)
- ✅ Redis password required (`scripts/secure-platform.sh`)
- ✅ bcrypt cost 12 (`auth/manager.go:12`)
- ✅ .pre-commit-config.yaml: gitleaks hook (`v8.21.2`)
- ⚠️  Docker image tags without digest — see L3 in AUDIT.md (low priority)

### Input & Validation
- ✅ SafeTarget() blocks private IPs, cloud metadata, shell chars (`tools/executor.go:38`)
- ✅ ROE Gate validates scope before any tool execution (`roe/gate.go`)
- ✅ Schema validation via Pydantic in ai-proxy (`ai-proxy/main.py`)
- ✅ Subprocess uses args slice where possible; shell=True avoided
- ✅ safeReadFile() — 10MB limit on all file reads (`agent/pipeline.go`)

### AuthN / AuthZ
- ✅ JWT in httpOnly cookie (`auth/cookies.go:46-57`)
- ✅ CSRF double-submit pattern — middleware wired on `/api/v1` (`cmd/server/main.go:378`)
- ✅ 2FA TOTP (`auth/totp.go`)
- ✅ RBAC: RoleAdmin/RoleHunter/RoleViewer (`auth/manager.go`)
- ✅ Session expiry: access 15min, refresh 7d (`auth/manager.go:124-125`)
- ✅ Refresh rate limit: 10/hour/user (`auth/refresh_limit.go`)
- ✅ constant-time CSRF compare: subtle.ConstantTimeCompare (`auth/cookies.go`)
- ✅ [C2-FIXED] Login page no longer stores token in sessionStorage
- ✅ [H1-FIXED] 4 components no longer read localStorage.getItem("access_token")

### Network
- ✅ TLS via Caddy/nginx (Let's Encrypt A+)
- ✅ [M3-FIXED] HSTS header added (`nginx/nginx.conf`)
- ✅ [M2-FIXED] CSP header added (`nginx/nginx.conf`)
- ✅ [M4-FIXED] ai-proxy port 8001 not exposed on host
- ✅ [H6-FIXED] JWT token stripped from nginx access logs
- ✅ Rate limiting: register 5/h, login 20/15min (`cmd/server/main.go:304-306`)

### Runtime
- ✅ Orchestrator: non-root (`Dockerfile:36: USER nobody:nobody`)
- ✅ [H3-FIXED] ai-proxy: non-root (`ai-proxy/Dockerfile: USER appuser`)
- ✅ [C1-FIXED] docker.sock removed from orchestrator container
- ✅ [M1-FIXED] Docker resource limits: orchestrator 2CPU/2GB, ai-proxy 1CPU/1GB
- ✅ Subprocess timeout mandatory (`agent/pipeline.go`)
- ✅ Dead scan janitor — kills scans >2h (`agent/pipeline.go`)
- ✅ [M6-FIXED] Subprocess env allowlist — secrets not passed to tools

### Logging & Observability
- ✅ Structured JSON logs (zerolog)
- ✅ Audit log for tool execution, auth events (`auditlog/logger.go`)
- ✅ [C3-FIXED] /metrics restricted to localhost/RFC1918 only
- ✅ [C4-FIXED] /healthz strips public_ip, vps_mode, postgres fields
- ⚠️  Audit log: no HMAC chain (tamper-detectable) — see L1 in AUDIT.md

### Data
- ✅ PostgreSQL: pgx prepared statements (`findings/postgres_sync.go`)
- ✅ Redis: maxmemory 25% RAM, allkeys-lru (`secure-platform.sh`)
- ✅ Backup script: `scripts/backup-redis.sh`

### Supply Chain
- ✅ go.sum committed (`apps/orchestrator/go.sum`)
- ✅ ai-proxy requirements pinned (`apps/ai-proxy/requirements.txt`)
- ✅ [H4-FIXED] Agent requirements pinned (`apps/agents/python_runtime/requirements.txt`)
- ⚠️  apps/web/package-lock.json missing — run `npm install` and commit
- ⚠️  Docker image tags not pinned by digest (L3 — low priority)

### CI/CD
- ✅ .pre-commit-config.yaml: gitleaks, go-vet, shellcheck, yamllint
- ⚠️  No automated gosec / govulncheck in CI pipeline yet

---

## Items neacoperite (trade-off explicit)

| Item | Motivul | Acțiunea necesară |
|------|---------|-------------------|
| Digest-pinned Docker images | Necesită rebuild la fiecare update de securitate | Pin după lansare stabilă |
| Audit log HMAC chain | Complexitate mare, zero valoare fără SIEM | Adaugă dacă ai cerințe compliance |
| govulncheck în CI | Nu există CI pipeline încă | Adaugă când configurezi GitHub Actions |
| package-lock.json | Nu pot rula npm în container | Run local + commit |
