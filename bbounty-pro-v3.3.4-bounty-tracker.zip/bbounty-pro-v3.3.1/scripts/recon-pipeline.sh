#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BBounty Pro — Recon Pipeline
# Adapted from: danieldurnea/BugBounty/scripts/automation/recon-pipeline.sh
# Improvements: parallel execution, live WS stats push, ROE enforcement,
#               structured JSON output, resumable (skip existing outputs)
# Usage: ./recon-pipeline.sh target.com [--scope "*.target.com,api.target.com"]
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
DOMAIN="${1:?Usage: $0 <domain> [--scope scope_pattern]}"
SCOPE="${SCOPE:-*.$DOMAIN}"
RESOLVERS="${RESOLVERS:-/opt/resolvers.txt}"
WORDLISTS="${WORDLISTS:-/opt/wordlists/SecLists}"
RATE_LIMIT="${RATE_LIMIT:-50}"       # requests/sec to target
THREADS="${THREADS:-10}"
ORCHESTRATOR="${ORCHESTRATOR:-http://localhost:8080}"
SCAN_ID="${SCAN_ID:-$(uuidgen 2>/dev/null || cat /proc/sys/kernel/random/uuid)}"

# ── Output structure ──────────────────────────────────────────────────────────
TS=$(date +%Y%m%d_%H%M%S)
OUTDIR="${OUTDIR:-$HOME/pentesting/$DOMAIN/recon-$TS}"
mkdir -p "$OUTDIR"/{screenshots,params,js,ports,vulns}

# ── Colors ────────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; BOLD='\033[1m'; NC='\033[0m'

phase()  { echo -e "\n${BOLD}${CYAN}[$(date +%H:%M:%S)] PHASE: $1${NC}"; }
step()   { echo -e "${GREEN}[+]${NC} $1"; }
info()   { echo -e "${CYAN}[*]${NC} $1"; }
warn()   { echo -e "${YELLOW}[!]${NC} $1"; }
skip()   { echo -e "${YELLOW}[~]${NC} $1 — skipping (already exists)"; }

# Push stat update to orchestrator WS (non-blocking)
push_stat() {
    local key="$1" val="$2"
    curl -sf -X POST "$ORCHESTRATOR/api/v1/stats/$SCAN_ID/increment" \
        -H "Content-Type: application/json" \
        -d "{\"key\":\"$key\",\"value\":$val}" &>/dev/null & true
}

# Run step only if output doesn't exist (resumable pipeline)
run_if_new() {
    local output="$1"; shift
    if [[ -f "$output" && -s "$output" ]]; then
        skip "$(basename $output)"
        return 0
    fi
    "$@"
}

# ─────────────────────────────────────────────────────────────────────────────
echo -e "${BOLD}${CYAN}"
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  BBounty Pro Recon Pipeline                              ║"
echo "║  Target: $DOMAIN"
echo "║  Output: $OUTDIR"
echo "║  Scan ID: $SCAN_ID"
echo "╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 1: SUBDOMAIN ENUMERATION (parallel passive sources)
# ─────────────────────────────────────────────────────────────────────────────
phase "1/6 SUBDOMAIN ENUMERATION"

step "Running passive sources in parallel..."
(
    # All passive enum tools run concurrently — collect into individual files
    run_if_new "$OUTDIR/subs_subfinder.txt" \
        subfinder -d "$DOMAIN" -all -recursive -silent -o "$OUTDIR/subs_subfinder.txt" &

    run_if_new "$OUTDIR/subs_assetfinder.txt" \
        bash -c "assetfinder --subs-only $DOMAIN > $OUTDIR/subs_assetfinder.txt" &

    run_if_new "$OUTDIR/subs_amass.txt" \
        amass enum -passive -d "$DOMAIN" -o "$OUTDIR/subs_amass.txt" &

    # crt.sh via curl (no tool needed)
    run_if_new "$OUTDIR/subs_crtsh.txt" \
        bash -c "curl -sf 'https://crt.sh/?q=%.$DOMAIN&output=json' | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > $OUTDIR/subs_crtsh.txt" &

    wait
)
step "Passive enumeration complete"

# Deduplicate all sources
step "Deduplicating and resolving subdomains..."
sort -u "$OUTDIR"/subs_*.txt 2>/dev/null > "$OUTDIR/subs_all_raw.txt"
TOTAL_RAW=$(wc -l < "$OUTDIR/subs_all_raw.txt")
info "Raw unique subdomains: $TOTAL_RAW"

# DNS resolution — puredns for accuracy, handles wildcard DNS correctly
run_if_new "$OUTDIR/subs_resolved.txt" \
    puredns resolve "$OUTDIR/subs_all_raw.txt" \
        --resolvers "$RESOLVERS" \
        --rate-limit 3000 \
        -q \
        -o "$OUTDIR/subs_resolved.txt"

TOTAL_RESOLVED=$(wc -l < "$OUTDIR/subs_resolved.txt" 2>/dev/null || echo 0)
step "Resolved: $TOTAL_RESOLVED valid subdomains"
push_stat "subs" "$TOTAL_RESOLVED"

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 2: HTTP PROBING & FINGERPRINTING
# ─────────────────────────────────────────────────────────────────────────────
phase "2/6 HTTP PROBING & FINGERPRINTING"

run_if_new "$OUTDIR/alive.json" \
    httpx \
        -l "$OUTDIR/subs_resolved.txt" \
        -td -sc -title -wc -cl -ct -location -server \
        -json \
        -rate-limit "$RATE_LIMIT" \
        -threads "$THREADS" \
        -timeout 10 \
        -o "$OUTDIR/alive.json" \
        -silent

# Extract plain URL list for tools that don't take JSON
jq -r '.url' "$OUTDIR/alive.json" 2>/dev/null | sort -u > "$OUTDIR/alive_urls.txt" || true
TOTAL_LIVE=$(wc -l < "$OUTDIR/alive_urls.txt" 2>/dev/null || echo 0)
step "Live hosts: $TOTAL_LIVE"
push_stat "live" "$TOTAL_LIVE"

# WAF Detection (wafw00f) — parallel per host
step "WAF fingerprinting..."
if command -v wafw00f &>/dev/null && [[ -s "$OUTDIR/alive_urls.txt" ]]; then
    run_if_new "$OUTDIR/waf_results.txt" \
        wafw00f -i "$OUTDIR/alive_urls.txt" -o "$OUTDIR/waf_results.txt" -f json 2>/dev/null || true
fi

# Tech fingerprinting (whatweb)
if command -v whatweb &>/dev/null; then
    step "Technology fingerprinting..."
    run_if_new "$OUTDIR/whatweb.json" \
        whatweb -i "$OUTDIR/alive_urls.txt" --log-json="$OUTDIR/whatweb.json" -a 3 -q 2>/dev/null || true
fi

# Screenshots (aquatone)
step "Taking screenshots (background)..."
if command -v aquatone &>/dev/null && [[ -s "$OUTDIR/subs_resolved.txt" ]]; then
    cat "$OUTDIR/subs_resolved.txt" | \
        aquatone -threads 5 -timeout 30000 -out "$OUTDIR/screenshots/" &>/dev/null &
    AQUATONE_PID=$!
    info "Screenshots running in background (PID: $AQUATONE_PID)"
fi

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 3: URL COLLECTION & CRAWLING
# ─────────────────────────────────────────────────────────────────────────────
phase "3/6 URL COLLECTION & CRAWLING"

step "Running URL collectors in parallel..."
(
    # katana — JS-aware crawler with form detection
    run_if_new "$OUTDIR/urls_katana.txt" \
        katana -list "$OUTDIR/alive_urls.txt" \
            -jc -kf all -aff \
            -d 5 -c 50 -p "$THREADS" \
            -o "$OUTDIR/urls_katana.txt" \
            -silent &

    # waybackurls — historical URLs
    run_if_new "$OUTDIR/urls_wayback.txt" \
        bash -c "cat $OUTDIR/subs_resolved.txt | waybackurls > $OUTDIR/urls_wayback.txt" &

    # gau — multiple archive sources
    run_if_new "$OUTDIR/urls_gau.txt" \
        bash -c "cat $OUTDIR/subs_resolved.txt | gau --threads 5 2>/dev/null > $OUTDIR/urls_gau.txt" &

    # gospider — web spidering
    run_if_new "$OUTDIR/urls_gospider.txt" \
        bash -c "gospider -S $OUTDIR/alive_urls.txt -t 5 -c 5 --json 2>/dev/null | grep -oP 'https?://[^\s\"]+' > $OUTDIR/urls_gospider.txt" &

    wait
)

# Merge and deduplicate all URLs
cat "$OUTDIR"/urls_*.txt 2>/dev/null | sort -u > "$OUTDIR/urls_all.txt"
TOTAL_URLS=$(wc -l < "$OUTDIR/urls_all.txt" 2>/dev/null || echo 0)
step "Total unique URLs: $TOTAL_URLS"
push_stat "urls" "$TOTAL_URLS"

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 4: PATTERN MATCHING & PARAMETER DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────
phase "4/6 PATTERN MATCHING & PARAMETER DISCOVERY"

step "GF pattern matching..."
for pattern in xss sqli ssrf redirect rce idor lfi ssti; do
    if command -v gf &>/dev/null; then
        cat "$OUTDIR/urls_all.txt" | gf "$pattern" 2>/dev/null > "$OUTDIR/gf_${pattern}.txt" || true
        COUNT=$(wc -l < "$OUTDIR/gf_${pattern}.txt" 2>/dev/null || echo 0)
        [[ $COUNT -gt 0 ]] && info "  gf.$pattern: $COUNT URLs"
    fi
done

# Parameter discovery
step "Parameter discovery (arjun)..."
if command -v arjun &>/dev/null; then
    run_if_new "$OUTDIR/params/params.json" \
        arjun -i "$OUTDIR/alive_urls.txt" \
            -oJ "$OUTDIR/params/params.json" \
            -t 10 --stable \
            2>/dev/null || true
fi

# JS secret scanning
step "JS secret scanning..."
grep -E '\.js(\?|$)' "$OUTDIR/urls_all.txt" 2>/dev/null | sort -u > "$OUTDIR/js/js_urls.txt" || true
JS_COUNT=$(wc -l < "$OUTDIR/js/js_urls.txt" 2>/dev/null || echo 0)
info "JS files found: $JS_COUNT"

if [[ $JS_COUNT -gt 0 ]] && command -v secretfinder &>/dev/null; then
    while IFS= read -r url; do
        secretfinder -i "$url" -o cli 2>/dev/null >> "$OUTDIR/js/js_secrets.txt" || true
    done < "$OUTDIR/js/js_urls.txt"
fi

# Gitleaks on collected output
step "Secret scanning collected output..."
if command -v gitleaks &>/dev/null; then
    gitleaks detect --source "$OUTDIR" \
        -r "$OUTDIR/gitleaks_report.json" \
        -f json --no-banner \
        2>/dev/null || true
fi

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 5: VULNERABILITY SCANNING
# ─────────────────────────────────────────────────────────────────────────────
phase "5/6 VULNERABILITY SCANNING"

# Port scan — non-standard ports often most interesting
step "Port scanning..."
run_if_new "$OUTDIR/ports/ports.json" \
    naabu \
        -l "$OUTDIR/subs_resolved.txt" \
        -p "80,443,8080,8443,8888,9090,3000,4000,5000,8000,9000,9200,6379,27017,5432,3306,6443" \
        -rate 2000 \
        -json \
        -o "$OUTDIR/ports/ports.json" \
        -silent 2>/dev/null || true

# Nuclei — critical/high first (fast pass for quick wins)
step "Nuclei scan — Critical/High (fast pass)..."
run_if_new "$OUTDIR/vulns/nuclei_critical.json" \
    nuclei \
        -l "$OUTDIR/alive_urls.txt" \
        -t nuclei-templates/ \
        -severity critical,high \
        -rate-limit "$RATE_LIMIT" \
        -json-export "$OUTDIR/vulns/nuclei_critical.json" \
        -silent 2>/dev/null || true

CRITICAL_COUNT=$(jq -s 'length' "$OUTDIR/vulns/nuclei_critical.json" 2>/dev/null || echo 0)
step "Critical/High nuclei findings: $CRITICAL_COUNT"
push_stat "vulns" "$CRITICAL_COUNT"

# Nuclei — medium in background
step "Nuclei — Medium severity (background)..."
nuclei \
    -l "$OUTDIR/alive_urls.txt" \
    -t nuclei-templates/ \
    -severity medium \
    -rate-limit 30 \
    -json-export "$OUTDIR/vulns/nuclei_medium.json" \
    -silent &>/dev/null &
info "Medium nuclei scan running in background (PID: $!)"

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 6: SUMMARY REPORT
# ─────────────────────────────────────────────────────────────────────────────
phase "6/6 SUMMARY"

SUMMARY="$OUTDIR/summary.txt"
cat > "$SUMMARY" << SUMMARY_EOF
# Recon Summary — $DOMAIN
# Generated: $(date)
# Scan ID: $SCAN_ID

## Discovery Stats
Subdomains (raw):   $TOTAL_RAW
Subdomains (valid): $TOTAL_RESOLVED
Live Hosts:         $TOTAL_LIVE
Total URLs:         $TOTAL_URLS
Critical Vulns:     $CRITICAL_COUNT
JS Files:           $JS_COUNT

## Output Files
$OUTDIR/
  subs_resolved.txt    — Valid subdomains
  alive.json           — Live hosts with metadata
  alive_urls.txt       — Plain URL list
  urls_all.txt         — All collected URLs
  gf_xss.txt           — XSS parameter candidates
  gf_sqli.txt          — SQLi parameter candidates
  gf_ssrf.txt          — SSRF parameter candidates
  ports/ports.json     — Port scan results
  vulns/nuclei_critical.json — Critical/High findings
  js/js_secrets.txt    — Potential secrets in JS
  screenshots/         — Visual screenshots

## Recommended Next Steps
1. Review nuclei_critical.json for immediate findings
2. Test gf_xss.txt URLs with dalfox
3. Test gf_sqli.txt URLs with sqlmap/ghauri
4. Test gf_ssrf.txt with ssrfmap
5. Check non-standard ports in ports.json
6. Validate JS secrets in js_secrets.txt
7. Run commix on gf_rce.txt URLs
SUMMARY_EOF

cat "$SUMMARY"
echo ""
echo -e "${GREEN}${BOLD}Pipeline complete! Results: $OUTDIR${NC}"
echo -e "${CYAN}Push to agent: $ORCHESTRATOR/api/v1/scan/$SCAN_ID${NC}"
