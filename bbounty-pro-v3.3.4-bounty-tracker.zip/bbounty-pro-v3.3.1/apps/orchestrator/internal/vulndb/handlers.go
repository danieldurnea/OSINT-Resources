package vulndb

import (
	"encoding/json"
	"net/http"
	"strconv"
)

// handlers.go — Vulnerability Database endpoints:
//   GET  /api/v1/vulndb              list entries (newest first)
//   GET  /api/v1/vulndb/stats        summary (counts, FP count)
//   POST /api/v1/vulndb/check        {category,url,parameter} → {fingerprint, known_false_positive}

type UserIDFunc func(r *http.Request) string

type Handler struct {
	store  *Store
	userID UserIDFunc
}

func NewHandler(store *Store, userID UserIDFunc) *Handler {
	return &Handler{store: store, userID: userID}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (h *Handler) uid(w http.ResponseWriter, r *http.Request) (string, bool) {
	id := h.userID(r)
	if id == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return "", false
	}
	return id, true
}

func (h *Handler) HandleList(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	limit := 200
	if v := r.URL.Query().Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			limit = n
		}
	}
	entries, err := h.store.List(r.Context(), uid, limit)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load vuln DB"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"entries": entries, "count": len(entries)})
}

func (h *Handler) HandleStats(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	st, err := h.store.Summary(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not summarise"})
		return
	}
	writeJSON(w, http.StatusOK, st)
}

// checkReq lets a client test whether a candidate finding is a known false
// positive before bothering the hunter with it.
type checkReq struct {
	Category  string `json:"category"`
	URL       string `json:"url"`
	Parameter string `json:"parameter"`
}

func (h *Handler) HandleCheck(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	var req checkReq
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(&req); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid body"})
		return
	}
	fp := Fingerprint(req.Category, req.URL, req.Parameter)
	writeJSON(w, http.StatusOK, map[string]any{
		"fingerprint":          fp,
		"known_false_positive": h.store.IsFalsePositive(r.Context(), uid, fp),
	})
}
