"use client";

// Global error boundary — the LAST line of defense. Unlike app/error.tsx, this
// also catches errors thrown in the root layout itself. It must render its own
// <html>/<body> because it replaces the entire document when it activates.
// Kept deliberately minimal (no app dependencies) so it can never itself fail.

import { useEffect } from "react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // eslint-disable-next-line no-console
    console.error("[bbounty] global error:", error);
  }, [error]);

  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#080c0e",
          color: "#c8d8e0",
          fontFamily:
            "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace",
          padding: "24px",
        }}
      >
        <div
          style={{
            width: "100%",
            maxWidth: 420,
            border: "1px solid #1c2a2e",
            borderRadius: 8,
            background: "#0c1214",
            padding: 28,
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              marginBottom: 16,
            }}
          >
            <span style={{ color: "#ff5c7a", fontSize: 20 }}>●</span>
            <h1
              style={{
                fontSize: 13,
                letterSpacing: 3,
                textTransform: "uppercase",
                color: "#8aa0aa",
                margin: 0,
              }}
            >
              Application error
            </h1>
          </div>
          <p
            style={{
              fontSize: 13,
              lineHeight: 1.6,
              color: "#9fb4bd",
              marginTop: 0,
              marginBottom: 20,
            }}
          >
            The interface encountered a fatal error and had to stop. Reloading
            usually fixes it. If it keeps happening, the backend may be
            unavailable.
          </p>
          <button
            onClick={() => reset()}
            style={{
              padding: "9px 18px",
              fontSize: 12,
              fontWeight: 600,
              letterSpacing: 1,
              borderRadius: 6,
              background: "#0e3a32",
              color: "#7fffd6",
              border: "1px solid #1f6f5c",
              cursor: "pointer",
            }}
          >
            ↻ Reload
          </button>
        </div>
      </body>
    </html>
  );
}
