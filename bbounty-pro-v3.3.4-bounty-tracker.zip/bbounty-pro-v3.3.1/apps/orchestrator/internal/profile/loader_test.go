package profile_test

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/bbounty-pro/orchestrator/internal/profile"
)

func TestLoader_EmbeddedProfiles(t *testing.T) {
	l := profile.NewLoader("") // empty dir = embedded only
	if err := l.Load(); err != nil {
		t.Fatalf("Load: %v", err)
	}

	// All expected built-in profiles must exist
	expected := []string{"quick", "deep", "stealth", "wordpress", "api", "reconftw-deep", "osmedeus"}
	for _, name := range expected {
		p := l.Get(name)
		if p == nil {
			t.Errorf("embedded profile %q not found", name)
			continue
		}
		if p.Name != name {
			t.Errorf("profile name mismatch: got %q want %q", p.Name, name)
		}
		if len(p.Tools) == 0 {
			t.Errorf("profile %q has no tools", name)
		}
		if p.MaxConcurrent <= 0 {
			t.Errorf("profile %q has invalid MaxConcurrent %d", name, p.MaxConcurrent)
		}
		if p.RateLimit <= 0 {
			t.Errorf("profile %q has invalid RateLimit %d", name, p.RateLimit)
		}
	}
}

func TestLoader_DefaultProfile(t *testing.T) {
	l := profile.NewLoader("")
	if err := l.Load(); err != nil {
		t.Fatalf("Load: %v", err)
	}
	def := l.Default()
	if def == nil {
		t.Fatal("Default() returned nil")
	}
	if def.Name != "deep" {
		t.Errorf("expected default profile to be 'deep', got %q", def.Name)
	}
}

func TestLoader_UserProfileOverridesBuiltin(t *testing.T) {
	dir := t.TempDir()

	// Write a user profile that overrides the built-in 'quick' profile
	custom := `
name        = "quick"
description = "Custom quick override"
rate_limit  = 999
max_concurrent = 99
tools = ["subfinder", "httpx"]
`
	os.WriteFile(filepath.Join(dir, "quick.toml"), []byte(custom), 0o644)

	l := profile.NewLoader(dir)
	if err := l.Load(); err != nil {
		t.Fatalf("Load: %v", err)
	}

	p := l.Get("quick")
	if p == nil {
		t.Fatal("quick profile not found")
	}
	if p.RateLimit != 999 {
		t.Errorf("expected user override rate_limit=999, got %d", p.RateLimit)
	}
	if p.MaxConcurrent != 99 {
		t.Errorf("expected user override max_concurrent=99, got %d", p.MaxConcurrent)
	}
	if p.Description != "Custom quick override" {
		t.Errorf("expected custom description, got %q", p.Description)
	}
}

func TestLoader_All(t *testing.T) {
	l := profile.NewLoader("")
	if err := l.Load(); err != nil {
		t.Fatalf("Load: %v", err)
	}
	all := l.All()
	if len(all) < 5 {
		t.Errorf("expected at least 5 profiles, got %d", len(all))
	}
	// Verify sorted by name
	for i := 1; i < len(all); i++ {
		if all[i].Name < all[i-1].Name {
			t.Errorf("profiles not sorted: %q before %q", all[i-1].Name, all[i].Name)
		}
	}
}

func TestLoader_GetMissing(t *testing.T) {
	l := profile.NewLoader("")
	if err := l.Load(); err != nil {
		t.Fatalf("Load: %v", err)
	}
	p := l.Get("nonexistent-profile-xyz")
	if p != nil {
		t.Errorf("expected nil for missing profile, got %+v", p)
	}
}

func TestLoader_ProfileDefaults(t *testing.T) {
	dir := t.TempDir()

	// Profile with minimal fields — defaults should be applied
	minimal := "name = \"minimal\"\ntools = [\"subfinder\"]\n"
	os.WriteFile(filepath.Join(dir, "minimal.toml"), []byte(minimal), 0o644)

	l := profile.NewLoader(dir)
	if err := l.Load(); err != nil {
		t.Fatalf("Load: %v", err)
	}

	p := l.Get("minimal")
	if p == nil {
		t.Fatal("minimal profile not found")
	}
	if p.MaxConcurrent == 0 {
		t.Error("MaxConcurrent should have a default value")
	}
	if p.RateLimit == 0 {
		t.Error("RateLimit should have a default value")
	}
	if p.Nuclei.Severity == "" {
		t.Error("Nuclei.Severity should have a default value")
	}
}

func TestProfile_StealthIsPassive(t *testing.T) {
	l := profile.NewLoader("")
	if err := l.Load(); err != nil {
		t.Fatalf("Load: %v", err)
	}
	stealth := l.Get("stealth")
	if stealth == nil {
		t.Fatal("stealth profile missing")
	}
	if stealth.RateLimit > 15 {
		t.Errorf("stealth profile rate_limit %d is too high (should be ≤15)", stealth.RateLimit)
	}
	if stealth.Conditions.ServiceBrute {
		t.Error("stealth profile must not enable service_brute")
	}
}
