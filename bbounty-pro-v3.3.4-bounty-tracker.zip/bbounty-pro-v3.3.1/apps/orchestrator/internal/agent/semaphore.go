package agent

import "context"

// Semaphore is a counting semaphore for goroutine concurrency control.
type Semaphore struct {
	ch chan struct{}
}

// NewSemaphore creates a semaphore allowing up to n concurrent acquisitions.
func NewSemaphore(n int) *Semaphore {
	return &Semaphore{ch: make(chan struct{}, n)}
}

// Acquire blocks until a slot is available or ctx is cancelled.
func (s *Semaphore) Acquire(ctx context.Context) error {
	select {
	case s.ch <- struct{}{}:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// Release frees one slot.
func (s *Semaphore) Release() { <-s.ch }

// TryAcquire acquires immediately; returns false if full.
func (s *Semaphore) TryAcquire() bool {
	select {
	case s.ch <- struct{}{}:
		return true
	default:
		return false
	}
}

// Available returns the number of free slots.
func (s *Semaphore) Available() int { return cap(s.ch) - len(s.ch) }
