package main

import (
	"os"
	"strconv"
	"strings"
)

// cgroupMemSoftLimit reads the container's cgroup v2 memory limit and returns
// `frac` of it as a byte count suitable for debug.SetMemoryLimit. Returns
// (0,false) when there is no enforced limit (bare metal, "max", or unreadable),
// in which case the caller should leave the Go default untouched.
//
// Rationale: the orchestrator runs with a hard cgroup memory limit (2G in
// docker-compose). Without a soft GC target, a burst of concurrent scans can
// push RSS into the hard limit and get the process OOM-killed. Setting the soft
// limit a little below the hard limit lets the GC reclaim aggressively first.
func cgroupMemSoftLimit(frac float64) (int64, bool) {
	// cgroup v2 unified hierarchy
	const path = "/sys/fs/cgroup/memory.max"
	data, err := os.ReadFile(path)
	if err != nil {
		return 0, false
	}
	s := strings.TrimSpace(string(data))
	if s == "" || s == "max" {
		return 0, false // no enforced limit
	}
	hard, err := strconv.ParseInt(s, 10, 64)
	if err != nil || hard <= 0 {
		return 0, false
	}
	soft := int64(float64(hard) * frac)
	// Guard against absurdly small values that would choke the runtime.
	const minReasonable = 64 << 20 // 64 MiB
	if soft < minReasonable {
		return 0, false
	}
	return soft, true
}
