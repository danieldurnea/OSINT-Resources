// Package metrics — Prometheus metrics endpoint.
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// - Provides counter/gauge primitives without external dependency
// - For production, replace with `prometheus/client_golang` for proper
//   histograms with quantile buckets and label cardinality protection
// - Metrics are global — no per-tenant isolation
// - No alert rules / Grafana dashboards included

package metrics

import (
	"fmt"
	"net/http"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
)

// Counter is a monotonically increasing metric.
type Counter struct {
	name   string
	help   string
	labels []string
	values sync.Map // labelKey → *int64
}

func NewCounter(name, help string, labels ...string) *Counter {
	c := &Counter{name: name, help: help, labels: labels}
	registry.register(c)
	return c
}

func (c *Counter) Inc(labelValues ...string) { c.Add(1, labelValues...) }

func (c *Counter) Add(n int64, labelValues ...string) {
	key := labelKey(labelValues)
	v, _ := c.values.LoadOrStore(key, new(int64))
	atomic.AddInt64(v.(*int64), n)
}

// Gauge is a metric that can go up or down.
type Gauge struct {
	name   string
	help   string
	labels []string
	values sync.Map
}

func NewGauge(name, help string, labels ...string) *Gauge {
	g := &Gauge{name: name, help: help, labels: labels}
	registry.register(g)
	return g
}

func (g *Gauge) Set(value float64, labelValues ...string) {
	bits := uint64(value * 1000) // 3 decimal precision
	key := labelKey(labelValues)
	g.values.Store(key, bits)
}

func (g *Gauge) Inc(labelValues ...string) {
	key := labelKey(labelValues)
	for {
		current, _ := g.values.LoadOrStore(key, uint64(0))
		curBits := current.(uint64)
		newBits := curBits + 1000
		if g.values.CompareAndSwap(key, curBits, newBits) {
			return
		}
	}
}

func (g *Gauge) Dec(labelValues ...string) {
	key := labelKey(labelValues)
	for {
		current, _ := g.values.LoadOrStore(key, uint64(0))
		curBits := current.(uint64)
		var newBits uint64
		if curBits >= 1000 {
			newBits = curBits - 1000
		}
		if g.values.CompareAndSwap(key, curBits, newBits) {
			return
		}
	}
}

func labelKey(values []string) string {
	if len(values) == 0 {
		return ""
	}
	return strings.Join(values, "|")
}

// ── Registry ──────────────────────────────────────────────────────────────────

type metricEmitter interface {
	emit() string
}

type Registry struct {
	mu      sync.RWMutex
	metrics []metricEmitter
}

var registry = &Registry{}

func (r *Registry) register(m metricEmitter) {
	r.mu.Lock()
	r.metrics = append(r.metrics, m)
	r.mu.Unlock()
}

// Counter emit
func (c *Counter) emit() string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("# HELP %s %s\n", c.name, c.help))
	sb.WriteString(fmt.Sprintf("# TYPE %s counter\n", c.name))

	keys := []string{}
	c.values.Range(func(k, v any) bool {
		keys = append(keys, k.(string))
		return true
	})
	sort.Strings(keys)

	for _, k := range keys {
		v, _ := c.values.Load(k)
		count := atomic.LoadInt64(v.(*int64))
		sb.WriteString(fmt.Sprintf("%s%s %d\n", c.name, formatLabels(c.labels, k), count))
	}
	return sb.String()
}

func (g *Gauge) emit() string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("# HELP %s %s\n", g.name, g.help))
	sb.WriteString(fmt.Sprintf("# TYPE %s gauge\n", g.name))

	keys := []string{}
	g.values.Range(func(k, v any) bool {
		keys = append(keys, k.(string))
		return true
	})
	sort.Strings(keys)

	for _, k := range keys {
		v, _ := g.values.Load(k)
		bits := v.(uint64)
		sb.WriteString(fmt.Sprintf("%s%s %.3f\n",
			g.name, formatLabels(g.labels, k), float64(bits)/1000))
	}
	return sb.String()
}

func formatLabels(names []string, key string) string {
	if key == "" || len(names) == 0 {
		return ""
	}
	values := strings.Split(key, "|")
	parts := []string{}
	for i, n := range names {
		if i < len(values) {
			parts = append(parts, fmt.Sprintf(`%s=%q`, n, values[i]))
		}
	}
	return "{" + strings.Join(parts, ",") + "}"
}

// HandleMetrics exposes /metrics in Prometheus exposition format.
func HandleMetrics(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "text/plain; version=0.0.4")
	registry.mu.RLock()
	defer registry.mu.RUnlock()
	for _, m := range registry.metrics {
		fmt.Fprint(w, m.emit())
	}
}

// ── Pre-defined metrics ──────────────────────────────────────────────────────

var (
	ScansTotal    = NewCounter("bbounty_scans_total", "Total scans started", "status")
	ScansActive   = NewGauge("bbounty_scans_active", "Currently running scans")
	FindingsTotal = NewCounter("bbounty_findings_total", "Total findings", "severity")
	RateLimitHits = NewCounter("bbounty_rate_limit_429_total", "Total 429 responses", "target")
	ToolDuration  = NewCounter("bbounty_tool_duration_seconds", "Tool execution time", "tool", "status")
	AuthAttempts  = NewCounter("bbounty_auth_attempts_total", "Auth attempts", "result")
	APIRequests   = NewCounter("bbounty_api_requests_total", "API requests", "method", "status")
	WSConnections = NewGauge("bbounty_ws_connections", "Active WebSocket connections")
)

// HTTPMiddleware records per-request metrics (method + status code).
func HTTPMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ww := &statusWriter{ResponseWriter: w, code: http.StatusOK}
		next.ServeHTTP(ww, r)
		APIRequests.Inc(r.Method, fmt.Sprintf("%d", ww.code))
	})
}

type statusWriter struct {
	http.ResponseWriter
	code int
}

func (sw *statusWriter) WriteHeader(code int) {
	sw.code = code
	sw.ResponseWriter.WriteHeader(code)
}
