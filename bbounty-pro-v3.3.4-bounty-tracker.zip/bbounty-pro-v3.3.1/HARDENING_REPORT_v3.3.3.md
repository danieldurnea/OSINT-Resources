# BBounty Pro v3.3.3 — Docker / Redis / PostgreSQL Hardening Report

**Date:** 2026-05-29
**Base:** v3.3.2-AUDITED (all tests green)
**Scope touched:** `infra/docker-compose.yml`, `infra/docker-compose.dev.yml`,
`infra/redis/redis.conf`, `apps/orchestrator/Dockerfile`, `apps/ai-proxy/Dockerfile`.
**Untouched:** all Go/Python application code, `platform/`, `apps/web/` source,
Vigolium attribution, aiguard/canary.
**Sources:** OWASP Docker Cheat Sheet, CIS PostgreSQL Benchmark, and 2025–2026
hardening guides (Aikido, Whitespots, Virtua.cloud, oneuptime, SOCFortress).

---

## 0. Method & verification environment

No Docker daemon is available in this environment and Docker Hub is blocked, so
`docker compose up` could not be run here. Instead, every change was validated by:

- **Full YAML + Compose-schema validation** with a Python checker (parses both
  compose files, asserts every new key — `tmpfs` option syntax, `cap_drop`/`cap_add`,
  `ulimits`, `pids_limit`, `internal` networks — is well-formed, and that the
  network topology is internally consistent).
- **Re-running the entire v3.3.2 test battery** against a real Go toolchain to
  prove no application code regressed (none was touched).

The real `docker compose up` smoke-boot is an **operator step on the VPS** before
deploy — called out explicitly in §4.

### Verification results — all green

| Check | Result |
|---|---|
| `docker compose config` equivalent (pyyaml schema validation, both files) | ✅ pass |
| `go vet ./...` | ✅ |
| `go build ./...` | ✅ |
| `go test ./...` | ✅ all pass |
| `go test -race ./...` | ✅ 0 races, 8 pkgs |
| `go test -tags integration ./...` | ✅ |
| `gofmt -l` | ✅ clean |
| `py_compile` (ai-proxy + ultra_agent) | ✅ |
| `pytest tests/ -q` | ✅ 48 passed |
| `bash -n scripts/*.sh` | ✅ all 19 |

`go.mod`/`go.sum` ship pristine at `go 1.26` with original sums (the directive was
only temporarily lowered for the apt-Go verification build, then restored).

---

## 1. What was applied

### T8 — Removed obsolete `version:` + added `ulimits` · ✅
Dropped the deprecated `version: "3.9"` key from both compose files (ignored by
Compose v2, emits a warning). Added `ulimits.nofile 65535/65535` on the
orchestrator (high socket fan-out during scans).

### T9 — Dockerfile version sync + ai-proxy hardening · ✅
- **Orchestrator Dockerfile:** bumped `golang:1.23-alpine` → `golang:1.26-alpine`
  to match `go.mod`'s `go 1.26`. Building with a 1.23 toolchain against a module
  that declares 1.26 would fail or silently differ — this was a latent
  inconsistency carried since v3.3.2.
- **ai-proxy Dockerfile:** added `PYTHONDONTWRITEBYTECODE=1` / `PYTHONUNBUFFERED=1`.
  The first is **required** for the read-only rootfs (T2) — otherwise Python would
  try to write `.pyc` files onto the now-immutable filesystem.
- Digest pinning (`@sha256:`) left as a documented TODO (can't resolve a digest
  without pulling; Docker Hub is blocked here).

### T3 — `pids_limit` on every service · ✅
Anti fork-bomb DoS. orchestrator/web/postgres = 256, ai-proxy/redis = 128.

### T1 — `no-new-privileges` + `cap_drop: ALL` on every service · ✅
- orchestrator/ai-proxy/web/redis: `cap_drop: [ALL]`, no `cap_add` (they bind
  ports >1024 → don't need `NET_BIND_SERVICE`, and need no other capability).
- **postgres:** `cap_drop: [ALL]` + a **scoped** `cap_add` of `CHOWN`,
  `DAC_OVERRIDE`, `FOWNER`, `SETUID`, `SETGID` — the minimum `initdb` needs to
  chown the data dir and drop from root to the postgres user on first boot.
  (Verify on the boot smoke-test; if init still complains, these are exactly the
  caps to keep.)

### T2 — `read_only` rootfs + `tmpfs` · ✅ (postgres excluded by design)
`read_only: true` on orchestrator, ai-proxy, web, redis, each with a
`/tmp:rw,noexec,nosuid` tmpfs (sized per service). `noexec` means a dropped tool
output or payload under `/tmp` cannot be executed; `nosuid` blocks setuid tricks.
- **orchestrator:** `/tmp` tmpfs covers `secureOutputDir()`'s `os.TempDir()`
  fallback; the `scan-results` named volume stays writable.
- **web:** added a second tmpfs `/app/.next/cache` because Next.js may write
  incremental cache at runtime (documented; switch to a named volume if it must
  persist).
- **postgres:** deliberately **not** `read_only` — initdb and the server write to
  several paths beyond the data volume. It gets `tmpfs` for `/tmp` and the unix
  socket dir `/run/postgresql`, plus cap_drop + no-new-privileges + pids_limit.
  (This was the "ask first" item; I chose the safe option — the task itself flags
  postgres read-only as the most fragile.)

### T4 — Redis 7 hardening flags · ✅ (ACL deferred)
Added to `redis.conf`: `enable-protected-configs no`, `enable-debug-command no`,
`enable-module-command no` — gates the dangerous runtime surfaces Redis 7 exposes
(runtime CONFIG of security params, DEBUG crash primitives, MODULE native-code
loading). **ACL (dedicated least-privilege user) deferred** — it requires mapping
every key prefix the platform uses, and a wrong `~pattern` or `user default off`
would lock the app out. Recommended as a follow-up once prefixes are enumerated.

### T5 — Redis `bind` latent-bug fix · ✅
`redis.conf` had `bind 127.0.0.1 ::1`, which accepts only the container's own
loopback — it would **reject** the orchestrator connecting via the Docker DNS name
`redis:6379`. Changed to `bind 0.0.0.0 -::*`. This is safe because the port is
never published to the host and (T6) redis now sits on an `internal: true`
network — isolation is enforced at the network layer. A comment notes bare-metal
installs should override back to a private/LAN IP. **Test on the boot smoke-test:
confirm orchestrator connects with no "connection refused".**

### T6 — Network segmentation (`internal: true` backend) · ✅
Split the single `bbounty` bridge into:
- `frontend` (bridge, egress allowed): orchestrator, ai-proxy, web.
- `backend` (bridge, **`internal: true`** — no internet/host route): redis,
  postgres, and orchestrator (which needs DB access).

Connectivity was mapped before assigning: ai-proxy only needs Anthropic egress
(no redis) → frontend only; web only talks to orchestrator → frontend; orchestrator
needs egress *and* the datastores → both networks (Docker routes its egress via
the non-internal `frontend`). Datastores are now unreachable from the internet and
from any container not explicitly on `backend`.

### T7 — PostgreSQL SCRAM + timeouts · ✅ (+ fixed a real bug)
Added to the postgres `command`: `password_encryption=scram-sha-256`,
`statement_timeout=60000`, `idle_in_transaction_session_timeout=60000`,
`log_min_error_statement=error`; and `POSTGRES_INITDB_ARGS` forcing
`--auth-host=scram-sha-256 --auth-local=scram-sha-256` at initdb (CIS Benchmark).
**Bug fixed as a side effect:** the original `command:` had two `#` comment lines
*inside* the YAML folded scalar (`>`), which Compose would have passed verbatim to
the postgres binary as bogus arguments — breaking startup. Those are now real
comments outside the scalar. `DATABASE_URL` is empty by default (Redis-only), so
this only affects deployments that actually enable Postgres; `statement_timeout`
(60s) is well above what `postgres_sync.go` needs.

### T10 — dev compose Redis on loopback · ✅
`6379:6379` → `127.0.0.1:6379:6379`, and the redis-commander dev UI `8081:8081`
→ `127.0.0.1:8081:8081`, so a dev stack on a VPS doesn't expose Redis or its
contents to the world. Also synced the dev orchestrator image to `golang:1.26`.

---

## 2. Decisions made (the 5 "ask first" items)

You uploaded the task and said to execute, so I took the **safest defensible**
option for each, matching the task's own recommendations:

1. **T2 postgres read_only:** NOT applied (cap_drop + nnp + tmpfs only) — postgres
   is the most fragile under read-only.
2. **T4 Redis ACL:** flags only; ACL deferred (needs key-prefix mapping).
3. **T5 Redis bind:** fixed to `0.0.0.0 -::*`, relying on network-layer isolation.
4. **T6 segmentation:** applied (`backend` internal).
5. **T9 digest pin:** synced Go version; digest pin left as documented TODO.

All are reversible.

---

## 3. Operator action required before deploy (important)

These cannot be verified without a live Docker daemon — run on the VPS:

1. **Boot smoke-test:** `docker compose -f infra/docker-compose.yml up -d`, then
   `docker compose ps` — confirm every service reaches `healthy`. Check
   `docker compose logs orchestrator` for redis connectivity (no "connection
   refused"), which validates T5 + T6.
2. **nginx network:** nginx is referenced in comments (proxies to `orchestrator:8080`
   and `web:3000`) but is **not** a service in either compose file — it runs
   externally. With T6, nginx must attach to the **`frontend`** network to reach
   orchestrator and web. Update the external nginx run/compose accordingly.
3. **postgres caps:** if `initdb` fails on first boot, the scoped `cap_add`
   (CHOWN/DAC_OVERRIDE/FOWNER/SETUID/SETGID) is already in place; if it still
   complains, the logs will name the missing cap.
4. **web read_only:** if Next.js fails to start under read-only, the `/app/.next/cache`
   tmpfs should cover it; if not, switch that path to a named volume.

---

## 4. Out of scope (unchanged)

Rootless Docker / userns-remap (host changes), custom seccomp/AppArmor profiles,
real TLS with certificates (Redis tls-port, Postgres ssl=on/hostssl — left as
documented hooks), application code in `platform/` & `apps/web/`, external secrets
management (Vault).

---

*Generated 2026-05-29. All validation green; live boot is an operator step.*
