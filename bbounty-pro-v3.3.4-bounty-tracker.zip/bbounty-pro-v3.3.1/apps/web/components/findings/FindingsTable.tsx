"use client";

import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Bot, ExternalLink, ChevronDown, Trash2, Filter } from "lucide-react";
import useSWR from "swr";

interface Finding {
  id: string;
  title: string;
  url: string;
  severity: "critical" | "high" | "medium" | "low" | "info";
  category: string;
  parameter?: string;
  status: "new" | "confirmed" | "duplicate" | "invalid" | "resolved";
  cvss?: number;
  created_at: string;
  source: string; // tool that found it or "manual"
  ai_analysis?: string;
}

const SEVERITY_META = {
  critical: { color: "#ff3a5c", bg: "#1f0a0e", score: "9.0-10" },
  high:     { color: "#ff9b3a", bg: "#1f150a", score: "7.0-8.9" },
  medium:   { color: "#ffcc3a", bg: "#1f1b0a", score: "4.0-6.9" },
  low:      { color: "#7c6aff", bg: "#120e1f", score: "0.1-3.9" },
  info:     { color: "#4a8a9a", bg: "#0a131f", score: "0" },
} as const;

const STATUS_META = {
  new:       { color: "#00e5cc", label: "New" },
  confirmed: { color: "#54b35f", label: "Confirmed" },
  duplicate: { color: "#4a6a7a", label: "Duplicate" },
  invalid:   { color: "#4a3a3a", label: "Invalid" },
  resolved:  { color: "#2a5a6a", label: "Resolved" },
};

const EMPTY_FINDING: Omit<Finding, "id" | "created_at" | "source"> = {
  title: "",
  url: "",
  severity: "medium",
  category: "",
  parameter: "",
  status: "new",
};

const fetcher = (url: string) => fetch(url).then(r => r.json());

interface Props { scanID: string | null }

export function FindingsTable({ scanID }: Props) {
  const { data: findings = [], mutate } = useSWR<Finding[]>(
    scanID ? `/api/v1/findings/${scanID}` : null,
    fetcher,
    { refreshInterval: 5000 }
  );

  const [filter, setFilter] = useState("");
  const [sevFilter, setSevFilter] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newFinding, setNewFinding] = useState({ ...EMPTY_FINDING });
  const [analyzing, setAnalyzing] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const filtered = useMemo(() => {
    return findings.filter(f => {
      const q = filter.toLowerCase();
      const matchText =
        !q ||
        f.title.toLowerCase().includes(q) ||
        f.url.toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q);
      const matchSev = !sevFilter || f.severity === sevFilter;
      return matchText && matchSev;
    });
  }, [findings, filter, sevFilter]);

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const f of findings) c[f.severity] = (c[f.severity] || 0) + 1;
    return c;
  }, [findings]);

  const addFinding = async () => {
    if (!newFinding.title || !newFinding.url) return;
    setAdding(true);
    await fetch("/api/v1/findings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...newFinding, scan_id: scanID, source: "manual" }),
    });
    await mutate();
    setNewFinding({ ...EMPTY_FINDING });
    setShowAdd(false);
    setAdding(false);
  };

  const deleteFinding = async (id: string) => {
    await fetch(`/api/v1/findings/${id}`, { method: "DELETE" });
    await mutate();
  };

  const analyzeFinding = async (finding: Finding) => {
    setAnalyzing(finding.id);
    try {
      const res = await fetch(`/api/v1/findings/${finding.id}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ finding }),
      });
      const json = await res.json();
      // Update finding with AI analysis
      await fetch(`/api/v1/findings/${finding.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ai_analysis: json.analysis }),
      });
      await mutate();
      setExpandedId(finding.id);
    } finally {
      setAnalyzing(null);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Severity summary */}
      <div className="flex items-center gap-2 px-4 py-2 border-b border-[#1a2a32] bg-[#0a1015]">
        {Object.entries(SEVERITY_META).map(([sev, { color }]) => (
          <button
            key={sev}
            onClick={() => setSevFilter(sevFilter === sev ? null : sev)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border transition-all",
              sevFilter === sev
                ? "border-current bg-current/15"
                : "border-[#1a2a32] text-[#2a4a5a] hover:border-[#2a4a5a]"
            )}
            style={{ color: sevFilter === sev ? color : undefined }}
          >
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
            {sev.toUpperCase()}
            <span className="ml-0.5">{counts[sev] || 0}</span>
          </button>
        ))}

        {/* Inline add + search */}
        <div className="flex items-center gap-2 ml-auto">
          <div className="relative">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#2a5a6a]" />
            <input
              value={filter}
              onChange={e => setFilter(e.target.value)}
              placeholder="Filter findings..."
              className="pl-7 pr-3 py-1.5 bg-[#080c0e] border border-[#1a2a32] rounded-lg text-xs text-[#c8d8e0] placeholder-[#2a4a5a] focus:outline-none focus:border-[#00e5cc]/30 w-44"
            />
          </div>
          <button
            onClick={() => setShowAdd(!showAdd)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-all",
              showAdd
                ? "border-[#00e5cc]/40 text-[#00e5cc] bg-[#00e5cc]/10"
                : "border-[#1a2a32] text-[#4a6a7a] hover:border-[#2a4a5a] hover:text-[#8ab4c4]"
            )}
          >
            <Plus size={12} /> ADD FINDING
          </button>
        </div>
      </div>

      {/* Inline add form */}
      {showAdd && (
        <div className="border-b border-[#00e5cc]/20 bg-[#0a1f19]/50 px-4 py-3">
          <div className="grid grid-cols-12 gap-2 items-start">
            <input
              value={newFinding.title}
              onChange={e => setNewFinding(p => ({ ...p, title: e.target.value }))}
              placeholder="Finding title *"
              className={cn(inputCls, "col-span-3")}
            />
            <input
              value={newFinding.url}
              onChange={e => setNewFinding(p => ({ ...p, url: e.target.value }))}
              placeholder="URL *"
              className={cn(inputCls, "col-span-3")}
            />
            <input
              value={newFinding.category}
              onChange={e => setNewFinding(p => ({ ...p, category: e.target.value }))}
              placeholder="Category (XSS, SQLi...)"
              className={cn(inputCls, "col-span-2")}
            />
            <select
              value={newFinding.severity}
              onChange={e => setNewFinding(p => ({ ...p, severity: e.target.value as any }))}
              className={cn(inputCls, "col-span-1")}
            >
              {Object.keys(SEVERITY_META).map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <input
              value={newFinding.parameter}
              onChange={e => setNewFinding(p => ({ ...p, parameter: e.target.value }))}
              placeholder="Parameter"
              className={cn(inputCls, "col-span-2")}
            />
            <button
              onClick={addFinding}
              disabled={!newFinding.title || !newFinding.url || adding}
              className="col-span-1 py-2 rounded-lg bg-[#00e5cc] text-[#080c0e] text-xs font-bold disabled:opacity-40 hover:bg-[#20ffec] transition-colors"
            >
              {adding ? "..." : "Add"}
            </button>
          </div>
        </div>
      )}

      {/* Findings list */}
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-16">
            <div className="text-[#1a2a32] text-5xl mb-4">◎</div>
            <div className="text-[#2a4a5a] text-sm font-semibold">No findings yet</div>
            <div className="text-[#1a2a32] text-xs mt-1">
              {scanID ? "Scan in progress — findings will appear here" : "Start a scan to discover vulnerabilities"}
            </div>
          </div>
        ) : (
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-[#080c0e] border-b border-[#1a2a32]">
              <tr className="text-[10px] text-[#2a5a6a] tracking-widest">
                <th className="text-left px-4 py-2 font-semibold">SEVERITY</th>
                <th className="text-left px-4 py-2 font-semibold">TITLE</th>
                <th className="text-left px-4 py-2 font-semibold">URL</th>
                <th className="text-left px-4 py-2 font-semibold">CATEGORY</th>
                <th className="text-left px-4 py-2 font-semibold">STATUS</th>
                <th className="text-left px-4 py-2 font-semibold">CVSS</th>
                <th className="text-left px-4 py-2 font-semibold">SOURCE</th>
                <th className="text-right px-4 py-2 font-semibold">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#0f1e28]">
              {filtered.map(finding => {
                const sev = SEVERITY_META[finding.severity];
                const status = STATUS_META[finding.status];
                const isExpanded = expandedId === finding.id;

                return (
                  <>
                    <tr
                      key={finding.id}
                      className={cn(
                        "transition-colors duration-100 cursor-pointer",
                        "hover:bg-[#0a1820]",
                        isExpanded && "bg-[#0a1820]"
                      )}
                      onClick={() => setExpandedId(isExpanded ? null : finding.id)}
                    >
                      {/* Severity */}
                      <td className="px-4 py-3">
                        <span
                          className="inline-flex items-center gap-1.5 px-2 py-1 rounded font-bold text-[10px] border"
                          style={{
                            color: sev.color,
                            background: sev.bg,
                            borderColor: sev.color + "30",
                          }}
                        >
                          <span className="w-1.5 h-1.5 rounded-full" style={{ background: sev.color }} />
                          {finding.severity.toUpperCase()}
                        </span>
                      </td>

                      {/* Title */}
                      <td className="px-4 py-3 text-[#c8d8e0] font-semibold max-w-xs">
                        <div className="flex items-center gap-2">
                          <ChevronDown
                            size={12}
                            className={cn(
                              "text-[#2a5a6a] flex-shrink-0 transition-transform",
                              isExpanded && "rotate-180"
                            )}
                          />
                          <span className="truncate">{finding.title}</span>
                        </div>
                      </td>

                      {/* URL */}
                      <td className="px-4 py-3 text-[#2a7a9a] font-mono max-w-[200px]">
                        <div className="truncate" title={finding.url}>{finding.url}</div>
                      </td>

                      {/* Category */}
                      <td className="px-4 py-3 text-[#4a6a7a]">{finding.category}</td>

                      {/* Status */}
                      <td className="px-4 py-3">
                        <span className="text-[10px] font-semibold" style={{ color: status.color }}>
                          {status.label}
                        </span>
                      </td>

                      {/* CVSS */}
                      <td className="px-4 py-3 text-[#4a6a7a] tabular-nums">
                        {finding.cvss != null ? (
                          <span style={{ color: finding.cvss >= 7 ? sev.color : undefined }}>
                            {finding.cvss.toFixed(1)}
                          </span>
                        ) : "—"}
                      </td>

                      {/* Source */}
                      <td className="px-4 py-3">
                        <span className="text-[10px] text-[#2a5a6a] font-mono">{finding.source}</span>
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3 text-right" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => analyzeFinding(finding)}
                            disabled={analyzing === finding.id}
                            className={cn(
                              "flex items-center gap-1 px-2 py-1 rounded text-[10px] border transition-all",
                              "border-[#1a3a4a] text-[#2a7a9a] hover:border-[#7c6aff]/40 hover:text-[#7c6aff]",
                              analyzing === finding.id && "opacity-50"
                            )}
                            title="AI Analysis: CVSS + Report"
                          >
                            <Bot size={10} />
                            {analyzing === finding.id ? "..." : "AI"}
                          </button>
                          <a
                            href={finding.url?.startsWith("http") ? finding.url : "#"}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1 text-[#2a5a6a] hover:text-[#4a8a9a] transition-colors"
                          >
                            <ExternalLink size={12} />
                          </a>
                          <button
                            onClick={() => deleteFinding(finding.id)}
                            className="p-1 text-[#2a5a6a] hover:text-[#ff3a5c] transition-colors"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </td>
                    </tr>

                    {/* Expanded AI analysis row */}
                    {isExpanded && finding.ai_analysis && (
                      <tr key={`${finding.id}-expanded`} className="bg-[#0a1820]">
                        <td colSpan={8} className="px-12 py-4">
                          <div className="border border-[#7c6aff]/20 rounded-lg p-4 bg-[#0f0e1f]">
                            <div className="flex items-center gap-2 mb-3">
                              <Bot size={13} className="text-[#7c6aff]" />
                              <span className="text-[10px] font-bold text-[#7c6aff] tracking-widest">
                                AI ANALYSIS
                              </span>
                            </div>
                            <pre className="text-xs text-[#8ab4c4] whitespace-pre-wrap font-mono leading-relaxed">
                              {finding.ai_analysis}
                            </pre>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

const inputCls =
  "w-full bg-[#080c0e] border border-[#00e5cc]/20 rounded-lg px-3 py-2 text-xs text-[#c8d8e0] " +
  "placeholder-[#2a4a5a] font-mono focus:outline-none focus:border-[#00e5cc]/40 transition-colors";
