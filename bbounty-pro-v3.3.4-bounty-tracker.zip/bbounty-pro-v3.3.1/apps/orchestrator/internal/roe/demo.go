package roe

import (
	"os"
	"strings"
)

// demo.go — DEMO MODE support (v3.3.4).
//
// This file exists ONLY to support the self-contained demo/test build used for
// videos and promotion. It is fully gated behind the DEMO_MODE env var: when
// unset (the default, i.e. every real deployment) none of this code changes any
// behaviour. In demo mode, the ROE gate is replaced by a hard allowlist of the
// public, intentionally-vulnerable test targets so the demo can run without any
// scope/ROE setup yet still cannot be aimed at a real host.

// isDemoMode reports whether the platform is running as a demo build.
func isDemoMode() bool {
	v := strings.ToLower(strings.TrimSpace(os.Getenv("DEMO_MODE")))
	return v == "1" || v == "true" || v == "yes"
}

// demoAllowedHosts is the fixed allowlist for demo mode: Acunetix's public
// vulnweb test sites, which are explicitly published for testing security tools
// and are legal to scan. Nothing else is permitted, even in demo mode.
var demoAllowedHosts = []string{
	"testphp.vulnweb.com",
	"testasp.vulnweb.com",
	"testaspnet.vulnweb.com",
	"testhtml5.vulnweb.com",
	"rest.vulnweb.com",
	"vulnweb.com",
}

// isDemoAllowedHost returns true if host is (or is a subdomain of) a permitted
// demo test target.
func isDemoAllowedHost(host string) bool {
	host = strings.ToLower(strings.TrimSpace(host))
	host = strings.TrimSuffix(host, ".")
	for _, allowed := range demoAllowedHosts {
		if host == allowed || strings.HasSuffix(host, "."+allowed) {
			return true
		}
	}
	return false
}
