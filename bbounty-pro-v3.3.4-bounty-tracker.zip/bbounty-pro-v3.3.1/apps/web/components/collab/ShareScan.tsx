"use client";

import { useState } from "react";
import useSWR from "swr";
import { Users, UserPlus, X } from "lucide-react";
import { collabAPI } from "@/lib/api-client";

// Compact, embeddable share panel for a single scan. Drop it on a scan/findings
// page: <ShareScan scanID={id} />
export default function ShareScan({ scanID }: { scanID: string }) {
  const { data, mutate } = useSWR<{ members: string[] }>(
    scanID ? `collab-members-${scanID}` : null,
    () => collabAPI.members(scanID) as Promise<{ members: string[] }>,
    { revalidateOnFocus: true }
  );
  const [username, setUsername] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  async function share() {
    if (!username) return;
    setBusy(true);
    setMsg("");
    try {
      await collabAPI.share(scanID, username);
      setUsername("");
      setMsg(`Shared with ${username}`);
      mutate();
    } catch {
      setMsg("Could not share — check the username.");
    } finally {
      setBusy(false);
    }
  }

  async function revoke(userID: string) {
    await collabAPI.revoke(scanID, userID);
    mutate();
  }

  const members = data?.members || [];

  return (
    <div className="font-mono border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 space-y-3">
      <h3 className="text-xs uppercase tracking-widest text-[#8aa0aa] flex items-center gap-2">
        <Users size={14} /> Share this scan
      </h3>

      <div className="flex gap-2">
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && share()}
          placeholder="teammate username"
          className="flex-1 bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs
                     text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none"
        />
        <button
          onClick={share}
          disabled={busy || !username}
          className="px-3 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                     text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors
                     flex items-center gap-1"
        >
          <UserPlus size={13} /> Share
        </button>
      </div>

      {msg && <p className="text-[11px] text-[#7fffd6]">{msg}</p>}

      {members.length > 0 ? (
        <ul className="space-y-1 pt-1">
          {members.map((m) => (
            <li
              key={m}
              className="flex items-center justify-between text-xs text-[#c8d8e0]
                         border-t border-[#141f23] pt-1.5"
            >
              <span>{m}</span>
              <button
                onClick={() => revoke(m)}
                className="text-[#5a6b72] hover:text-[#ff5c7a] transition-colors"
                aria-label="revoke"
              >
                <X size={13} />
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-[11px] text-[#5a6b72]">Not shared with anyone yet.</p>
      )}
    </div>
  );
}
