"""Scope D tests — AI proxy + frontend fixes."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import pytest


class TestAIProxySystemPrompt:
    def test_chat_request_no_system_field(self):
        """Fix 1: ChatRequest must not have a user-controllable system field."""
        # Verify the system field was removed from ChatRequest
        src = open(os.path.join(
            os.path.dirname(__file__),
            '../../ai-proxy/main.py'
        )).read()

        # system field removed from ChatRequest class body
        import re
        # Find ChatRequest class definition
        chat_req = re.search(
            r'class ChatRequest\(BaseModel\):(.*?)(?=^class|\Z)',
            src, re.MULTILINE | re.DOTALL
        )
        assert chat_req, "ChatRequest class not found"
        body = chat_req.group(1)
        # system: str should NOT be in ChatRequest
        assert 'system:' not in body, \
            "ChatRequest must not have system field — prompt injection risk"

    def test_health_no_version_exposed(self):
        """Fix 3: /health must not expose version or framework name."""
        src = open(os.path.join(
            os.path.dirname(__file__), '../../ai-proxy/main.py'
        )).read()
        import re
        health_fn = re.search(
            r'async def health\(request.*?\n(?:    .*\n)*',
            src
        )
        assert health_fn, "health function not found"
        body = health_fn.group(0)
        assert '"version"' not in body, \
            "/health must not expose version string"
        assert 'BountyHunter' not in body, \
            "/health must not expose framework branding"

    def test_trusted_ip_function_exists(self):
        """Fix 2: get_trusted_ip must exist and use X-Real-IP."""
        src = open(os.path.join(
            os.path.dirname(__file__), '../../ai-proxy/main.py'
        )).read()
        assert 'def get_trusted_ip' in src, \
            "get_trusted_ip function must exist"
        assert 'X-Real-IP' in src, \
            "get_trusted_ip must read X-Real-IP header"
        # Should NOT trust X-Forwarded-For as primary source
        assert 'key_func=get_trusted_ip' in src, \
            "limiter must use get_trusted_ip, not get_remote_address"


class TestFrontendSecurity:
    def test_finding_url_sanitized(self):
        """Fix 5: finding.url href must only allow http/https."""
        src = open(os.path.join(
            os.path.dirname(__file__),
            '../../web/components/findings/FindingsTable.tsx'
        )).read()
        # Should have URL sanitization
        assert 'startsWith' in src and 'http' in src, \
            "finding.url must be sanitized before use in href"

    def test_aiagent_has_msgs_ref(self):
        """Fix 4: AIAgent must use msgsRef to avoid stale closure."""
        src = open(os.path.join(
            os.path.dirname(__file__),
            '../../web/components/agent/AIAgent.tsx'
        )).read()
        assert 'msgsRef' in src, \
            "AIAgent must use msgsRef.current to avoid stale closure"
        assert 'isMounted' in src, \
            "AIAgent must have isMounted guard against state updates after unmount"
        assert 'msgsRef.current' in src, \
            "ask() must use msgsRef.current not stale msgs closure"
