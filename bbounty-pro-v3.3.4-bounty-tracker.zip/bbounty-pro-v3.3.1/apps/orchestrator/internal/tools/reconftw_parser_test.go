package tools

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestParseReconFTWOutput_SubdomainsAndHosts(t *testing.T) {
	dir := t.TempDir()

	// Create reconFTW directory structure
	os.MkdirAll(filepath.Join(dir, "subdomains"), 0o755)
	os.MkdirAll(filepath.Join(dir, "webs"), 0o755)
	os.MkdirAll(filepath.Join(dir, "report"), 0o755)
	os.MkdirAll(filepath.Join(dir, "vulns"), 0o755)

	// Write subdomains
	os.WriteFile(filepath.Join(dir, "subdomains", "subdomains.txt"), []byte(
		"api.target.com\nadmin.target.com\nstaging.target.com\n",
	), 0o644)

	// Write webs
	os.WriteFile(filepath.Join(dir, "webs", "webs.txt"), []byte(
		"https://api.target.com\nhttps://admin.target.com\n",
	), 0o644)

	result, err := ParseReconFTWOutput("test-scan-id-12345678", dir)
	if err != nil {
		t.Fatalf("ParseReconFTWOutput: %v", err)
	}

	if len(result.Subdomains) != 3 {
		t.Errorf("expected 3 subdomains, got %d: %v", len(result.Subdomains), result.Subdomains)
	}
	if len(result.LiveHosts) != 2 {
		t.Errorf("expected 2 live hosts, got %d: %v", len(result.LiveHosts), result.LiveHosts)
	}
}

func TestParseReconFTWOutput_ReportJSON(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "report"), 0o755)
	os.MkdirAll(filepath.Join(dir, "subdomains"), 0o755)
	os.MkdirAll(filepath.Join(dir, "webs"), 0o755)
	os.MkdirAll(filepath.Join(dir, "vulns"), 0o755)

	report := map[string]any{
		"domain": "target.com",
		"vulns": []map[string]any{
			{
				"name":        "SQL Injection in /api/users",
				"url":         "https://target.com/api/users?id=1",
				"severity":    "high",
				"description": "Error-based SQLi confirmed",
				"tool":        "sqlmap",
				"cvss":        8.8,
			},
			{
				"name":     "XSS in /search parameter",
				"url":      "https://target.com/search?q=<script>",
				"severity": "medium",
				"tool":     "dalfox",
			},
		},
	}
	data, _ := json.Marshal(report)
	os.WriteFile(filepath.Join(dir, "report", "report.json"), data, 0o644)

	result, err := ParseReconFTWOutput("test-scan-id-12345678", dir)
	if err != nil {
		t.Fatalf("ParseReconFTWOutput: %v", err)
	}

	if len(result.Findings) != 2 {
		t.Fatalf("expected 2 findings, got %d", len(result.Findings))
	}

	f0 := result.Findings[0]
	if string(f0.Severity) != "high" {
		t.Errorf("expected high severity, got %s", f0.Severity)
	}
	if f0.Source != "reconftw:sqlmap" {
		t.Errorf("expected source reconftw:sqlmap, got %s", f0.Source)
	}
	if *f0.CVSS != 8.8 {
		t.Errorf("expected CVSS 8.8, got %v", *f0.CVSS)
	}
}

func TestParseReconFTWOutput_HotlistAssets(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "subdomains"), 0o755)
	os.MkdirAll(filepath.Join(dir, "webs"), 0o755)
	os.MkdirAll(filepath.Join(dir, "report"), 0o755)
	os.MkdirAll(filepath.Join(dir, "vulns"), 0o755)

	// Assets with high score should become findings
	assets := []map[string]any{
		{"url": "https://api.target.com", "score": 9.5, "tech": []string{"WordPress", "PHP"}},
		{"url": "https://staging.target.com", "score": 4.0, "tech": []string{"Nginx"}},
		{"url": "https://admin.target.com", "score": 8.0, "tech": []string{"Apache"}},
	}
	var lines []byte
	for _, a := range assets {
		b, _ := json.Marshal(a)
		lines = append(lines, b...)
		lines = append(lines, '\n')
	}
	os.WriteFile(filepath.Join(dir, "assets.jsonl"), lines, 0o644)

	result, err := ParseReconFTWOutput("test-scan-id-12345678", dir)
	if err != nil {
		t.Fatalf("ParseReconFTWOutput: %v", err)
	}

	// Only assets with score ≥ 8 should become findings (2 out of 3)
	hotlistFindings := 0
	for _, f := range result.Findings {
		for _, tag := range f.Tags {
			if tag == "hotlist" {
				hotlistFindings++
				break
			}
		}
	}
	if hotlistFindings != 2 {
		t.Errorf("expected 2 hotlist findings (score≥8), got %d", hotlistFindings)
	}
}

func TestParseReconFTWOutput_NucleiVulns(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "subdomains"), 0o755)
	os.MkdirAll(filepath.Join(dir, "webs"), 0o755)
	os.MkdirAll(filepath.Join(dir, "report"), 0o755)
	os.MkdirAll(filepath.Join(dir, "vulns"), 0o755)

	// Write nuclei JSONL output in vulns/
	nucleiLine := map[string]any{
		"template-id": "apache-log4j-rce",
		"info": map[string]any{
			"name":     "Apache Log4j RCE",
			"severity": "critical",
			"tags":     []string{"cve", "rce", "log4j"},
		},
		"matched-at": "https://api.target.com/api/v1/user",
	}
	data, _ := json.Marshal(nucleiLine)
	os.WriteFile(filepath.Join(dir, "vulns", "critical.json"), data, 0o644)

	result, err := ParseReconFTWOutput("test-scan-id-12345678", dir)
	if err != nil {
		t.Fatalf("ParseReconFTWOutput: %v", err)
	}

	found := false
	for _, f := range result.Findings {
		if f.Source == "reconftw:nuclei" && string(f.Severity) == "critical" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected critical nuclei finding from vulns/critical.json")
	}
}

func TestWriteReconFTWToPipeline(t *testing.T) {
	outDir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	r := &ReconFTWResult{
		Subdomains: []string{"api.target.com", "admin.target.com"},
		LiveHosts:  []string{"https://api.target.com", "https://admin.target.com"},
	}

	WriteReconFTWToPipeline(outDir, scanID, r)

	// Check subs file
	subsData, err := os.ReadFile(filepath.Join(outDir, id8+"_subs.txt"))
	if err != nil {
		t.Fatalf("subs file not created: %v", err)
	}
	if !contains(string(subsData), "api.target.com") {
		t.Error("api.target.com not in subs file")
	}

	// Check live file
	liveData, err := os.ReadFile(filepath.Join(outDir, id8+"_live.txt"))
	if err != nil {
		t.Fatalf("live file not created: %v", err)
	}
	if !contains(string(liveData), "https://api.target.com") {
		t.Error("https://api.target.com not in live file")
	}
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || len(s) > 0 && containsStr(s, sub))
}

func containsStr(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
