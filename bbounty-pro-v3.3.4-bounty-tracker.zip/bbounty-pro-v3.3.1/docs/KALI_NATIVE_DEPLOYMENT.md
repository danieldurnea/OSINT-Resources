# Kali Native Deployment Guide

> Run BBounty Pro **without Docker**, directly on Kali Linux 2024.x+ (or Debian 12+, Ubuntu 22.04+).
> Useful for: PC hunting setup, VPS without Docker, embedded test boxes.

## When to use this vs Docker

| Use Native (this guide) | Use Docker |
|---|---|
| Personal Kali workstation | VPS deployment |
| Tools already installed | Clean isolated environment |
| Direct hardware access (USB, etc.) | Reproducible builds |
| Faster iteration during dev | Multi-tenant / production |
| Single-user setup | Team scanning infrastructure |

## Quick install (one command)

From a fresh Kali install with sudo:

```bash
git clone <repo> /opt/bbounty-pro
cd /opt/bbounty-pro
sudo bash scripts/install-kali-native.sh
```

The script installs:
- **Redis 7** (apt + systemd)
- **Go 1.26** (matches go.mod; latest stable from go.dev)
- **Bun + Node.js 22** (frontend runtime)
- **PostgreSQL 16** (optional, for long-term findings)
- **100+ security tools** in `/opt/bbounty-tools/bin`
- **SecLists wordlists** at `/opt/bbounty-tools/wordlists/SecLists`
- **Builds the orchestrator + frontend**
- **Installs systemd services** (`bbounty-orchestrator`, `bbounty-web`)

Total install time: 8–15 minutes depending on Go module cache + bandwidth.

## Install options

```bash
# Tools only (no orchestrator/frontend — useful for upgrade or partial setup)
sudo bash scripts/install-kali-native.sh --tools-only

# Skip PostgreSQL (Redis is sufficient for ≤72h finding retention)
sudo bash scripts/install-kali-native.sh --no-postgres

# Clean uninstall (keeps Redis/Postgres/tools, removes services + project)
sudo bash scripts/install-kali-native.sh --uninstall
```

## After installation

### 1. Configure environment

```bash
sudoedit /opt/bbounty-pro/.env
```

Required field:
```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

Auto-set by installer:
- `MODE=local`
- `JWT_SECRET` (random 64-hex)
- `BIND_ADDR=127.0.0.1`
- `REDIS_URL=redis://127.0.0.1:6379`
- `DOCKER_MODE=false`
- `POSTGRES_PASSWORD` (if Postgres installed)

### 2. Start services

```bash
sudo systemctl start bbounty-orchestrator bbounty-web
```

Or via Makefile:
```bash
make local-start
```

### 3. Verify

```bash
make local-health
```

Should print:
```
✓ Redis: PONG
✓ Orchestrator: ok
✓ Web: ok
✓ nuclei: <version>
✓ subfinder: <version>
✓ httpx: ok
```

### 4. Open dashboard

```
http://127.0.0.1:3000
```

First registered account = admin.

## Service management

| Command | Effect |
|---|---|
| `make local-start` | Start orchestrator + web |
| `make local-stop` | Stop both |
| `make local-restart` | Restart both |
| `make local-status` | systemctl status |
| `make local-logs` | journalctl -f for both |
| `make local-dev` | Run in foreground (no systemd, hot-reload Go + bun dev) |

Direct systemctl:
```bash
sudo systemctl status bbounty-orchestrator
sudo systemctl restart bbounty-web
sudo journalctl -u bbounty-orchestrator -f
```

Log files (also written by services):
- `/var/log/bbounty-orchestrator.log`
- `/var/log/bbounty-web.log`

## Tool inventory

After install, tools live at `/opt/bbounty-tools/bin`, symlinked into `/usr/local/bin`:

**Recon:** subfinder, assetfinder, amass, dnsx, chaos, puredns, shuffledns
**HTTP/Probing:** httpx, naabu, katana, gau, waybackurls, gospider, hakrawler
**Scanners:** nuclei, dalfox, ffuf, gobuster, crlfuzz, cariddi
**Params:** kxss, qsreplace, gf, anew, unfurl, meg, arjun, paramspider
**Takeover:** subzy, subjack
**Secrets:** gitleaks, trufflehog
**Python (pipx):** arjun, dirsearch, corscanner, graphw00f, ssrfmap, xnLinkFinder
**APT:** nmap, masscan, sqlmap, nikto, wpscan, hydra, john, hashcat, metasploit-framework

Updates:
```bash
# Update all Go tools
sudo bash scripts/install-kali-native.sh --tools-only

# Update nuclei templates only
nuclei -update-templates
```

## Hardening (recommended for shared/multi-user systems)

The systemd unit applies these by default:

```ini
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
LimitNOFILE=65536
```

Service runs as user `bbounty`, not root. Tools still run as `bbounty` —
they inherit no special capabilities. For raw socket scanning (masscan,
naabu SYN scan), grant capability instead of root:

```bash
sudo setcap cap_net_raw+ep /usr/local/bin/masscan
sudo setcap cap_net_raw+ep /usr/local/bin/naabu
```

## Firewall (recommended)

By default, services bind to 127.0.0.1 (loopback only). To access from LAN:

```bash
# Edit .env
BIND_ADDR=0.0.0.0

# Open ports (be careful)
sudo ufw allow from 192.168.1.0/24 to any port 3000 comment 'BBounty UI LAN'
sudo ufw allow from 192.168.1.0/24 to any port 8080 comment 'BBounty API LAN'
sudo systemctl restart bbounty-orchestrator bbounty-web
```

For public access, deploy on a real VPS using `MODE=vps` instead.

## Reverse proxy (optional, for HTTPS on local domain)

If you have a local domain (e.g., `bbounty.lan`), install Caddy:

```bash
sudo apt install caddy
sudo tee /etc/caddy/Caddyfile << 'EOF'
bbounty.lan {
    tls internal
    reverse_proxy /api/* localhost:8080
    reverse_proxy /ws/* localhost:8080
    reverse_proxy /auth/* localhost:8080
    reverse_proxy /healthz localhost:8080
    reverse_proxy /* localhost:3000
}
EOF
sudo systemctl restart caddy
```

Then access: `https://bbounty.lan` (after adding to `/etc/hosts` or DNS).

## Troubleshooting

### "Connection refused" on /healthz
```bash
sudo journalctl -u bbounty-orchestrator -n 50
# Check JWT_SECRET is set, Redis is running, .env permissions are 600
```

### Tools missing
```bash
ls /opt/bbounty-tools/bin/ | wc -l    # should be 30+
sudo bash scripts/install-kali-native.sh --tools-only   # reinstall
```

### Frontend won't start
```bash
sudo journalctl -u bbounty-web -n 50
# Common: bun not in PATH for service user
sudo -u bbounty -H bash -c 'which bun'
# If empty: ln -s /root/.bun/bin/bun /usr/local/bin/bun
```

### Port conflict
```bash
sudo ss -tlnp | grep -E ':(3000|8080|6379)'
# Edit .env to change PORT, restart
```

### Reset and reinstall
```bash
sudo bash scripts/install-kali-native.sh --uninstall
sudo bash scripts/install-kali-native.sh
```

## Comparison: Local vs VPS modes

| Aspect | MODE=local | MODE=vps |
|---|---|---|
| Bind address | 127.0.0.1 | 0.0.0.0 |
| Public IP requirement | None | Required |
| JWT_SECRET | Required | Required |
| Bug bounty scanning | Risky (residential IP) | Recommended |
| Frontend access | LAN/localhost | HTTPS public |
| Hardening level | Standard | Maximum |
| Use case | PC dev/testing | Production |

For real bug bounty work on platforms like HackerOne, **always use a VPS**.
ISP can flag scanning traffic from residential IPs as abuse.
