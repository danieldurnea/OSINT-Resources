# Third-Party Licenses & Attribution — BBounty Pro

BBounty Pro orchestrates many independent open-source security tools. Each tool
is invoked as an **external binary via subprocess (CLI)** — BBounty Pro does NOT
link against, embed, or modify their source code. This document credits those
tools and satisfies attribution requirements where applicable.

---

## Vigolium (AGPL-3.0) — special attribution

**Vigolium** is a high-fidelity DAST vulnerability scanner created by
**Jessie Ho** ([@j3ssie](https://x.com/j3ssie)).

- **Source code:** https://github.com/vigolium/vigolium
- **Website:** https://www.vigolium.com
- **Documentation:** https://docs.vigolium.com
- **License:** GNU Affero General Public License v3.0 (AGPL-3.0)

### Attribution statement (required by AGPL-3.0)

BBounty Pro uses **Vigolium unmodified**, invoked as an external command-line
binary. The complete, unmodified source code of Vigolium is publicly available
at the repository linked above:

> **https://github.com/vigolium/vigolium**

Per written confirmation from the Vigolium author (Jessie Ho, 2026-05-28),
unmodified use of Vigolium within a hosted SaaS — calling it as an external
binary without modifying its source — does **not** require a commercial license.
The only obligation is to make the original Vigolium source available to end
users, which this link satisfies.

### Important notes

- BBounty Pro invokes **only the Vigolium native scan** (`vigolium scan`).
  The agentic modes (`agent` / `swarm` / `autopilot`) are intentionally NOT
  used — per Vigolium's own security documentation, those run an LLM with
  unsandboxed shell/file/network access on the host.
- BBounty Pro does **not** modify Vigolium. If the source is ever modified,
  AGPL-3.0 would require offering the modified Corresponding Source to all
  network users — at which point a commercial license from the author would
  be the appropriate path (the author offers these). As long as Vigolium runs
  unmodified, no such obligation applies.
- Users of BBounty Pro who wish to inspect, audit, or self-host Vigolium can
  obtain its full source from the GitHub link above.

---

## Other bundled / invoked tools

BBounty Pro invokes the following tools as external binaries. Each retains its
own upstream license; consult the respective repository for full terms.

### ProjectDiscovery suite (MIT)
subfinder, httpx, nuclei, naabu, katana, dnsx, alterx, chaos-client, notify,
interactsh, mapcidr, asnmap, uncover — https://github.com/projectdiscovery

### Go-based tools (various OSI licenses — MIT/Apache-2.0/BSD)
ffuf, dalfox, gitleaks, trufflehog, gospider, hakrawler, gobuster, feroxbuster
(MIT/Apache), subzy, subjack, crlfuzz, afrog, kxss, gf, qsreplace, anew, unfurl,
cariddi, gowitness, byp4xx, kiterunner, vulnapi, gotestwaf, nomore403

### Python tools (various OSI licenses)
sqlmap (GPL-2.0), ghauri, wafw00f, arjun, xsstrike, dirsearch, paramspider,
commix (GPL), ssrfmap, jwt_tool, corsy, smuggler, linkfinder, secretfinder,
graphql-cop, graphw00f, apifuzzer, bbot, theHarvester, emailfinder, metagoofil

### Ruby / other
whatweb (GPL-2.0), wpscan (dual-license — see WPScan terms for commercial use),
nikto (GPL), hydra (AGPL-style — see THC license)

> ⚠️ **wpscan note:** WPScan has its own licensing terms that may restrict
> commercial/SaaS use. Review https://wpscan.com for the current terms before
> enabling it in a commercial deployment.

> ⚠️ **General SaaS reminder:** GPL/AGPL tools invoked as separate external
> binaries (not linked into your code) generally do not impose copyleft on your
> own codebase. However, licensing is your legal responsibility — review each
> tool's terms for your specific deployment, especially for commercial SaaS.

---

## How BBounty Pro invokes tools (technical clarification)

Every tool above is executed via subprocess (`exec.Command` in Go / shell in
the Python agent). BBounty Pro:

- does NOT statically or dynamically link against any tool's code,
- does NOT import any tool's source into its own binary,
- does NOT modify any tool's source,
- treats each tool as an independent program whose stdout/files are parsed.

This separation is the standard "mere aggregation / arms-length invocation"
pattern, which keeps each tool's copyleft scoped to itself rather than to
BBounty Pro's own (proprietary) codebase.

---

## recon0 DSL engine (MIT) — embedded source code

Unlike the tools above (invoked as external binaries), the **DSL detection
engine** in `apps/orchestrator/internal/dsl/` is **source code adapted from**
another project and compiled into BBounty Pro. Its license terms therefore apply
directly and must be honored.

- **Project:** recon0 — all-in-one bug bounty recon pipeline
- **Author:** Orhan Yildirim ([@badchars](https://github.com/badchars))
- **Source:** https://github.com/badchars/recon0 (v0.5.0)
- **License:** MIT (per the project README and repository metadata)
- **Files adapted:** `internal/dsl/{types.go, rules.go, engine.go, rules/default.yaml}`
  (the regex rule engine + 118 built-in detection rules). The BBounty-specific
  `internal/dsl/adapter.go` is original glue and not from recon0.

### MIT License notice (preserved as required)

```
MIT License

Copyright (c) Orhan Yildirim (@badchars)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

> **Note for maintainers:** at integration time the upstream repository declared
> MIT in its README and GitHub metadata but did not contain a `LICENSE` file in
> the cloned tree. The reproduction above is the standard MIT text with the
> project's copyright holder. If upstream later publishes a `LICENSE` with
> different wording, replace the block above with the verbatim upstream text.

---

## Advanced-Bug-Bounty-Reconnaissance-Tool (MIT) — manual-guide logic

The manual testing-guide generator in `apps/orchestrator/internal/manualguide/`
adapts the checklist content from this project's `bugbounty.py` manual-guide
output. Ported to Go and restructured to consume BBounty Pro's scan signals.

- **Project:** Advanced-Bug-Bounty-Reconnaissance-Tool
- **Author:** abdullah89255
- **Source:** https://github.com/abdullah89255/Advanced-Bug-Bounty-Reconnaissance-Tool
- **License:** MIT (repository LICENSE present)
- **Used:** checklist/section content only; engine code is original Go.

MIT terms apply to the adapted content; the copyright notice is preserved here
per the license. For AUTHORIZED security testing only.


## PayloadsAllTheThings (curated reference) — payload wordlists

The curated payload wordlists in `apps/orchestrator/internal/payloads/lists/`
(XSS, SQLi, SSRF, LFI, open-redirect, CMDi, XXE — ~50 each) were hand-selected
with reference to this project plus standard public payload knowledge. This is a
small curated subset, NOT a copy of the full corpus.

- **Project:** PayloadsAllTheThings
- **Author:** Swissky (swisskyrepo) and contributors
- **Source:** https://github.com/swisskyrepo/PayloadsAllTheThings
- **License:** repository is provided for the security community; individual
  payloads are common public knowledge. Attribution preserved here in good faith.
- **For AUTHORIZED security testing only.**


## PayloadBox (İsmail Taşdelen) — SSTI / CRLF / NoSQL payload reference

The SSTI, CRLF and NoSQL payload wordlists added in v3.3.4
(`apps/orchestrator/internal/payloads/lists/{ssti,crlf,nosqli}.txt`) were curated
with reference to the PayloadBox payload-list collection plus standard public
payload knowledge. Curated subset, not a full copy.

- **Project:** PayloadBox (xss/sql/command/ssti/crlf/open-redirect payload lists)
- **Author:** İsmail Taşdelen (@ismailtsdln)
- **Source:** https://github.com/payloadbox
- **Note:** PayloadBox repos are plain payload lists (no executable code); these
  payloads are common public knowledge. Attribution preserved in good faith.
- **For AUTHORIZED security testing only.**


_Last updated: 2026-05-29_
