package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"runtime/debug"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/agent"
	"github.com/bbounty-pro/orchestrator/internal/ai"
	"github.com/bbounty-pro/orchestrator/internal/auditlog"
	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/billing"
	"github.com/bbounty-pro/orchestrator/internal/bounty"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/canary"
	"github.com/bbounty-pro/orchestrator/internal/collab"
	"github.com/bbounty-pro/orchestrator/internal/config"
	"github.com/bbounty-pro/orchestrator/internal/cors"
	"github.com/bbounty-pro/orchestrator/internal/diff"
	"github.com/bbounty-pro/orchestrator/internal/email"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/bbounty-pro/orchestrator/internal/health"
	"github.com/bbounty-pro/orchestrator/internal/hunter"
	"github.com/bbounty-pro/orchestrator/internal/metrics"
	"github.com/bbounty-pro/orchestrator/internal/notify"
	"github.com/bbounty-pro/orchestrator/internal/priority"
	"github.com/bbounty-pro/orchestrator/internal/profile"
	"github.com/bbounty-pro/orchestrator/internal/ratelimit"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/bbounty-pro/orchestrator/internal/scope"
	"github.com/bbounty-pro/orchestrator/internal/skills"
	"github.com/bbounty-pro/orchestrator/internal/tips"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"github.com/bbounty-pro/orchestrator/internal/vps"
	"github.com/bbounty-pro/orchestrator/internal/vulndb"
	"github.com/bbounty-pro/orchestrator/internal/ws"
	chicors "github.com/go-chi/cors"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"github.com/spf13/viper"
)

var version = "3.3.0-zen"

// authRateLimiter returns a per-IP sliding window rate limiter middleware.
// register: 5/hour, login: 20/15min — prevents brute force and mass account creation.
func authRateLimiter(endpoint string, max int, window time.Duration) func(http.Handler) http.Handler {
	type entry struct {
		count   int
		resetAt time.Time
	}
	var (
		mu    sync.Mutex
		store = make(map[string]*entry)
	)
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ip := r.RemoteAddr
			if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
				for i, c := range xff {
					if c == ',' {
						ip = xff[:i]
						break
					}
					if i == len(xff)-1 {
						ip = xff
					}
				}
			}
			mu.Lock()
			e, ok := store[ip+endpoint]
			now := time.Now()
			if !ok || now.After(e.resetAt) {
				e = &entry{count: 0, resetAt: now.Add(window)}
				store[ip+endpoint] = e
			}
			e.count++
			count := e.count
			mu.Unlock()
			if count > max {
				w.Header().Set("Retry-After", fmt.Sprintf("%.0f", window.Seconds()))
				http.Error(w, fmt.Sprintf(
					`{"error":"too many %s attempts — retry after %s"}`, endpoint, window,
				), http.StatusTooManyRequests)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

func main() {
	// PERF (v3.3.4): the Go runtime already honours GOMEMLIMIT from the env
	// natively. When it is NOT set, derive a soft memory limit from the
	// container's cgroup v2 limit (~90% of it) so the GC backs off before the
	// hard cgroup limit triggers an OOM-kill. Under heavy concurrent-scan load
	// this trades a little CPU for stability. GOMAXPROCS is container-aware since
	// Go 1.25, and the Green Tea GC (default in Go 1.26) further cuts GC overhead
	// for this cache/JSON-heavy, high-fan-out workload — both free via the toolchain.
	if os.Getenv("GOMEMLIMIT") == "" {
		if limit, ok := cgroupMemSoftLimit(0.90); ok {
			debug.SetMemoryLimit(limit)
			log.Info().Int64("soft_limit_bytes", limit).
				Msg("runtime: soft memory limit derived from cgroup (anti-OOM)")
		}
	}

	if os.Getenv("ENV") != "production" {
		log.Logger = log.Output(zerolog.ConsoleWriter{Out: os.Stderr, TimeFormat: time.RFC3339})
	}

	if err := vps.EnforceMode(); err != nil {
		log.Fatal().Err(err).Msg("VPS enforcement failed — set ALLOW_LOCAL=true for dev")
	}

	viper.AutomaticEnv()
	viper.SetDefault("BIND_ADDR", "0.0.0.0")
	viper.SetDefault("PORT", "8080")
	viper.SetDefault("REDIS_URL", "redis://redis:6379")
	viper.SetDefault("MAX_CONCURRENT", 8)
	viper.SetDefault("FRONTEND_URL", "")
	viper.SetDefault("SKILLS_ROOT", "/opt/bbounty-pro/apps/skills")
	viper.SetDefault("DATABASE_URL", "")
	viper.SetDefault("AI_PROXY_URL", "http://127.0.0.1:8001")
	viper.SetDefault("PROFILES_DIR", "") // empty = embedded built-ins only

	if viper.GetString("JWT_SECRET") == "" {
		log.Fatal().Msg("JWT_SECRET required — generate with: openssl rand -hex 32")
	}

	rootCtx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// ── Core deps ─────────────────────────────────────────────────────────────
	redisClient := cache.MustConnect(viper.GetString("REDIS_URL"))
	wsHub := ws.NewHub(redisClient)
	registry := tools.NewRegistry()
	roeGate := roe.NewGate()
	findingsStore := findings.NewStore(redisClient)
	hunterStore := hunter.NewStore(redisClient.Raw())
	hunterHandler := hunter.NewHandler(hunterStore, func(r *http.Request) string {
		if c := auth.ClaimsFromCtx(r.Context()); c != nil {
			return c.UserID
		}
		return ""
	})
	scopeStore := scope.NewStore(redisClient.Raw())
	scopeHandler := scope.NewHandler(scopeStore, func(r *http.Request) string {
		if c := auth.ClaimsFromCtx(r.Context()); c != nil {
			return c.UserID
		}
		return ""
	}, roeGate.CheckInScope)
	collabStore := collab.NewStore(redisClient.Raw())
	collabHandler := collab.NewHandler(collabStore, func(r *http.Request) string {
		if c := auth.ClaimsFromCtx(r.Context()); c != nil {
			return c.UserID
		}
		return ""
	}, func(ctx context.Context, scanID, userID string) bool {
		owner, err := redisClient.Raw().Get(ctx, "scan:owner:"+scanID).Result()
		return err == nil && owner == userID
	}, func(ctx context.Context, username string) (string, bool) {
		id, err := redisClient.Raw().Get(ctx, "auth:uname:"+strings.ToLower(username)).Result()
		return id, err == nil && id != ""
	})
	findingsStore.SetSharedAccessChecker(collabStore.CanAccess)
	vulnStore := vulndb.NewStore(redisClient.Raw())
	vulnHandler := vulndb.NewHandler(vulnStore, func(r *http.Request) string {
		if c := auth.ClaimsFromCtx(r.Context()); c != nil {
			return c.UserID
		}
		return ""
	})
	bountyStore := bounty.NewStore(redisClient.Raw())
	bountyHandler := bounty.NewHandler(bountyStore, func(r *http.Request) string {
		if c := auth.ClaimsFromCtx(r.Context()); c != nil {
			return c.UserID
		}
		return ""
	})
	// Vulnerability DB false-positive learning: when a finding is marked
	// invalid/duplicate, record its fingerprint as a known FP for the scan owner.
	findingsStore.OnStatusChange(func(f *findings.Finding) {
		ctx := context.Background()
		owner, err := redisClient.Raw().Get(ctx, "scan:owner:"+f.ScanID).Result()
		if err != nil || owner == "" {
			return
		}
		fp := vulndb.Fingerprint(f.Category, f.URL, f.Parameter)
		if f.Status == findings.StatusInvalid || f.Status == findings.StatusDuplicate {
			_ = vulnStore.MarkFalsePositive(ctx, owner, fp)
		} else if f.Status == findings.StatusConfirmed {
			_ = vulnStore.UnmarkFalsePositive(ctx, owner, fp)
		}
	})
	// Record every saved finding into the user's Vulnerability DB (history).
	findingsStore.OnSave(func(f *findings.Finding) {
		ctx := context.Background()
		owner, err := redisClient.Raw().Get(ctx, "scan:owner:"+f.ScanID).Result()
		if err != nil || owner == "" {
			return
		}
		_, _ = vulnStore.Record(ctx, owner, vulndb.Entry{
			Fingerprint: vulndb.Fingerprint(f.Category, f.URL, f.Parameter),
			ScanID:      f.ScanID,
			Title:       f.Title,
			URL:         f.URL,
			Category:    f.Category,
			Parameter:   f.Parameter,
			Severity:    string(f.Severity),
			Status:      string(f.Status),
		})
	})
	primaryAI := ai.NewClient(viper.GetString("ANTHROPIC_API_KEY"))
	cachedAI := ai.NewCachedClient(primaryAI, redisClient)
	rateLimReg := ratelimit.NewRegistry(redisClient)
	scorer := priority.NewScorer(primaryAI, redisClient)
	diffEngine := diff.NewEngine(redisClient)
	notifier := notify.New()

	// Auth manager — handles login, register, JWT, 2FA
	authMgr := auth.NewManager(redisClient, viper.GetString("JWT_SECRET"))

	// Optional Postgres — nil-safe everywhere
	var pgPool *pgxpool.Pool
	if dsn := viper.GetString("DATABASE_URL"); dsn != "" {
		cfg, err := pgxpool.ParseConfig(dsn)
		if err != nil {
			log.Warn().Err(err).Msg("postgres: invalid DATABASE_URL — Redis-only")
		} else {
			cfg.MaxConns = 10
			cfg.MinConns = 2
			cfg.MaxConnLifetime = time.Hour
			pool, err := pgxpool.NewWithConfig(rootCtx, cfg)
			if err != nil || pool.Ping(rootCtx) != nil {
				log.Warn().Msg("postgres: unavailable — Redis-only")
				if pool != nil {
					pool.Close()
				}
			} else {
				pgPool = pool
				log.Info().Msg("postgres: connected ✓")
				defer pgPool.Close()
			}
		}
	} else {
		log.Info().Msg("postgres: not configured — Redis-only mode")
	}

	healthChecker := health.New(redisClient, pgPool)
	auditLogger := auditlog.New(redisClient, pgPool)

	// ── Email service ─────────────────────────────────────────────────────────
	emailSvc := email.New(email.ConfigFromEnv())
	resetStore := email.NewResetStore(redisClient)

	// Inject email into auth manager (welcome email on register)
	authMgr.SetEmailService(emailSvc)
	pipeline := agent.NewPipeline(registry, wsHub, roeGate, findingsStore, redisClient)
	checkpoints := agent.NewCheckpointStore(redisClient)

	// Profile loader — built-in profiles + optional user profiles from disk
	profileLoader := profile.NewLoader(viper.GetString("PROFILES_DIR"))
	if err := profileLoader.Load(); err != nil {
		log.Warn().Err(err).Msg("profiles: load failed — built-ins only")
	}

	pipeline.SetCheckpointStore(checkpoints)
	pipeline.SetRateLimiter(rateLimReg)
	pipeline.SetProfileLoader(profileLoader)
	pipeline.SetHunterRecorder(hunterStore)
	pipeline.SetScopeResolver(scopeStore)
	pipeline.SetEmailService(emailSvc)
	pipeline.SetDiffEngine(diffEngine)
	pipeline.SetNotifier(notifier)

	if pgPool != nil {
		go findings.NewPostgresSync(findingsStore, pgPool).Run(rootCtx)
		log.Info().Msg("findings: Postgres sync started")
	}

	// Wire audit hook into auth manager
	authMgr.SetAuditLoginSuccess(func(ctx context.Context, _ *auth.Manager, u *auth.User) {
		auditLogger.Log(ctx, auditlog.Event{
			Type:      auditlog.EventLoginSuccess,
			Timestamp: time.Now(),
			UserID:    u.ID,
			Username:  u.Username,
			UserRole:  string(u.Role),
			Action:    "auth.login",
			Success:   true,
		})
	})

	// ── Cross-module hooks ────────────────────────────────────────────────────
	findingsStore.OnSave(func(f *findings.Finding) {
		auditLogger.Log(context.Background(), auditlog.Event{
			Type:       auditlog.EventFindingCreate,
			Timestamp:  time.Now(),
			ResourceID: f.ScanID,
			Action:     "finding.saved",
			Success:    true,
			Metadata:   map[string]any{"id": f.ID, "severity": string(f.Severity), "title": f.Title},
		})
		if f.Severity == findings.SeverityCritical || f.Severity == findings.SeverityHigh {
			sev := notify.SevWarning
			if f.Severity == findings.SeverityCritical {
				sev = notify.SevCritical
			}
			notifier.Send(context.Background(), notify.Message{
				Title:    "[" + string(f.Severity) + "] " + f.Title,
				Body:     f.URL,
				Severity: sev,
				Target:   f.URL,
				Fields:   map[string]any{"category": f.Category, "source": f.Source},
			})
			metrics.FindingsTotal.Inc(string(f.Severity))
		}
	})

	// ── Health probe: AI proxy ─────────────────────────────────────────────────
	healthChecker.AddProbe(health.Probe{
		Name: "ai-proxy", Critical: false,
		Check: func(ctx context.Context) error {
			if viper.GetString("ANTHROPIC_API_KEY") == "" {
				return nil
			}
			c, cancel := context.WithTimeout(ctx, 3*time.Second)
			defer cancel()
			req, _ := http.NewRequestWithContext(c, "GET", viper.GetString("AI_PROXY_URL")+"/health", nil)
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				return err
			}
			resp.Body.Close()
			return nil
		},
	})

	// ── Skills ────────────────────────────────────────────────────────────────
	skillRegistry := skills.NewRegistry(viper.GetString("SKILLS_ROOT"))
	if err := skillRegistry.LoadFromDisk(); err != nil {
		log.Warn().Err(err).Msg("skills: disk load failed — built-ins only")
	}
	pythonRunner := skills.NewPythonRunner()

	// ── Background workers ────────────────────────────────────────────────────
	go wsHub.Run()
	go auditLogger.Run(rootCtx)
	go func() {
		t := time.NewTicker(6 * time.Hour)
		defer t.Stop()
		for {
			select {
			case <-t.C:
				agent.CleanOldOutputs(config.OldOutputAge)
			case <-rootCtx.Done():
				return
			}
		}
	}()

	// ── Router ────────────────────────────────────────────────────────────────
	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(middleware.Recoverer)
	r.Use(middleware.Compress(5))
	// HARDENING: panic recovery — un panic nu mai omoară serverul
	r.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			defer func() {
				if rec := recover(); rec != nil {
					log.Error().
						Str("method", r.Method).
						Str("path", r.URL.Path).
						Interface("panic", rec).
						Msg("recovered from panic")
					http.Error(w, `{"error":"internal server error"}`, http.StatusInternalServerError)
				}
			}()
			next.ServeHTTP(w, r)
		})
	})
	r.Use(metrics.HTTPMiddleware)

	allowedOrigins := []string{"http://localhost:3000"}
	if u := viper.GetString("FRONTEND_URL"); u != "" {
		allowedOrigins = []string{u}
	}
	r.Use(chicors.Handler(chicors.Options{
		AllowedOrigins:   allowedOrigins,
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-Request-ID"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// ── Canary honeypot (B): detectează recon pe platformă ────────────────────
	// Înregistrează ~25 endpoint-uri capcană (.env, /.git/config, /wp-admin etc.)
	// care, când sunt accesate, logează request-ul și auto-block-ează IP-ul după
	// AutoBlockThreshold hit-uri în AutoBlockWindow.
	//
	// BlockMiddleware e DUPĂ middleware-urile globale (RequestID, RealIP,
	// Recoverer, CORS) ca să avem RealIP setat corect ÎNAINTE de check, dar
	// ÎNAINTE de toate rutele reale ca să blocăm IP-urile rele cât mai devreme.
	canarySvc := canary.NewService(redisClient.Raw(), canary.DefaultConfig())
	canarySvc.SetNotifier(&canaryNotifierAdapter{notifier: notifier})
	// Broadcaster intentionally not wired: ws.Hub broadcasts only per-scanID
	// (terminal/stats/pipeline). Canary events go to logs + Slack/Discord
	// via notifier. Dashboard polls /api/v1/admin/canary/stats periodic
	// pentru live view.
	r.Use(canarySvc.BlockMiddleware)
	canarySvc.RegisterRoutes(r)

	// ── Public routes ─────────────────────────────────────────────────────────
	r.Get("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		// C4-FIX: public_ip, vps_mode, postgres removed — infrastructure enumeration.
		_ = json.NewEncoder(w).Encode(map[string]any{
			"status":  "ok",
			"version": version,
		})
	})
	r.Get("/livez", healthChecker.HandleLive)
	r.Get("/readyz", healthChecker.HandleReady)
	r.Get("/health", healthChecker.HandleHealth)
	// C3-FIX: /metrics restricted to localhost only — prevents info leak.
	// Prometheus scraper must run on same host or use SSH tunnel.
	r.Get("/metrics", func(w http.ResponseWriter, r *http.Request) {
		// Allow only loopback and RFC1918 addresses
		host, _, _ := net.SplitHostPort(r.RemoteAddr)
		allowed := host == "127.0.0.1" || host == "::1" ||
			strings.HasPrefix(host, "10.") ||
			strings.HasPrefix(host, "172.") ||
			strings.HasPrefix(host, "192.168.")
		if !allowed {
			http.Error(w, `{"error":"forbidden"}`, http.StatusForbidden)
			return
		}
		metrics.HandleMetrics(w, r)
	})

	// ── Auth routes (public) ──────────────────────────────────────────────────
	r.Route("/auth", func(r chi.Router) {
		// Public — rate limited to prevent account creation abuse and brute force
		// register: max 5/hour per IP (prevents mass account creation)
		// login:    max 20/15min per IP (brute force protection — Redis two-tier
		//           per-account limit is handled inside HandleLogin)
		r.With(authRateLimiter("register", 5, time.Hour)).
			Post("/register", authMgr.HandleRegister)
		r.With(authRateLimiter("login", 20, 15*time.Minute)).
			Post("/login", authMgr.HandleLogin)
		r.Post("/refresh", authMgr.HandleRefresh)
		r.Post("/2fa/validate", authMgr.HandleValidate2FA)

		// Forgot / reset password
		emailHandler := email.NewHandler(
			emailSvc, resetStore,
			authMgr.FindUserByEmail,
			authMgr.UpdatePassword,
		)
		r.Post("/forgot-password", emailHandler.HandleForgotPassword)
		r.Post("/reset-password", emailHandler.HandleResetPassword)

		// Protected
		r.Group(func(r chi.Router) {
			r.Use(authMgr.Middleware)
			r.Get("/me", authMgr.HandleMe)
			r.Post("/logout", authMgr.HandleLogout)
			r.Post("/invite", authMgr.HandleInvite)
			r.Get("/team", authMgr.HandleTeam)
			r.Put("/team/{id}", authMgr.HandleUpdateMember)

			// 2FA management
			r.Post("/2fa/setup", authMgr.HandleSetup2FA)     // generate QR + secret
			r.Post("/2fa/verify", authMgr.HandleVerify2FA)   // confirm code → enable 2FA
			r.Post("/2fa/disable", authMgr.HandleDisable2FA) // disable 2FA (requires valid code)
		})
	})

	// ── Billing service (single instance shared by webhook + API routes) ──────
	billingSvc := billing.New(
		redisClient,
		viper.GetString("STRIPE_SECRET_KEY"),
		viper.GetString("STRIPE_WEBHOOK_SECRET"),
		viper.GetString("APP_URL"),
	)
	// Inject Stripe price IDs from .env
	if p := billing.Plans["solo"]; viper.GetString("STRIPE_PRICE_SOLO") != "" {
		p.StripePriceID = viper.GetString("STRIPE_PRICE_SOLO")
		billing.Plans["solo"] = p
	}
	if p := billing.Plans["professional"]; viper.GetString("STRIPE_PRICE_PROFESSIONAL") != "" {
		p.StripePriceID = viper.GetString("STRIPE_PRICE_PROFESSIONAL")
		billing.Plans["professional"] = p
	}
	if p := billing.Plans["team"]; viper.GetString("STRIPE_PRICE_TEAM") != "" {
		p.StripePriceID = viper.GetString("STRIPE_PRICE_TEAM")
		billing.Plans["team"] = p
	}
	// Send receipt email after successful Stripe payment
	billingSvc.SetPaymentCallback(func(ctx context.Context, userID, planName string, amountUSD int) {
		users, err := authMgr.ListTeamByID(ctx)
		if err != nil {
			return
		}
		for _, u := range users {
			if u.ID == userID {
				if err := emailSvc.SendReceipt(ctx, u.Email, u.Username, planName, amountUSD); err != nil {
					log.Warn().Err(err).Str("user", userID).Msg("[billing] receipt email failed")
				}
				return
			}
		}
	})

	// ── Stripe Webhook (public — Stripe calls this, no JWT) ──────────────────
	// Must be registered BEFORE the authenticated API block.
	// We verify the Stripe-Signature header instead of JWT.
	r.Post("/api/v1/billing/webhook", billingSvc.HandleWebhook)

	// ── Protected API ─────────────────────────────────────────────────────────
	r.Route("/api/v1", func(r chi.Router) {
		r.Use(authMgr.Middleware)
		// CSRF enforcement on all state-changing requests.
		// Double-submit cookie pattern: X-CSRF-Token header must match bb_csrf cookie.
		// GET/HEAD/OPTIONS are exempt. Legacy Bearer-only clients (no cookie) are exempt.
		r.Use(auth.CSRFMiddleware)
		hunterAdmin := authMgr.RequireRole(auth.RoleAdmin, auth.RoleHunter)

		// ── Billing (Stripe) — uses shared billingSvc from above ──────────────
		r.Get("/billing/plans", billingSvc.HandlePlans)
		r.Get("/billing/status", billingSvc.HandleStatus)
		r.Post("/billing/checkout", billingSvc.HandleCheckout)
		r.Post("/billing/portal", billingSvc.HandlePortal)

		// Scan — wrapped with plan enforcement
		r.With(hunterAdmin, billingSvc.EnforcePlan).Post("/scan/start", pipeline.HandleStart)
		r.With(hunterAdmin).Post("/scan/stop", pipeline.HandleStop)
		r.With(hunterAdmin).Post("/scan/pause", pipeline.HandlePause)
		r.Get("/scan/status/{scanID}", pipeline.HandleStatus)
		r.Get("/scan/resumable", pipeline.HandleListResumable)
		r.With(hunterAdmin).Post("/scan/{scanID}/resume", pipeline.HandleResume)

		// Tools
		r.Get("/tools", registry.HandleList)
		r.Get("/tools/{toolID}/info", registry.HandleInfo)
		r.With(hunterAdmin).Post("/tools/{toolID}/run", registry.HandleRunSingle)

		// Profiles
		r.Get("/profiles", profileLoader.HandleList)

		// Skills
		r.Get("/skills", skillRegistry.HandleList)
		r.Get("/skills/{skillID}", skillRegistry.HandleGet)
		r.With(hunterAdmin).Post("/skills/{skillID}/execute", skillRegistry.HandleExecute(pythonRunner))

		// Tips — AI-powered daily tips + contextual scan hints (cached 24h)
		tipsHandler := tips.New(primaryAI, redisClient)
		r.Get("/tips", tipsHandler.HandleDailyTips)
		r.Post("/tips/contextual", tipsHandler.HandleContextualTip)

		// ROE
		r.Post("/roe/validate", roeGate.HandleValidate)
		r.Post("/roe/check-scope", roeGate.HandleCheckScope)

		// CORS Engine (native Go — tests 7 vectors per URL)
		corsHandler := cors.NewHandler()
		r.Get("/cors/scan", corsHandler.HandleScanSingle) // GET ?url=https://target.com
		r.Post("/cors/scan", corsHandler.HandleScan)      // POST {"urls":[...]}

		// Findings
		r.Get("/findings/{scanID}", findingsStore.HandleList)
		r.Get("/findings/{scanID}/stream", findingsStore.HandleStream)
		r.Get("/findings/{scanID}/export", findingsStore.HandleExport) // Markdown + JSON report
		// Hunter Dashboard (v3.3.4): personal stats + scan history
		r.Get("/hunter/stats", hunterHandler.HandleStats)
		r.Get("/hunter/history", hunterHandler.HandleHistory)
		// Scope Manager (v3.3.4): saved programs + H1/Bugcrowd import + auto-check
		r.Get("/scope/programs", scopeHandler.HandleList)
		r.Post("/scope/programs", scopeHandler.HandleSave)
		r.Delete("/scope/programs/{id}", scopeHandler.HandleDelete)
		r.Post("/scope/import", scopeHandler.HandleImport)
		r.Post("/scope/check", scopeHandler.HandleCheck)
		// Collaboration (v3.3.4): share scan results with team hunters
		r.Get("/collab/shared-with-me", collabHandler.HandleSharedWithMe)
		r.Post("/collab/{scanID}/share", collabHandler.HandleShare)
		r.Delete("/collab/{scanID}/share/{userID}", collabHandler.HandleRevoke)
		r.Get("/collab/{scanID}/members", collabHandler.HandleMembers)
		// Vulnerability Database (v3.3.4): finding history + false-positive learning
		r.Get("/vulndb", vulnHandler.HandleList)
		r.Get("/vulndb/stats", vulnHandler.HandleStats)
		r.Post("/vulndb/check", vulnHandler.HandleCheck)
		// Bounty Tracker (v3.3.4): submitted report status + earnings
		r.Get("/bounty", bountyHandler.HandleList)
		r.Post("/bounty", bountyHandler.HandleSave)
		r.Delete("/bounty/{id}", bountyHandler.HandleDelete)
		r.Get("/bounty/stats", bountyHandler.HandleStats)
		r.With(hunterAdmin).Post("/findings", findingsStore.HandleCreate)
		r.With(hunterAdmin).Put("/findings/{id}", findingsStore.HandleUpdate)
		r.With(authMgr.RequireRole(auth.RoleAdmin)).Delete("/findings/{id}", findingsStore.HandleDelete)
		// cachedAI: cache-first analysis — same finding hash → no redundant API call
		r.Post("/findings/{id}/analyze", cachedAI.HandleAnalyzeFindingCached)

		// AI
		r.Post("/ai/chat", primaryAI.HandleChat)
		r.Post("/ai/report-review", primaryAI.HandleReportReview)

		// Audit
		r.With(authMgr.RequireRole(auth.RoleAdmin)).
			Get("/audit", func(w http.ResponseWriter, r *http.Request) {
				if pgPool == nil {
					http.Error(w, `{"error":"audit requires Postgres"}`, http.StatusServiceUnavailable)
					return
				}
				events, err := auditLogger.Query(r.Context(), auditlog.QueryOptions{Limit: 100})
				if err != nil {
					http.Error(w, `{"error":"audit query failed"}`, http.StatusInternalServerError)
					return
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(events)
			})

		// Canary (B): stats + listă hits recente, doar admin.
		// Path-urile capcană SUNT publice (registered direct pe r, nu pe acest
		// group protected) — doar dashboard-ul cu hits e admin-only.
		r.With(authMgr.RequireRole(auth.RoleAdmin)).
			Get("/admin/canary/stats", canarySvc.HandleAdminStats)
		r.With(authMgr.RequireRole(auth.RoleAdmin)).
			Get("/admin/canary/hits", canarySvc.HandleAdminListHits)

		// Dashboards
		r.Get("/stats/{scanID}", pipeline.HandleStats)
		r.Get("/ratelimit/stats", rateLimReg.HandleStats)
		r.Get("/priority/{scanID}", func(w http.ResponseWriter, r *http.Request) {
			q, err := scorer.GetQueue(r.Context(), chi.URLParam(r, "scanID"))
			if err != nil {
				http.Error(w, `{"error":"queue not ready"}`, http.StatusNotFound)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(q)
		})

		// Diff
		r.Get("/diff/latest", diffEngine.HandleLatestDiff)
		r.Get("/diff/history", diffEngine.HandleScanHistory)
		r.Get("/diff/compare", func(w http.ResponseWriter, r *http.Request) {
			q := r.URL.Query()
			old, new_, target := q.Get("old"), q.Get("new"), q.Get("target")
			if old == "" || new_ == "" || target == "" {
				http.Error(w, `{"error":"old, new, target required"}`, http.StatusBadRequest)
				return
			}
			oldSnap, err1 := diffEngine.GetSnapshot(r.Context(), target, old)
			newSnap, err2 := diffEngine.GetSnapshot(r.Context(), target, new_)
			if err1 != nil || err2 != nil {
				http.Error(w, `{"error":"snapshot not found"}`, http.StatusNotFound)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(diffEngine.Compare(r.Context(), oldSnap, newSnap))
		})
	})

	// ── WebSocket (JWT via ?token= query param) ───────────────────────────────
	r.Group(func(r chi.Router) {
		r.Use(authMgr.WSMiddleware)
		r.Get("/ws/terminal/{scanID}/{toolID}", wsHub.HandleTerminal)
		r.Get("/ws/stats/{scanID}", wsHub.HandleStats)
		r.Get("/ws/pipeline/{scanID}", wsHub.HandlePipeline)
	})

	addr := viper.GetString("BIND_ADDR") + ":" + viper.GetString("PORT")
	srv := &http.Server{
		Addr:              addr,
		Handler:           r,
		ReadTimeout:       config.HTTPReadTimeout,
		WriteTimeout:      0,
		IdleTimeout:       config.HTTPIdleTimeout,
		ReadHeaderTimeout: config.HTTPReadHeaderTimeout,
	}

	go func() {
		log.Info().
			Str("addr", srv.Addr).
			Str("version", version).
			Str("public_ip", vps.PublicIP()).
			Bool("postgres", pgPool != nil).
			Msg("BBounty Pro orchestrator started — 2FA enabled")
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatal().Err(err).Msg("server error")
		}
	}()

	<-rootCtx.Done()
	log.Info().Msg("Shutting down...")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), config.HTTPShutdownTimeout)
	defer cancel()
	pipeline.StopJanitor() // stop background goroutine cleanly
	wsHub.Stop()           // OPUS-FIX H1: stop WebSocket Hub goroutine
	pipeline.DrainAll(shutdownCtx)
	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Error().Err(err).Msg("shutdown error")
	}
	log.Info().Msg("Stopped cleanly")
}

// canaryNotifierAdapter — adapt notify.Notifier la interfața canary.Notifier.
// Canary nu vrea să depindă direct de notify (evită ciclu de import) — îi
// dă o interfață minimă; aici implementăm interfața convertind apelurile.
type canaryNotifierAdapter struct {
	notifier *notify.Notifier
}

func (a *canaryNotifierAdapter) NotifySecurityEvent(
	ctx context.Context, title, body string, fields map[string]any,
) {
	if a.notifier == nil {
		return
	}
	// Convertim "fields" la map[string]any cum cere notify.Message.
	// Folosim severity Warning pentru canary hits (single hit) și — implicit —
	// notify.Notifier ratelimit-uiește per-target pe 5min, deci nu suntem
	// spammed la flood.
	a.notifier.Send(ctx, notify.Message{
		Title:    title,
		Body:     body,
		Severity: notify.SevWarning,
		Target:   "canary", // toate canary events pe același "target" → rate limit comun
		Fields:   fields,
	})
}
