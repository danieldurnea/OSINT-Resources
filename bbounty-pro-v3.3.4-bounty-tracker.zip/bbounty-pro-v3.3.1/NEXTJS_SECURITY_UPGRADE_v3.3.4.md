# BBounty Pro — Next.js Security Upgrade v3.3.4

**Date:** 2026-05-29 · **Scope:** `apps/web/package.json` only
**Reason:** the May 2026 Next.js coordinated security release fixed **13 advisories**
(DoS, middleware/proxy bypass, SSRF via WebSocket upgrades, cache poisoning, XSS)
affecting the 15.2.x line you were on. Patching is the only complete mitigation.

---

## What changed in package.json (pinned to known-patched versions)

| Package | Was | Now |
|---|---|---|
| next | 15.2.4 | **^15.5.18** |
| react | 19.0.0 | **^19.2.6** |
| react-dom | 19.0.0 | **^19.2.6** |
| eslint-config-next (dev) | 15.2.4 | **^15.5.18** |
| @types/react (dev) | 19.0.7 | **^19.2.0** |
| @types/react-dom (dev) | 19.0.3 | **^19.2.0** |

**Why the 15.x line, not 16:** this stays on Next 15 (no breaking changes) and
pulls in all the security fixes. Next 16 is a major upgrade (React Compiler stable,
React 19.2 canary, API changes) — worth doing later, with testing, not as an urgent
security patch. Verified against the npm registry: `next@15.5.18` accepts React
`^19.0.0` as a peer, so React 19.2.6 pairs cleanly — no conflict.

Versions are checked exact numbers from the registry (latest stable 15.x = 15.5.18,
latest React 19.x = 19.2.6 as of 2026-05-29). Caret (`^`) lets `npm install` pull any
newer patch automatically while keeping the patched floor.

## What YOU run (I can't reach the npm registry from the build sandbox)

```bash
cd apps/web

# 1. Install the new versions + generate the lockfile (fixes the missing-lockfile issue too)
npm install

# 2. Verify the resolved versions are actually the patched ones
npm ls next react react-dom
#   expect next@15.5.18 (or newer 15.x), react@19.2.6, react-dom@19.2.6

# 3. Type-check + build to confirm nothing broke
npm run typecheck
npm run build

# 4. Audit for remaining known vulns
npm audit

# 5. Commit BOTH package.json and the new lockfile
git add package.json package-lock.json
git commit -m "security: bump Next 15.5.18 + React 19.2.6 (May 2026 advisories)"
```

If you build the Docker image with Bun (the Dockerfile uses `oven/bun`), also refresh
the Bun lockfile from the repo root:
```bash
bun install   # updates bun.lockb
git add bun.lockb && git commit -m "chore: refresh bun lockfile"
```

## If `npm run build` fails after the bump

The 15.2 → 15.5 jump is within the same major and should be clean, but if you hit
issues:
- Check the codemod helper: `npx @next/codemod@latest upgrade latest` (it rewrites
  any changed APIs for you — but review the diff before committing).
- The React 19.0 → 19.2 bump is additive; no known breaking changes for app code.
- Worst case, roll back: `git checkout package.json && npm install`.

## After this — plan the Next 16 upgrade (not urgent)

Next 16 is the current major (16.2.x). When you have time to test:
```bash
npx @next/codemod@latest upgrade latest
```
It brings the stable React Compiler (automatic memoization → fewer re-renders, a
real perf win for a dashboard with many users) — but it's a major upgrade that needs
a staging test pass. Do it deliberately, not as a hotfix.

## Honest note

I pinned exact patched versions verified against the npm registry, but I could not
run `npm install`/`npm run build` here (no registry access in the build sandbox).
The version numbers and peer-compatibility are confirmed; the actual install + build
verification is the one step that must happen on your machine. Run the commands above
before deploying.

---

*Generated 2026-05-29. apps/web/package.json only; security bump within the stable*
*Next 15 line; install + build verification left for the operator (sandbox has no*
*npm registry access).*
