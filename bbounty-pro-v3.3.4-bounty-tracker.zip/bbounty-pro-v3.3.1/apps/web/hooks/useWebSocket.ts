"use client";

import { useEffect, useRef, useCallback, useState } from "react";
import { createWebSocket } from "@/lib/api";

// ─── usePipelineWS — subscribe to scan phase events ──────────────────────────

export type PipelineEvent = {
  event: string;
  payload: Record<string, string | number>;
  ts: number;
};

export function usePipelineWS(
  scanID: string | null,
  onEvent: (evt: PipelineEvent) => void
) {
  const wsRef = useRef<WebSocket | null>(null);
  const onEventRef = useRef(onEvent);
  onEventRef.current = onEvent;

  useEffect(() => {
    if (!scanID) return;

    const ws = createWebSocket(scanID, "pipeline");
    wsRef.current = ws;

    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(
          evt.data instanceof ArrayBuffer
            ? new TextDecoder().decode(evt.data)
            : evt.data
        ) as PipelineEvent;
        onEventRef.current(msg);
      } catch {}
    };

    return () => {
      ws.close();
      wsRef.current = null;
    };
  }, [scanID]);

  return { ws: wsRef.current };
}

// ─── useStatsWS — subscribe to live scan stats ───────────────────────────────

export type LiveStats = {
  scan_id: string;
  phase: string;
  status: string;
  subs: number;
  live: number;
  urls: number;
  vulns: number;
  progress: number;
  elapsed_sec: number;
};

export function useStatsWS(scanID: string | null) {
  const [stats, setStats] = useState<LiveStats | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!scanID) return;

    const ws = createWebSocket(scanID, "stats");
    ws.binaryType = "arraybuffer";

    ws.onopen = () => setConnected(true);
    ws.onclose = () => setConnected(false);

    ws.onmessage = (evt) => {
      try {
        const raw =
          evt.data instanceof ArrayBuffer
            ? new TextDecoder().decode(evt.data)
            : evt.data;
        // Skip ping frames
        if (raw.includes('"ping"')) return;
        setStats(JSON.parse(raw) as LiveStats);
      } catch {}
    };

    return () => ws.close();
  }, [scanID]);

  return { stats, connected };
}

// ─── useTerminalWS — raw binary stream for xterm.js ──────────────────────────

export function useTerminalWS(
  scanID: string | null,
  toolID: string,
  onData: (data: Uint8Array) => void
) {
  const wsRef = useRef<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const onDataRef = useRef(onData);
  onDataRef.current = onData;

  const connect = useCallback(() => {
    if (!scanID) return;

    // Close existing connection
    wsRef.current?.close();

    const ws = createWebSocket(scanID, "terminal", toolID);
    ws.binaryType = "arraybuffer";
    wsRef.current = ws;

    ws.onopen = () => setConnected(true);
    ws.onclose = () => setConnected(false);

    ws.onmessage = (evt) => {
      if (evt.data instanceof ArrayBuffer) {
        onDataRef.current(new Uint8Array(evt.data));
      } else if (typeof evt.data === "string") {
        // Text frame — encode as UTF-8 bytes for xterm
        onDataRef.current(new TextEncoder().encode(evt.data));
      }
    };
  }, [scanID, toolID]);

  useEffect(() => {
    connect();
    return () => {
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [connect]);

  return { connected, reconnect: connect };
}

// ─── useAutoReconnect — wraps any WS hook with reconnect logic ───────────────

export function useAutoReconnect(
  connect: () => void,
  scanID: string | null,
  interval = 3000
) {
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!scanID) return;

    timerRef.current = setInterval(() => {
      connect();
    }, interval);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [connect, scanID, interval]);
}
