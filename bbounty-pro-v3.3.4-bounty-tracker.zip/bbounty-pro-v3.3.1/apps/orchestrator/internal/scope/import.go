package scope

import (
	"encoding/json"
	"strings"
)

// import.go — parse scope from HackerOne / Bugcrowd into a Program.
//
// Hunters get scope in a few shapes. We support the practical ones:
//   1. Plain text, one asset per line (the most common copy-paste), with optional
//      "OUT:" / "-" prefixes or an "Out of scope:" section for exclusions.
//   2. HackerOne structured_scopes JSON (asset_identifier + eligible_for_submission).
//   3. Bugcrowd targets JSON (name/category + in_scope boolean).
//
// Anything we can't confidently classify as a host/pattern is skipped, so a
// messy paste degrades gracefully instead of importing junk.

// ParseScopeText parses a plain-text scope paste. Lines under an "out of
// scope"/"excluded" header (or prefixed with "-" or "OUT:") become exclusions.
func ParseScopeText(text string) (scopeList, excluded []string) {
	inExcluded := false
	for _, raw := range strings.Split(text, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		low := strings.ToLower(line)

		// Section headers toggle the excluded mode.
		if strings.Contains(low, "out of scope") || strings.Contains(low, "out-of-scope") ||
			strings.HasPrefix(low, "excluded") || low == "exclusions:" {
			inExcluded = true
			continue
		}
		if strings.HasPrefix(low, "in scope") || strings.HasPrefix(low, "in-scope") ||
			low == "scope:" || strings.HasPrefix(low, "targets") {
			inExcluded = false
			continue
		}

		// Per-line exclusion markers.
		ex := inExcluded
		if strings.HasPrefix(line, "-") || strings.HasPrefix(low, "out:") {
			ex = true
			line = strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(line, "-"), "OUT:"))
			line = strings.TrimSpace(strings.TrimPrefix(line, "out:"))
		}

		asset := cleanAsset(line)
		if asset == "" {
			continue
		}
		if ex {
			excluded = append(excluded, asset)
		} else {
			scopeList = append(scopeList, asset)
		}
	}
	return dedupe(scopeList), dedupe(excluded)
}

// h1Scope mirrors a HackerOne structured_scopes export entry.
type h1Scope struct {
	AssetIdentifier       string `json:"asset_identifier"`
	AssetType             string `json:"asset_type"`
	EligibleForSubmission *bool  `json:"eligible_for_submission"`
}

// ParseHackerOneJSON parses a HackerOne structured_scopes JSON array.
func ParseHackerOneJSON(data []byte) (scopeList, excluded []string, ok bool) {
	// Accept either a bare array or {"data":[...]} wrapping.
	var arr []h1Scope
	if err := json.Unmarshal(data, &arr); err != nil {
		var wrap struct {
			Data []h1Scope `json:"data"`
		}
		if err2 := json.Unmarshal(data, &wrap); err2 != nil || len(wrap.Data) == 0 {
			return nil, nil, false
		}
		arr = wrap.Data
	}
	for _, e := range arr {
		a := cleanAsset(e.AssetIdentifier)
		if a == "" || !isHostLike(e.AssetType) {
			continue
		}
		if e.EligibleForSubmission != nil && !*e.EligibleForSubmission {
			excluded = append(excluded, a)
		} else {
			scopeList = append(scopeList, a)
		}
	}
	return dedupe(scopeList), dedupe(excluded), len(scopeList)+len(excluded) > 0
}

// bcTarget mirrors a Bugcrowd targets export entry.
type bcTarget struct {
	Name     string `json:"name"`
	Category string `json:"category"`
	InScope  *bool  `json:"in_scope"`
}

// ParseBugcrowdJSON parses a Bugcrowd targets JSON array.
func ParseBugcrowdJSON(data []byte) (scopeList, excluded []string, ok bool) {
	var arr []bcTarget
	if err := json.Unmarshal(data, &arr); err != nil {
		var wrap struct {
			Targets []bcTarget `json:"targets"`
		}
		if err2 := json.Unmarshal(data, &wrap); err2 != nil || len(wrap.Targets) == 0 {
			return nil, nil, false
		}
		arr = wrap.Targets
	}
	for _, t := range arr {
		a := cleanAsset(t.Name)
		if a == "" {
			continue
		}
		// website/api categories are host-like; skip android/ios/source etc.
		if t.Category != "" && !isHostLike(t.Category) {
			continue
		}
		if t.InScope != nil && !*t.InScope {
			excluded = append(excluded, a)
		} else {
			scopeList = append(scopeList, a)
		}
	}
	return dedupe(scopeList), dedupe(excluded), len(scopeList)+len(excluded) > 0
}

// cleanAsset normalises an asset string into a host/pattern, dropping protocol,
// paths, and obvious non-host noise. Preserves wildcards (*.example.com).
func cleanAsset(s string) string {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, "https://")
	s = strings.TrimPrefix(s, "http://")
	// drop path
	if i := strings.IndexByte(s, '/'); i >= 0 {
		s = s[:i]
	}
	s = strings.TrimSpace(s)
	// reject things that clearly aren't hosts/wildcards
	if s == "" || strings.ContainsAny(s, " \t,;") {
		return ""
	}
	if !strings.Contains(s, ".") && !strings.HasPrefix(s, "*") {
		return ""
	}
	return strings.ToLower(s)
}

// isHostLike returns true for asset categories that map to web hosts.
func isHostLike(assetType string) bool {
	switch strings.ToLower(strings.TrimSpace(assetType)) {
	case "", "url", "website", "domain", "wildcard", "api", "cidr", "ip_address", "ip range":
		return true
	default:
		// HackerOne uses things like "OTHER", "SOURCE_CODE", "DOWNLOADABLE_EXECUTABLES" — skip.
		return false
	}
}

func dedupe(in []string) []string {
	seen := map[string]bool{}
	out := make([]string, 0, len(in))
	for _, v := range in {
		if v != "" && !seen[v] {
			seen[v] = true
			out = append(out, v)
		}
	}
	return out
}
