# BBounty Pro v3.3.1 — Audit Fixes Report
**Date:** 2026-05-19
**Auditor:** Claude Sonnet 4.6 Heavy Auditor

---

## Summary

All 14 issues from the full security & architecture audit have been fixed.
25 unit tests added and passing.

---

## P0 — Critical (all fixed)

### C1 ✅ CSRF Bypass via Missing Cookie
**File:** `internal/auth/cookies.go`
- Removed "Bearer-only client = skip CSRF" exception
- Added `crypto/subtle.ConstantTimeCompare` (timing-attack safe)
- No exceptions: all mutations require both cookie AND X-CSRF-Token header

### C2 ✅ AI Proxy — No Rate Limiting
**File:** `apps/ai-proxy/main.py` + `requirements.txt`
- Added `slowapi==0.1.9`
- `/v1/messages`: 30 req/min
- `/analyze`: 20 req/min
- `/chat`: 60 req/min
- Global fallback: 100 req/min

### C3 ✅ CSP `unsafe-inline`
**File:** `infra/nginx/nginx.conf`
- Removed `unsafe-inline` from script-src and style-src
- Added nonce-based CSP using `$request_id` as nonce per request
- Full policy: `default-src 'self'; script-src 'nonce-$csp_nonce'; ...`

---

## P1 — High (all fixed)

### H1 ✅ CSRF Timing Attack
**File:** `internal/auth/cookies.go`
- Fixed in C1 — `subtle.ConstantTimeCompare` used

### H2 ✅ Hardcoded Version in Healthcheck
**File:** `internal/health/checker.go` + `Makefile`
- `Version` var injected at build time via `-ldflags`
- `versionShort()` exposes only major.minor (not patch)
- Makefile: `go build -ldflags="-X '.../health.Version=$(VERSION)'"`

### H3 ✅ BBOUNTY_API in Subprocess Env
**File:** `internal/agent/pipeline.go`
- Removed `BBOUNTY_API` from subprocess env allowlist
- Tools have no knowledge of internal API URL

### H4 ✅ Insufficient Shell Injection Validation
**File:** `apps/agents/specialist_agents/ultra_agent.py`
- Extended from 7 to 15 regex patterns
- Now catches: backtick, `$()`, `${IFS}`, `<()`, `>()`, `|nc`, `|telnet`,
  `&&rm`, `&&curl -o`, `;rm`, `;curl -o`, `eval`, `exec`, `/dev/tcp`, `/dev/udp`
- Uses compiled `re.compile()` for performance

### H5 ✅ SWR Fetcher Missing `credentials: include`
**File:** `apps/web/lib/api.ts`
- `swrFetcher` now sends `credentials: "include"`
- `apiFetch` base function also adds `credentials: "include"`

### H6 ✅ Brain Storage in `/tmp`
**File:** `apps/agents/pentest_agents/brain.py`
- Changed from `/tmp/bbounty-brain` → `/var/lib/bbounty/brain`
- `chmod 700` on init (owner-only access)
- `_cleanup_expired()` runs at startup, removes files older than 90 days
- BRAIN_DIR validated to be absolute path (prevents env var injection)
- Added path traversal check in `_brain_file()`

---

## P2 — Medium/Low (all fixed)

### M1 ✅ Never-Submit Filter Incomplete
**File:** `apps/agents/pentest_agents/validator.py`
- Extended from 10 to 18 patterns
- Added: missing X-Frame-Options, CSRF on logout/search,
  rate limiting on non-critical, open redirect to self,
  CORS wildcard on public endpoints, missing SPF/DMARC without chain

### M2 ✅ Circuit Breaker Not Persistent
**File:** `apps/agents/pentest_agents/circuit_breaker.py`
- Added optional Redis persistence (falls back to memory gracefully)
- Redis key: `cb:{host}` with 15-minute TTL
- Exponential backoff: 60s → 120s → 240s → max 300s

### M3 ✅ Payload Magic Bytes Mixed Types
**File:** `apps/agents/pentest_agents/payloads.py`
- Changed from `bytes` objects to hex strings in dict
- Added PDF and ZIP magic bytes
- Usage: `bytes.fromhex(PAYLOADS["upload_magic_bytes"]["jpeg"])`

### M5 ✅ Brain Path Traversal
**File:** `apps/agents/pentest_agents/brain.py`
- `_brain_file()` validates resolved path is inside `BRAIN_DIR`
- BRAIN_DIR validated as absolute path at module init

### L2 ✅ Deprecated Kali Script
**File:** `scripts/install-kali-native.sh`
- Now exits with error code 1 and clear message
- Directs users to `scripts/install-ubuntu.sh`

### L3 ✅ Docker Dev Files Not in .gitignore
**File:** `.gitignore`
- Added: `docker-compose.dev.yml`, `docker-compose.local.yml`, `.env`, `.env.*`
- Added: `/var/lib/bbounty/brain/` (sensitive target history)

---

## Architecture Improvements

### A1 ✅ Centralized Rate Limit Config
**File:** `.env.example`
- All rate limits documented in one place with env vars

### A2 ✅ Unit Tests for pentest_agents
**Files:** `apps/agents/tests/test_validator.py`, `test_chain_builder.py`, `test_circuit_breaker.py`
- **25 tests, 25 passing**
- Coverage: 7-Question Gate, chain detection, circuit breaker behavior

### A3 ✅ Version Injection in Build
**File:** `Makefile`
- `make build` injects version via `-ldflags`
- `make deploy-check` = full pre-deploy checklist

---

## Test Results

```
============================= test session starts ==============================
collected 25 items

tests/test_chain_builder.py::TestChainDetection  6 PASSED
tests/test_circuit_breaker.py::TestCircuitBreaker  6 PASSED
tests/test_validator.py::TestNeverSubmitFilter     5 PASSED
tests/test_validator.py::TestSevenQuestions        6 PASSED
tests/test_validator.py::TestBatchValidate         2 PASSED

============================== 25 passed in 1.27s ==============================
```

## Python Syntax

```
✓ pentest_agents/__init__.py
✓ pentest_agents/brain.py
✓ pentest_agents/chain_builder.py
✓ pentest_agents/circuit_breaker.py
✓ pentest_agents/payloads.py
✓ pentest_agents/skills.py
✓ pentest_agents/validator.py
✓ specialist_agents/ultra_agent.py
✓ apps/ai-proxy/main.py
```

## Go Build

Go toolchain not available in audit environment.
Run before deploy:
```bash
make build   # injects version via ldflags
make vet     # go vet ./...
make test-race # go test -race ./...
```
