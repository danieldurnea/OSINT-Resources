package payloads

import "testing"

func TestAllCategoriesLoad(t *testing.T) {
	cats := AllCategories()
	if len(cats) != 10 {
		t.Fatalf("expected 10 categories, got %d", len(cats))
	}
	for _, c := range cats {
		p := Get(c)
		if len(p) < 40 {
			t.Errorf("category %q: expected 40+ payloads, got %d", c, len(p))
		}
		// no blank entries
		for i, line := range p {
			if line == "" {
				t.Errorf("category %q: blank payload at index %d", c, i)
			}
		}
	}
	if Total() < 300 {
		t.Errorf("expected 300+ total payloads, got %d", Total())
	}
	t.Logf("loaded %d payloads across %d categories", Total(), len(cats))
}

func TestParseCategory(t *testing.T) {
	if c, ok := ParseCategory("XSS"); !ok || c != XSS {
		t.Error("ParseCategory(XSS) failed")
	}
	if _, ok := ParseCategory("nonsense"); ok {
		t.Error("ParseCategory(nonsense) should fail")
	}
}

func TestWriteWordlists(t *testing.T) {
	written := map[string][]byte{}
	paths := WriteWordlists("/tmp/scan", func(name string, content []byte) error {
		written[name] = content
		return nil
	})
	if len(paths) != 10 {
		t.Fatalf("expected 10 wordlists written, got %d", len(paths))
	}
	if _, ok := written["payloads_xss.txt"]; !ok {
		t.Error("payloads_xss.txt not written")
	}
	if len(written["payloads_sqli.txt"]) == 0 {
		t.Error("sqli wordlist empty")
	}
}
