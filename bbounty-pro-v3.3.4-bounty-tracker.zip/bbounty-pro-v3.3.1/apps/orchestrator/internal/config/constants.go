// Package config — Centralised constants (Item #26).
//
// STATUS (v3.3.2): now wired into the codebase. 18 of the 20 constants are
// referenced from the packages that own the corresponding behaviour (auth token
// TTLs, invite TTL, findings TTL, checkpoint TTL, AI-analysis TTL, snapshot TTL,
// HTTP server timeouts, shutdown timeout, tool timeout/retries/concurrency,
// refresh rate window+max, notify min-interval, old-output age).
//
// Two constants are intentionally NOT wired because no call site is the same
// concept (wiring them would create a false semantic coupling on a coincidental
// number): DefaultRateLimit (the adaptive limiter uses platform-specific budgets
// 15/20/50/100, not a single default; tool rate flags are baked into bash
// command strings, not Go) and OldOutputCleanup (the only 6h literal is the
// SESSION janitor interval, a different concern from output cleanup). Leave them
// as documented intent until a genuine single owner exists.
package config

import "time"

const (
	AccessTokenTTL  = 15 * time.Minute
	RefreshTokenTTL = 7 * 24 * time.Hour
	InviteCodeTTL   = 48 * time.Hour
	FindingsTTL     = 72 * time.Hour
	SnapshotTTL     = 90 * 24 * time.Hour
	CheckpointTTL   = 24 * time.Hour
	AIAnalysisTTL   = 7 * 24 * time.Hour

	HTTPReadTimeout       = 10 * time.Second
	HTTPReadHeaderTimeout = 5 * time.Second
	HTTPIdleTimeout       = 120 * time.Second
	HTTPShutdownTimeout   = 30 * time.Second

	DefaultToolTimeout = 5 * time.Minute
	MaxToolRetries     = 2
	MaxConcurrentTools = 8

	DefaultRateLimit  = 30
	RateLimitWindow   = time.Hour
	MaxRefreshPerHour = 10

	OldOutputCleanup = 6 * time.Hour
	OldOutputAge     = 72 * time.Hour

	NotifyMinInterval = 5 * time.Minute
)
