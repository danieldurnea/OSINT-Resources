"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { cn } from "@/lib/utils";

// ── Types ─────────────────────────────────────────────────────────────────────

interface Message {
  role: "user" | "assistant";
  content: string;
  ts: number;
  error?: boolean;
}

interface GateResult {
  gate:   number;
  label:  string;
  passed: boolean;
  reason: string;
}

interface ROEContext {
  target:   string;
  program:  string;
  platform: string;
  scope:    string;
}

// ── Zen system prompt (from shared/index.ts) ──────────────────────────────────

const SYSTEM_PROMPT = `You are an elite Bug Bounty Hunter and Red Team Analyst operating under
the BountyHunter-Pro v2 methodology combined with the Zen-AI-Pentest framework,
running inside BBounty Pro v3.2.

BountyHunter-Pro v2 phases:
1. RECON & SCOPE VALIDATION
2. ASSET DISCOVERY (Subfinder → HTTPx)
3. PASSIVE ENUMERATION (Wayback + GAU)
4. ACTIVE SCANNING (Nuclei + Dalfox + SQLmap + FFuf)
5. VALIDATION — 7-Gate False Positive Filter
6. REPORT GENERATION — HackerOne-formatted CVSS 3.1 + PoC + business impact

7-GATE FALSE POSITIVE FILTER:
  Gate 1 — REPRODUCIBILITY : confidence > 80%
  Gate 2 — IMPACT          : severity >= Low, concrete scenario
  Gate 3 — EXPLOITABILITY  : PoC or CVE reference exists
  Gate 4 — BUSINESS LOGIC  : not info-only
  Gate 5 — IN SCOPE        : matches program boundaries
  Gate 6 — AUTH LOGIC      : not theoretical/speculative
  Gate 7 — UNIQUENESS      : not duplicate

SEVERITY = Exploitability × Impact × Context. Not by class alone.
Rules: authorized targets only. No weaponized payloads — safe curl/Python PoC only.`;

const QUICK_PROMPTS = [
  "Generate full recon pipeline for {{target}} with subfinder+amass+httpx chain",
  "Run 7-gate false positive analysis on the latest finding",
  "Map nuclei output to OWASP Top 10 (2021) with CWE references",
  "Write CVSS v3.1 vector + business impact for the highest severity finding",
  "What wafw00f bypass techniques work against Cloudflare for {{target}}?",
  "Draft a HackerOne P2 report for reflected XSS with curl PoC",
  "Build the full attack chain: .env exposure → credential reuse → RCE on {{target}}",
  "Explain the Zen enhanced_recon.py attack surface methodology",
];

// ── API client ────────────────────────────────────────────────────────────────

const AI_BASE = process.env.NEXT_PUBLIC_AI_PROXY_URL || "http://localhost:8001";

async function chatWithZen(
  messages: { role: string; content: string }[],
  system: string,
  signal: AbortSignal,
): Promise<string> {
  const res = await fetch(`${AI_BASE}/v1/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ system, messages }),
    signal,
  });
  if (!res.ok) throw new Error(`AI proxy error: HTTP ${res.status}`);
  const data = await res.json();
  return data.content || "(empty response)";
}

async function validateFinding(finding: any): Promise<{
  gates: GateResult[];
  gateScore: number;
  verdict: string;
}> {
  const res = await fetch(`${AI_BASE}/v1/validate-finding`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ finding }),
  });
  return res.json();
}

async function generatePoC(finding: any): Promise<string> {
  const res = await fetch(`${AI_BASE}/v1/generate-poc`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ finding }),
  });
  const data = await res.json();
  return data.content || "";
}

// ── Components ────────────────────────────────────────────────────────────────

function MsgRow({
  msg,
}: {
  msg: Message;
}) {
  if (msg.role === "user") {
    return (
      <div className="flex gap-2.5 mb-3.5">
        <span className="text-[9px] text-[#2a5a2a] font-bold flex-shrink-0 pt-0.5 tracking-wider">YOU</span>
        <div className="flex-1 bg-[#080f08] border border-[#1a3a1a] border-l-2 border-l-[#2a5a2a] px-3.5 py-2.5 text-[10px] text-[#5a7a5a] whitespace-pre-wrap leading-relaxed">
          {msg.content}
        </div>
      </div>
    );
  }
  return (
    <div className="flex gap-2.5 mb-3.5">
      <span
        className={cn(
          "text-[9px] font-bold flex-shrink-0 pt-0.5 tracking-wider",
          msg.error ? "text-red-500" : "text-[#a78bfa]",
        )}
      >
        ◈ ZEN
      </span>
      <div
        className={cn(
          "flex-1 border border-l-2 px-3.5 py-2.5 text-[10px] whitespace-pre-wrap leading-relaxed",
          msg.error
            ? "bg-[#1a0808] border-[#3a1a1a] border-l-red-500 text-[#aa6a6a]"
            : "bg-[#07070f] border-[#1a1a3a] border-l-[#a78bfa] text-[#b8b0d8]",
        )}
      >
        {msg.content}
      </div>
    </div>
  );
}

function GatePanel({ gates, score, verdict }: { gates: GateResult[]; score: number; verdict: string }) {
  const verdictColor =
    verdict === "SUBMIT" ? "#4ade80" : verdict === "INVESTIGATE" ? "#eab308" : "#ef4444";

  return (
    <div className="border border-[#1a1a3a] bg-[#07070f] p-3 my-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[9px] text-[#4a4a8a] tracking-widest font-bold">
          7-GATE FALSE POSITIVE FILTER
        </span>
        <div className="flex items-center gap-2">
          <span className="text-[9px] text-[#4a4a8a]">{score}/7 gates passed</span>
          <span
            className="text-[9px] font-bold px-2 py-0.5 border"
            style={{ color: verdictColor, borderColor: verdictColor + "40" }}
          >
            {verdict}
          </span>
        </div>
      </div>
      <div className="space-y-1">
        {gates.map((g) => (
          <div key={g.gate} className="flex items-start gap-2">
            <span className={cn("text-[9px] font-bold mt-0.5", g.passed ? "text-[#4ade80]" : "text-[#ef4444]")}>
              {g.passed ? "✓" : "✗"}
            </span>
            <div>
              <span className="text-[9px] text-[#4a4a8a]">G{g.gate} {g.label}</span>
              {g.reason && (
                <div className="text-[9px] text-[#3a3a5a] mt-0.5">{g.reason}</div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

interface Props {
  roe?: ROEContext;
}

export function AIAgent({ roe }: Props) {
  const [msgs, setMsgs]       = useState<Message[]>([]);
  const isMounted = useRef(true); // FIX: guard state updates after unmount
  const [input, setInput]     = useState("");
  const [loading, setLoading] = useState(false);
  const [gates, setGates]     = useState<{ gates: GateResult[]; score: number; verdict: string } | null>(null);
  const [proxyOk, setProxyOk] = useState<boolean | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const listRef  = useRef<HTMLDivElement>(null);
  const msgsRef  = useRef<Message[]>([]); // FIX: always-current msgs for closures

  // Check proxy health on mount
  useEffect(() => {
    fetch(`${AI_BASE}/health`)
      .then((r) => setProxyOk(r.ok))
      .catch(() => setProxyOk(false));
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: 9e9, behavior: "smooth" });
  }, [msgs, loading]);

  const pushMsg = (msg: Message) =>
    setMsgs((prev) => {
      const next = [...prev, msg];
      msgsRef.current = next; // FIX: keep ref in sync
      return next;
    });

  const ask = useCallback(async (userMsg: string) => {
    if (!userMsg.trim() || loading) return;
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    const now = Date.now();
    const userMessage: Message = { role: "user", content: userMsg, ts: now };
    setMsgs((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);
    setGates(null);

    // Inject ROE context into system prompt
    const sessionCtx = roe
      ? `\n\nSESSION CONTEXT: Target=${roe.target} | Program=${roe.program} | Platform=${roe.platform} | Authorization=CONFIRMED | Scope=${roe.scope}`
      : "";
    const system = SYSTEM_PROMPT + sessionCtx;

    // FIX: use msgsRef.current (always latest) instead of msgs (stale closure)
    const conv = [...msgsRef.current, userMessage].map((m) => ({ role: m.role, content: m.content }));

    try {
      const content = await chatWithZen(conv, system, ctrl.signal);
      pushMsg({ role: "assistant", content, ts: Date.now() });
    } catch (e: any) {
      if (e.name !== "AbortError") {
        pushMsg({
          role: "assistant",
          content: `⚠ AI error: ${e.message}. Check AI proxy at ${AI_BASE}/health`,
          error: true,
          ts: Date.now(),
        });
      }
    } finally {
      setLoading(false);
    }
  }, [loading, roe]); // FIX: msgs removed — using msgsRef.current instead

  const runGateFilter = useCallback(async (finding: any) => {
    setLoading(true);
    try {
      const result = await validateFinding(finding);
      setGates({ gates: result.gates, score: result.gateScore, verdict: result.verdict });
      pushMsg({
        role: "assistant",
        content: `7-Gate analysis complete: ${result.gateScore}/7 gates passed. Verdict: ${result.verdict}`,
        ts: Date.now(),
      });
    } catch (e: any) {
      pushMsg({ role: "assistant", content: `⚠ Gate filter error: ${e.message}`, error: true, ts: Date.now() });
    } finally {
      setLoading(false);
    }
  }, []);

  const quickPrompts = QUICK_PROMPTS.map((p) => p.replace("{{target}}", roe?.target || "target"));

  return (
    <div className="flex flex-col h-full bg-[#04040a]">
      {/* Header */}
      <div className="px-5 py-2.5 border-b border-[#1a1a2a] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[9px] text-[#a78bfa] font-bold tracking-widest">◈ ZEN-AI AGENT</span>
          <span className="text-[9px] text-[#2a2a4a]">·</span>
          <span className="text-[9px] text-[#2a2a4a]">BountyHunter-Pro v2 + Zen Framework</span>
        </div>
        <div className="flex items-center gap-3">
          {roe?.target && (
            <span className="text-[9px] text-[#2a5a2a] border border-[#1a3a1a] px-2 py-0.5">
              TARGET: {roe.target}
            </span>
          )}
          <div
            className="w-1.5 h-1.5 rounded-full"
            style={{
              background: proxyOk === null ? "#4a4a5a" : proxyOk ? "#4ade80" : "#ef4444",
            }}
            title={proxyOk === null ? "Checking..." : proxyOk ? "AI proxy online" : "AI proxy offline"}
          />
        </div>
      </div>

      {/* Messages */}
      <div ref={listRef} className="flex-1 overflow-y-auto px-4 py-3.5">
        {msgs.length === 0 && (
          <div className="py-10 text-center">
            <div className="text-[9px] text-[#1a2a3a] tracking-[0.15em] mb-4 uppercase">
              Zen-AI Agent · Claude · Bug Bounty Specialist
            </div>
            {!proxyOk && proxyOk !== null && (
              <div className="mb-4 text-[9px] text-red-500 border border-red-900 bg-red-950/30 px-3 py-2 inline-block">
                ⚠ AI proxy offline at {AI_BASE} — start with: uvicorn apps/ai-proxy/main:app --port 8001
              </div>
            )}
            <div className="flex flex-wrap gap-1.5 justify-center max-w-lg mx-auto">
              {quickPrompts.map((s) => (
                <button
                  key={s}
                  onClick={() => ask(s)}
                  className="px-2.5 py-1.5 text-[8.5px] cursor-pointer border border-[#1a1a2a] bg-transparent text-[#2a4a2a] tracking-[0.04em] text-left hover:border-[#a78bfa30] hover:text-[#5a5a9a] transition-colors"
                >
                  ▶ {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {msgs.map((m, i) => <MsgRow key={i} msg={m} />)}

        {gates && (
          <GatePanel gates={gates.gates} score={gates.score} verdict={gates.verdict} />
        )}

        {loading && (
          <div className="flex gap-2.5 items-center">
            <span className="text-[9px] text-[#a78bfa] font-bold">◈ ZEN</span>
            <div className="bg-[#07070f] border border-[#1a1a3a] border-l-2 border-l-[#a78bfa] px-3.5 py-2.5 flex gap-2 items-center">
              {[0, 1, 2].map((n) => (
                <div
                  key={n}
                  className="w-1 h-1 bg-[#a78bfa] animate-bounce"
                  style={{ animationDelay: `${n * 0.15}s` }}
                />
              ))}
              <span className="text-[8.5px] text-[#2a2a4a] tracking-[0.1em]">ANALYZING…</span>
            </div>
          </div>
        )}
      </div>

      {/* Action bar */}
      <div className="border-t border-[#1a1a2a] px-4 py-2 flex gap-2 bg-[#06060e]">
        <button
          onClick={() => runGateFilter({ type: "XSS", severity: "HIGH", target: roe?.target || "", tool: "dalfox", evidence: "reflected in response", confidence: 85 })}
          className="text-[8.5px] px-2 py-1 border border-[#1a1a3a] text-[#4a4a7a] hover:text-[#a78bfa] hover:border-[#a78bfa40] transition-colors"
          title="Run 7-Gate filter on a sample finding"
        >
          7-GATE
        </button>
        <button
          onClick={() => { setMsgs([]); setGates(null); }}
          className="text-[8.5px] px-2 py-1 border border-[#1a1a2a] text-[#3a3a5a] hover:text-[#ef4444] hover:border-[#ef444430] transition-colors"
        >
          CLEAR
        </button>
      </div>

      {/* Input */}
      <div className="border-t border-[#1a1a2a] px-4 py-2.5 bg-[#07080c]">
        <div className="flex gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                ask(input);
              }
            }}
            placeholder="Ask the Zen AI agent (Enter to send, Shift+Enter newline)"
            className="flex-1 min-h-14 max-h-28 resize-none text-[10px] leading-relaxed bg-transparent text-[#8070b0] border-0 outline-none"
            style={{
              borderLeft: `2px solid ${input ? "#a78bfa" : "#1a1a3a"}`,
              paddingLeft: "10px",
            }}
          />
          <button
            onClick={() => ask(input)}
            disabled={!input.trim() || loading}
            className={cn(
              "px-3.5 py-2 text-[9.5px] font-bold tracking-[0.1em] border transition-colors",
              input.trim() && !loading
                ? "border-[#a78bfa] bg-[#a78bfa15] text-[#a78bfa] cursor-pointer hover:bg-[#a78bfa25]"
                : "border-[#1a1a2a] bg-transparent text-[#2a2a3a] cursor-not-allowed",
            )}
          >
            {loading ? "…" : "► SEND"}
          </button>
        </div>
      </div>
    </div>
  );
}
