package tools

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/google/uuid"
)

// ── Nuclei ────────────────────────────────────────────────────────────────────

type nucleiLine struct {
	TemplateID string `json:"template-id"`
	Info       struct {
		Name           string   `json:"name"`
		Severity       string   `json:"severity"`
		Description    string   `json:"description"`
		Tags           []string `json:"tags"`
		Classification struct {
			CVSSScore  float64  `json:"cvss-score"`
			CVSSVector string   `json:"cvss-metrics"`
			CWEIDs     []string `json:"cwe-ids"`
		} `json:"classification"`
	} `json:"info"`
	Host             string   `json:"host"`
	Matched          string   `json:"matched"`
	ExtractedResults []string `json:"extracted-results"`
	Timestamp        string   `json:"timestamp"`
}

// ParseNucleiOutput parses nuclei JSONL output (one JSON object per line).
func ParseNucleiOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	var out []*findings.Finding
	scanner := bufio.NewScanner(r)
	scanner.Buffer(make([]byte, 1<<20), 1<<20) // 1 MB line buffer

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || line == "[" || line == "]" {
			continue
		}
		line = strings.TrimSuffix(line, ",") // handle JSON array format

		var n nucleiLine
		if err := json.Unmarshal([]byte(line), &n); err != nil {
			continue // skip progress bars, log lines, etc.
		}

		sev := normaliseSeverity(n.Info.Severity)

		var cvss *float64
		if n.Info.Classification.CVSSScore > 0 {
			v := n.Info.Classification.CVSSScore
			cvss = &v
		}

		url := n.Host
		if n.Matched != "" && n.Matched != n.Host {
			url = n.Matched
		}

		f := &findings.Finding{
			ID:         uuid.New().String(),
			ScanID:     scanID,
			Title:      fmt.Sprintf("[%s] %s", n.TemplateID, n.Info.Name),
			URL:        url,
			Severity:   findings.Severity(sev),
			Category:   categoryFromTags(n.Info.Tags),
			Status:     findings.StatusNew,
			CVSS:       cvss,
			CVSSVector: n.Info.Classification.CVSSVector,
			Source:     toolID,
			CreatedAt:  time.Now(),
			UpdatedAt:  time.Now(),
		}
		if n.Info.Description != "" {
			f.AIAnalysis = "[nuclei] " + n.Info.Description
		}
		if len(n.ExtractedResults) > 0 {
			// FIXED: use local clamp helper, not Go 1.21 min() builtin for clarity
			end := clamp(len(n.ExtractedResults), 0, 3)
			f.Response = strings.Join(n.ExtractedResults[:end], "\n")
		}
		out = append(out, f)
	}
	return out, scanner.Err()
}

// ── Dalfox (XSS) ─────────────────────────────────────────────────────────────

// ParseDalfoxOutput parses dalfox JSON or heuristic text output.
func ParseDalfoxOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	var out []*findings.Finding
	scanner := bufio.NewScanner(r)

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		var row struct {
			Type  string `json:"type"`
			URL   string `json:"url"`
			Param string `json:"param"`
			Data  string `json:"data"`
		}
		if err := json.Unmarshal([]byte(line), &row); err == nil && row.URL != "" {
			out = append(out, &findings.Finding{
				ID: uuid.New().String(), ScanID: scanID,
				Title: fmt.Sprintf("Cross-Site Scripting (XSS) — %s", row.Param),
				URL:   row.URL, Severity: findings.SeverityHigh,
				Category: "XSS", Parameter: row.Param, Payload: row.Data,
				Status: findings.StatusNew, Source: toolID,
				CreatedAt: time.Now(), UpdatedAt: time.Now(),
			})
			continue
		}

		// Heuristic: lines with [POC] or VULN
		if strings.Contains(line, "[POC]") || strings.Contains(line, "VULN") {
			if u := extractURL(line); u != "" {
				out = append(out, &findings.Finding{
					ID: uuid.New().String(), ScanID: scanID,
					Title: "Cross-Site Scripting (XSS)",
					URL:   u, Severity: findings.SeverityHigh,
					Category: "XSS", Status: findings.StatusNew, Source: toolID,
					Response:  truncateLine(line, 500),
					CreatedAt: time.Now(), UpdatedAt: time.Now(),
				})
			}
		}
	}
	return out, scanner.Err()
}

// ── Gitleaks ──────────────────────────────────────────────────────────────────

type gitleaksEntry struct {
	Description string `json:"Description"`
	StartLine   int    `json:"StartLine"`
	File        string `json:"File"`
	Secret      string `json:"Secret"`
	RuleID      string `json:"RuleID"`
}

// ParseGitleaksOutput parses the gitleaks JSON report.
func ParseGitleaksOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	var leaks []gitleaksEntry
	if err := json.NewDecoder(r).Decode(&leaks); err != nil {
		return nil, nil // empty or not JSON
	}
	out := make([]*findings.Finding, 0, len(leaks))
	for _, l := range leaks {
		out = append(out, &findings.Finding{
			ID: uuid.New().String(), ScanID: scanID,
			Title:    fmt.Sprintf("Secret Exposed — %s", l.RuleID),
			URL:      l.File,
			Severity: findings.SeverityCritical,
			Category: "Secrets", Status: findings.StatusNew, Source: toolID,
			Response:  fmt.Sprintf("Line %d: %s", l.StartLine, maskSecret(l.Secret)),
			CreatedAt: time.Now(), UpdatedAt: time.Now(),
		})
	}
	return out, nil
}

// ── CORS (Corsy) ──────────────────────────────────────────────────────────────

func ParseCorsyOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	var out []*findings.Finding
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, "Vulnerable") || strings.Contains(line, "Origin:") {
			if u := extractURL(line); u != "" {
				out = append(out, &findings.Finding{
					ID: uuid.New().String(), ScanID: scanID,
					Title: "CORS Misconfiguration",
					URL:   u, Severity: findings.SeverityHigh,
					Category: "CORS", Status: findings.StatusNew, Source: toolID,
					Response:  truncateLine(line, 500),
					CreatedAt: time.Now(), UpdatedAt: time.Now(),
				})
			}
		}
	}
	return out, scanner.Err()
}

// ── HTTP Request Smuggling (smuggler) ─────────────────────────────────────────

func ParseSmugglerOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	var out []*findings.Finding
	seen := make(map[string]bool)
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, "VULNERABLE") || strings.Contains(line, "Possible") {
			u := extractURL(line)
			if u == "" || seen[u] {
				continue
			}
			seen[u] = true
			out = append(out, &findings.Finding{
				ID: uuid.New().String(), ScanID: scanID,
				Title: "HTTP Request Smuggling",
				URL:   u, Severity: findings.SeverityCritical,
				Category: "HTTP Smuggling", Status: findings.StatusNew, Source: toolID,
				Response:  truncateLine(line, 500),
				CreatedAt: time.Now(), UpdatedAt: time.Now(),
			})
		}
	}
	return out, scanner.Err()
}

// ── Generic fallback ──────────────────────────────────────────────────────────

func ParseGenericOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	patterns := []struct {
		needle   string
		title    string
		sev      findings.Severity
		category string
	}{
		{"SQL syntax", "SQL Injection", findings.SeverityCritical, "SQLi"},
		{"error in your SQL", "SQL Injection", findings.SeverityCritical, "SQLi"},
		{"<script>", "Cross-Site Scripting (XSS)", findings.SeverityHigh, "XSS"},
		{"SSRF", "SSRF Vulnerability", findings.SeverityHigh, "SSRF"},
		{"command not found", "Possible RCE", findings.SeverityCritical, "RCE"},
		{"[CRITICAL]", "Critical Finding", findings.SeverityCritical, "Misc"},
		{"[HIGH]", "High Severity Finding", findings.SeverityHigh, "Misc"},
	}

	var out []*findings.Finding
	seen := make(map[string]bool)
	scanner := bufio.NewScanner(r)

	for scanner.Scan() {
		line := scanner.Text()
		for _, p := range patterns {
			if !strings.Contains(line, p.needle) {
				continue
			}
			u := extractURL(line)
			key := p.title + u
			if seen[key] {
				continue
			}
			seen[key] = true
			out = append(out, &findings.Finding{
				ID: uuid.New().String(), ScanID: scanID,
				Title: p.title, URL: u,
				Severity: p.sev, Category: p.category,
				Status: findings.StatusNew, Source: toolID,
				Response:  truncateLine(line, 500),
				CreatedAt: time.Now(), UpdatedAt: time.Now(),
			})
		}
	}
	return out, scanner.Err()
}

// ── Dispatcher ────────────────────────────────────────────────────────────────

// Parse routes tool output to the correct parser implementation.

// ── Vigolium ──────────────────────────────────────────────────────────────────
// Vigolium outputs one JSON object per line with --format jsonl.
// Schema based on vigolium v1 finding model (docs.vigolium.com/api-references/findings).
// SCOPE-F: AGPL-3.0 tool — invoked as subprocess only, not linked.

type vigoliumFinding struct {
	ID          string   `json:"id"`
	Module      string   `json:"module"`
	Title       string   `json:"title"`
	Severity    string   `json:"severity"`
	URL         string   `json:"url"`
	Method      string   `json:"method"`
	Parameter   string   `json:"parameter"`
	Payload     string   `json:"payload"`
	Evidence    string   `json:"evidence"`
	Description string   `json:"description"`
	CVSS        float64  `json:"cvss"`
	CVSSVector  string   `json:"cvss_vector"`
	Tags        []string `json:"tags"`
	Timestamp   string   `json:"timestamp"`
}

// ParseVigoliumOutput parses vigolium JSONL output (--format jsonl).
// Each line is a self-contained finding JSON object.
// Lines that fail JSON decode are silently skipped (progress / log lines).
func ParseVigoliumOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	var out []*findings.Finding
	scanner := bufio.NewScanner(r)
	scanner.Buffer(make([]byte, 1<<20), 1<<20) // 1 MB line buffer

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		var v vigoliumFinding
		if err := json.Unmarshal([]byte(line), &v); err != nil {
			continue // skip progress bars, log lines, non-JSON output
		}
		// Require at minimum a URL and a title to form a valid finding.
		if v.URL == "" || v.Title == "" {
			continue
		}

		sev := normaliseSeverity(v.Severity)

		var cvss *float64
		if v.CVSS > 0 {
			cvssVal := v.CVSS
			cvss = &cvssVal
		}

		tags := append([]string{"vigolium"}, v.Tags...)

		out = append(out, &findings.Finding{
			ID:         uuid.New().String(),
			ScanID:     scanID,
			Title:      fmt.Sprintf("[vigolium/%s] %s", v.Module, v.Title),
			URL:        v.URL,
			Severity:   findings.Severity(sev),
			Category:   "dast",
			Parameter:  v.Parameter,
			Payload:    v.Payload,
			Response:   v.Evidence,
			CVSS:       cvss,
			CVSSVector: v.CVSSVector,
			Source:     toolID,
			Tags:       tags,
			CreatedAt:  time.Now().UTC(),
			UpdatedAt:  time.Now().UTC(),
		})
	}
	if err := scanner.Err(); err != nil {
		return out, fmt.Errorf("vigolium output scan: %w", err)
	}
	return out, nil
}

// ── afrog ─────────────────────────────────────────────────────────────────────

// afrogResult is the per-finding object in afrog's `-json` output. afrog writes
// a JSON *array* of these to the file given by -json. The default (-json, not
// -json-all) emits: target, fulltarget, id, and the info sub-object. See
// https://github.com/zan8in/afrog/wiki/Usage (Output section).
type afrogResult struct {
	Target     string `json:"target"`
	FullTarget string `json:"fulltarget"`
	ID         string `json:"id"`
	Info       struct {
		Name        string   `json:"name"`
		Author      string   `json:"author"`
		Severity    string   `json:"severity"`
		Description string   `json:"description"`
		Reference   []string `json:"reference"`
	} `json:"info"`
}

// ParseAfrogOutput parses afrog's `-json` file content (a JSON array of results).
//
// IMPORTANT: afrog updates this file in real time and only appends the closing
// `]` once the scan completes (documented upstream). The pipeline parses this
// AFTER the afrog process exits, so the array is normally well-formed — but we
// tolerate a missing trailing `]` defensively in case the file is read early or
// the process was killed mid-scan.
func ParseAfrogOutput(r io.Reader, scanID, toolID string) ([]*findings.Finding, error) {
	raw, err := io.ReadAll(r)
	if err != nil {
		return nil, fmt.Errorf("afrog read: %w", err)
	}
	trimmed := strings.TrimSpace(string(raw))
	if trimmed == "" {
		return nil, nil
	}
	// Tolerate afrog's incremental writes: a partial array may be missing its
	// closing bracket (and possibly end on a trailing comma).
	if strings.HasPrefix(trimmed, "[") && !strings.HasSuffix(trimmed, "]") {
		trimmed = strings.TrimRight(trimmed, " \t\r\n,")
		trimmed += "]"
	}

	var results []afrogResult
	if err := json.Unmarshal([]byte(trimmed), &results); err != nil {
		// Not a valid array even after repair — nothing usable.
		return nil, fmt.Errorf("afrog json parse: %w", err)
	}

	var out []*findings.Finding
	for _, res := range results {
		url := res.FullTarget
		if url == "" {
			url = res.Target
		}
		title := res.Info.Name
		if title == "" {
			title = res.ID
		}
		if url == "" || title == "" {
			continue // not enough to form a meaningful finding
		}

		desc := res.Info.Description
		if len(res.Info.Reference) > 0 {
			if desc != "" {
				desc += " "
			}
			desc += "Refs: " + strings.Join(res.Info.Reference, ", ")
		}

		out = append(out, &findings.Finding{
			ID:        uuid.New().String(),
			ScanID:    scanID,
			Title:     fmt.Sprintf("[afrog/%s] %s", res.ID, title),
			URL:       url,
			Severity:  findings.Severity(normaliseSeverity(res.Info.Severity)),
			Category:  "cve",
			Response:  truncateLine(desc, 2000),
			Source:    toolID,
			Tags:      []string{"afrog", res.ID},
			CreatedAt: time.Now().UTC(),
			UpdatedAt: time.Now().UTC(),
		})
	}
	return out, nil
}

func Parse(toolID string, r io.Reader, scanID string) ([]*findings.Finding, error) {
	switch toolID {
	case "nuclei":
		return ParseNucleiOutput(r, scanID, toolID)
	case "nuclei-fuzz":
		// nuclei-fuzz emits the same JSON format as nuclei (it IS nuclei -dast).
		return ParseNucleiOutput(r, scanID, toolID)
	case "dalfox":
		return ParseDalfoxOutput(r, scanID, toolID)
	case "gitleaks":
		return ParseGitleaksOutput(r, scanID, toolID)
	case "corsy":
		return ParseCorsyOutput(r, scanID, toolID)
	case "smuggler":
		return ParseSmugglerOutput(r, scanID, toolID)
	case "vigolium":
		return ParseVigoliumOutput(r, scanID, toolID)
	case "afrog":
		return ParseAfrogOutput(r, scanID, toolID)
	default:
		return ParseGenericOutput(r, scanID, toolID)
	}
}

// ── Helpers ───────────────────────────────────────────────────────────────────

func normaliseSeverity(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	if s == "informational" {
		return "info"
	}
	switch s {
	case "critical", "high", "medium", "low", "info":
		return s
	default:
		return "info"
	}
}

func categoryFromTags(tags []string) string {
	priority := []string{
		"sqli", "xss", "ssrf", "rce", "lfi", "xxe", "idor",
		"cors", "csrf", "ssti", "jwt", "auth", "exposure",
		"misconfig", "takeover", "cve",
	}
	tagSet := make(map[string]bool, len(tags))
	for _, t := range tags {
		tagSet[strings.ToLower(t)] = true
	}
	for _, p := range priority {
		if tagSet[p] {
			return strings.ToUpper(p)
		}
	}
	if len(tags) > 0 {
		return strings.ToUpper(tags[0])
	}
	return "Misc"
}

func extractURL(line string) string {
	for _, prefix := range []string{"https://", "http://"} {
		idx := strings.Index(line, prefix)
		if idx < 0 {
			continue
		}
		u := line[idx:]
		for _, stop := range " \t\"')]}" {
			if i := strings.IndexRune(u, stop); i > 0 {
				u = u[:i]
			}
		}
		return u
	}
	return ""
}

func maskSecret(s string) string {
	if len(s) <= 8 {
		return "****"
	}
	return s[:4] + strings.Repeat("*", len(s)-8) + s[len(s)-4:]
}

// truncateLine truncates a line to maxLen bytes.
// FIXED: named clamp to avoid conflict with Go 1.21 min/max builtins.
func truncateLine(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen]
}

// clamp returns v clamped to [lo, hi].
func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
