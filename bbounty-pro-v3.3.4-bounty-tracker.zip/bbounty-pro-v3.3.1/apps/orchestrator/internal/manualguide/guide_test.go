package manualguide

import (
	"strings"
	"testing"
)

func TestGenerate_CoreSectionsAlwaysPresent(t *testing.T) {
	g := Generate(Signals{Domain: "example.com"})
	for _, must := range []string{
		"Manual Bug Bounty Guide — example.com",
		"## 1. Authentication",
		"## 3. SQL injection",
		"## 5. SSRF",
		"## 7. API security",
		"## 9. Sensitive data exposure",
		"Reporting format",
		"authorized scope",
	} {
		if !strings.Contains(g, must) {
			t.Errorf("guide missing core section/text: %q", must)
		}
	}
	// base URL default applied
	if !strings.Contains(g, "https://example.com") {
		t.Error("expected default base URL https://example.com")
	}
}

func TestGenerate_AdaptsToWordPress(t *testing.T) {
	with := Generate(Signals{Domain: "blog.example.com", Technologies: []string{"WordPress", "PHP"}})
	if !strings.Contains(with, "### WordPress") {
		t.Error("WordPress tips should appear when WordPress detected")
	}
	if !strings.Contains(with, "wp-json/wp/v2/users") {
		t.Error("expected WordPress user-enum tip")
	}
	without := Generate(Signals{Domain: "x.example.com", Technologies: []string{"nginx"}})
	if strings.Contains(without, "### WordPress") {
		t.Error("WordPress tips must NOT appear when not detected")
	}
}

func TestGenerate_WAFConditional(t *testing.T) {
	with := Generate(Signals{Domain: "e.com", WAF: "Cloudflare"})
	if !strings.Contains(with, "WAF (Cloudflare)") {
		t.Error("WAF section should appear when WAF detected")
	}
	// honest framing: must not promote defeating logging
	if !strings.Contains(with, "Do NOT attempt to defeat logging") {
		t.Error("WAF section must keep the authorized-testing guardrail")
	}
	none := Generate(Signals{Domain: "e.com", WAF: "Unknown"})
	if strings.Contains(none, "WAF (Unknown)") {
		t.Error("no WAF section for Unknown")
	}
}

func TestGenerate_FollowUpsFromFindings(t *testing.T) {
	g := Generate(Signals{Domain: "e.com", FindingCategs: []string{"xss", "secret"}})
	if !strings.Contains(g, "Prioritised follow-ups") {
		t.Error("expected follow-ups section when findings present")
	}
	if !strings.Contains(g, "XSS already flagged") || !strings.Contains(g, "Secrets found") {
		t.Error("expected category-specific follow-ups for xss and secret")
	}
}
