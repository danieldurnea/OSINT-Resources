# Skill: cloud-security

> Auto-generated metadata. Edit this file to override the built-in skill prompt.

## Activation
This skill is active when the orchestrator routes a scan with skill=cloud-security.

## Tools required
See registry.go for the canonical tool list per skill.

## Execution Notes
- Runtime is determined in registry.go (Go-native or Python via specialist_agents)
- Output is structured JSON matching the OutputSchema field
- All findings are persisted via the findings store

## Override
Add custom prompt content below — it will be appended to the built-in
SystemPrompt at orchestrator startup via Registry.LoadFromDisk().

