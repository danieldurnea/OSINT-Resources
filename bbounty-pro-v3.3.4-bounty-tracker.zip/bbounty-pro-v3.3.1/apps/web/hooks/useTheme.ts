"use client";
import { useEffect, useState } from "react";

// Item #25: Theme toggle hook.
// LIMITATION: Persists in localStorage (not synced across devices).

export type Theme = "dark" | "light" | "system";

export function useTheme() {
  const [theme, setTheme] = useState<Theme>("dark");

  useEffect(() => {
    const stored = localStorage.getItem("bbounty_theme") as Theme | null;
    if (stored) setTheme(stored);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const resolved = theme === "system"
      ? (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")
      : theme;
    root.classList.toggle("dark", resolved === "dark");
    root.classList.toggle("light", resolved === "light");
    localStorage.setItem("bbounty_theme", theme);
  }, [theme]);

  return { theme, setTheme };
}
