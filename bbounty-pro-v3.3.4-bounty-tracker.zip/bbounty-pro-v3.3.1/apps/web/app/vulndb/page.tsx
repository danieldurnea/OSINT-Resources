import VulnDatabase from "@/components/vulndb/VulnDatabase";

export const metadata = {
  title: "Vulnerability Database — BBounty Pro",
};

export default function VulnDBPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-4xl">
        <VulnDatabase />
      </div>
    </main>
  );
}
