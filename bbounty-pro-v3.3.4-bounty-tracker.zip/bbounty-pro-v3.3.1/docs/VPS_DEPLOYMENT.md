# VPS Deployment Guide — BBounty Pro v3 Merged

> Production-ready deployment on Ubuntu 22.04+ / Debian 12+ VPS.
> Tested on Hetzner CX21, DigitalOcean 4GB, Linode 4GB.
> **Will NOT run on localhost** — see ALLOW_LOCAL flag for development.

---

## Prerequisites

- VPS with **public IP** (Hetzner, DigitalOcean, Linode, OVH, etc.)
- Ubuntu 22.04+ or Debian 12+
- 4 GB RAM minimum (8 GB recommended)
- 40 GB disk minimum
- Domain pointed to VPS IP (for HTTPS — required in production)

---

## One-Command Install

```bash
# As root or with sudo
curl -fsSL https://raw.githubusercontent.com/your-org/bbounty-pro/main/scripts/install-vps.sh | bash
```

This script:
1. Installs Docker + Docker Compose
2. Installs UFW firewall and configures rules
3. Installs Caddy reverse proxy with auto-SSL
4. Clones BBounty Pro to /opt/bbounty-pro
5. Generates JWT_SECRET automatically
6. Prompts for ANTHROPIC_API_KEY and domain
7. Starts the full stack

---

## Manual Install (Step-by-Step)

### 1. System hardening

```bash
# Update + base packages
apt update && apt upgrade -y
apt install -y ufw fail2ban unattended-upgrades curl git

# Auto-security updates
dpkg-reconfigure --priority=low unattended-upgrades

# Firewall: only SSH + HTTPS
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# Fail2ban with sane defaults
systemctl enable --now fail2ban

# Disable root SSH login (use a non-root user with sudo + key)
# Edit /etc/ssh/sshd_config:
#   PermitRootLogin no
#   PasswordAuthentication no
# Then: systemctl restart sshd
```

### 2. Install Docker

```bash
curl -fsSL https://get.docker.com | bash
usermod -aG docker $USER
# Log out and back in
```

### 3. Clone and configure

```bash
cd /opt
git clone https://github.com/your-org/bbounty-pro.git
cd bbounty-pro
cp .env.example .env

# Generate strong secrets
sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$(openssl rand -hex 32)|" .env
sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$(openssl rand -hex 24)|" .env

# Required: edit .env and set:
#   ANTHROPIC_API_KEY=sk-ant-...
#   FRONTEND_URL=https://bounty.yourdomain.com
#   VPS_DOMAIN=bounty.yourdomain.com
nano .env
```

### 4. Install Caddy reverse proxy (automatic HTTPS)

```bash
apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | \
  gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | \
  tee /etc/apt/sources.list.d/caddy-stable.list
apt update && apt install -y caddy

# Configure Caddy
cat > /etc/caddy/Caddyfile << 'EOF'
bounty.yourdomain.com {
    reverse_proxy /api/* localhost:8080
    reverse_proxy /ws/* localhost:8080
    reverse_proxy /auth/* localhost:8080
    reverse_proxy /healthz localhost:8080
    reverse_proxy /* localhost:3000

    # Security headers
    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
        X-Content-Type-Options "nosniff"
        X-Frame-Options "DENY"
        Referrer-Policy "strict-origin-when-cross-origin"
        Permissions-Policy "geolocation=(), microphone=(), camera=()"
        -Server
    }

    # Rate limit auth endpoints
    @auth path /auth/login /auth/register
    rate_limit @auth 10r/m

    # Compress responses
    encode gzip zstd
}
EOF

# Replace bounty.yourdomain.com with your actual domain
sed -i "s|bounty.yourdomain.com|YOUR_DOMAIN|g" /etc/caddy/Caddyfile

systemctl enable --now caddy
```

### 5. Start the stack

```bash
cd /opt/bbounty-pro
docker compose -f infra/docker-compose.yml up -d

# Verify health
curl https://your-domain.com/healthz
# Expected: {"status":"ok","version":"3.0.0-MERGED","public_ip":"..."}
```

### 6. First-time setup

```bash
# Open in browser
open https://your-domain.com

# 1. Click Register
# 2. First account is automatically promoted to admin
# 3. Set up team via /team page (generate invite codes)
# 4. Confirm ROE before first scan
```

---

## VPS Enforcement (Why)

The orchestrator refuses to start on localhost by default. This prevents:

- Bug bounty scanning from residential IPs (ISP complaints, IP bans)
- Accidental exposure to LAN if firewall misconfigured
- Tools resolving to local network ranges

**To override (development only):**

```bash
ALLOW_LOCAL=true docker compose up
```

This disables:
- VPS interface check
- Public IP requirement
- Loopback bind rejection

Never set ALLOW_LOCAL=true in production.

---

## Tool Container

All 100+ security tools run inside a dedicated **Kali container** (`bbounty-kali`),
not on the host. Benefits:

- Tools cannot affect host system
- Consistent tool versions across deployments
- No conflicts with host package manager
- Easy update path: rebuild image only

The Go orchestrator shells into the Kali container via `docker exec` when
DOCKER_MODE=true. This is the default.

---

## Skills & Agents

The 8 skill modules (bug bounty / web pentest scope) are integrated:

| Skill | Runtime | Description |
|---|---|---|
| api-security | Go | OWASP API Top 10 + GraphQL |
| bug-bounty | Go | HackerOne-optimised hunting (full pipeline) |
| cloud-security | Go | S3/Blob/GCS exposure, dangling-DNS takeover |
| exploit-dev | Go | Educational PoC generation (BB-scope, minimal) |
| network-security | Go | Port scan + exposed services |
| osint | Mixed | Passive intel gathering |
| report-writing | Go | CVSS 3.1 + CWE references |
| web-audit | Go | OWASP WSTG |

Python skills run via `apps/agents/specialist_agents/agent.py` inside the
orchestrator container. Go skills run inline.

Out-of-scope skills removed in v3.3.1 cleanup: red-team, threat-intel,
malware-analysis, mobile-security, iot-security, social-engineering,
devops-security — these are not bug bounty / applied web pentest scope,
or had stub implementations that duplicated capabilities in remaining skills.

---

## Maintenance

```bash
# View logs
docker compose -f infra/docker-compose.yml logs -f orchestrator

# Update
cd /opt/bbounty-pro
git pull
docker compose -f infra/docker-compose.yml up -d --build

# Backup
docker compose exec redis redis-cli BGSAVE
cp /opt/bbounty-pro/redis-data/dump.rdb /backup/redis-$(date +%F).rdb

# Health check (cron)
*/5 * * * * curl -sf https://your-domain.com/healthz || systemctl restart bbounty
```

---

## Troubleshooting

### "VPS enforcement check failed"
You're on localhost. Either:
- Deploy to a real VPS, OR
- Set `ALLOW_LOCAL=true` in `.env` for development

### "no public network interface detected"
The VPS has no public IPv4. Check:
```bash
ip -4 addr show | grep -v lo
```

### "JWT_SECRET required"
Generate one:
```bash
openssl rand -hex 32 | tr -d '\n' | xargs -I {} sed -i "s|^JWT_SECRET=.*|JWT_SECRET={}|" .env
```

### "Cannot reach internet"
Docker bridge network broken. Restart Docker:
```bash
systemctl restart docker
docker compose down && docker compose up -d
```

---

## Security Checklist

- [ ] JWT_SECRET set to random 32+ hex chars
- [ ] ALLOW_LOCAL=false (or unset)
- [ ] FRONTEND_URL set to HTTPS URL only
- [ ] PostgreSQL password set via env, not hardcoded
- [ ] Caddy/nginx serving HTTPS with valid cert
- [ ] UFW firewall enabled, only 22/80/443 open
- [ ] Fail2ban running
- [ ] Auto-security-updates enabled
- [ ] SSH key auth only (no passwords)
- [ ] Root SSH login disabled
- [ ] First admin account created, weak default password not used
- [ ] Bug bounty scope strictly enforced via ROE Gate
- [ ] No API keys committed to git (`.env` in `.gitignore`)
