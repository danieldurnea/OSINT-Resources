package collab

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"
)

// handlers.go — Collaboration endpoints:
//   POST   /api/v1/collab/{scanID}/share    {"username":"bob"}  owner shares a scan
//   DELETE /api/v1/collab/{scanID}/share/{userID}              owner revokes access
//   GET    /api/v1/collab/{scanID}/members                     list who it's shared with
//   GET    /api/v1/collab/shared-with-me                       scans shared with caller

type UserIDFunc func(r *http.Request) string

// OwnerCheck reports whether userID owns scanID (injected from findings/cache so
// collab doesn't duplicate the ownership source of truth).
type OwnerCheck func(ctx context.Context, scanID, userID string) bool

// UsernameResolver maps a username to a user id (injected from auth).
type UsernameResolver func(ctx context.Context, username string) (userID string, ok bool)

type Handler struct {
	store   *Store
	userID  UserIDFunc
	isOwner OwnerCheck
	resolve UsernameResolver
}

func NewHandler(store *Store, userID UserIDFunc, isOwner OwnerCheck, resolve UsernameResolver) *Handler {
	return &Handler{store: store, userID: userID, isOwner: isOwner, resolve: resolve}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (h *Handler) caller(w http.ResponseWriter, r *http.Request) (string, bool) {
	id := h.userID(r)
	if id == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return "", false
	}
	return id, true
}

// requireOwner ensures the caller owns the scan before allowing share/revoke.
func (h *Handler) requireOwner(w http.ResponseWriter, r *http.Request, scanID, caller string) bool {
	if !h.isOwner(r.Context(), scanID, caller) {
		writeJSON(w, http.StatusForbidden, map[string]string{"error": "only the scan owner can manage sharing"})
		return false
	}
	return true
}

// HandleShare — POST /api/v1/collab/{scanID}/share
func (h *Handler) HandleShare(w http.ResponseWriter, r *http.Request) {
	caller, ok := h.caller(w, r)
	if !ok {
		return
	}
	scanID := chi.URLParam(r, "scanID")
	if !h.requireOwner(w, r, scanID, caller) {
		return
	}
	var body struct {
		Username string `json:"username"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(&body); err != nil || body.Username == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "username required"})
		return
	}
	granteeID, found := h.resolve(r.Context(), body.Username)
	if !found {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "no such user"})
		return
	}
	if err := h.store.Grant(r.Context(), scanID, caller, granteeID); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"shared_with": body.Username})
}

// HandleRevoke — DELETE /api/v1/collab/{scanID}/share/{userID}
func (h *Handler) HandleRevoke(w http.ResponseWriter, r *http.Request) {
	caller, ok := h.caller(w, r)
	if !ok {
		return
	}
	scanID := chi.URLParam(r, "scanID")
	if !h.requireOwner(w, r, scanID, caller) {
		return
	}
	grantee := chi.URLParam(r, "userID")
	if err := h.store.Revoke(r.Context(), scanID, grantee); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "revoke failed"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"revoked": grantee})
}

// HandleMembers — GET /api/v1/collab/{scanID}/members
func (h *Handler) HandleMembers(w http.ResponseWriter, r *http.Request) {
	caller, ok := h.caller(w, r)
	if !ok {
		return
	}
	scanID := chi.URLParam(r, "scanID")
	// Owner or a shared member may view the member list.
	if !h.isOwner(r.Context(), scanID, caller) && !h.store.CanAccess(r.Context(), scanID, caller) {
		writeJSON(w, http.StatusForbidden, map[string]string{"error": "access denied"})
		return
	}
	members, err := h.store.Members(r.Context(), scanID)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not list members"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"scan_id": scanID, "members": members, "count": len(members)})
}

// HandleSharedWithMe — GET /api/v1/collab/shared-with-me
func (h *Handler) HandleSharedWithMe(w http.ResponseWriter, r *http.Request) {
	caller, ok := h.caller(w, r)
	if !ok {
		return
	}
	scans, err := h.store.SharedWithMe(r.Context(), caller)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"scans": scans, "count": len(scans)})
}
