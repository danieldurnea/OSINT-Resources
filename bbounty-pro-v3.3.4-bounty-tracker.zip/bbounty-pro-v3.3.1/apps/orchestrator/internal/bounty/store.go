// Package bounty implements the Bounty Tracker: hunters log reports they've
// submitted to programs and track them through their lifecycle (submitted →
// triaged → accepted → paid, or duplicate/n-a), with payout amounts. It gives a
// personal pipeline + earnings view, complementing the Hunter Dashboard (which
// tracks scans/findings; this tracks the money side after submission).
package bounty

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

// Status is the lifecycle state of a submitted report.
type Status string

const (
	StatusSubmitted Status = "submitted"
	StatusTriaged   Status = "triaged"
	StatusAccepted  Status = "accepted"
	StatusPaid      Status = "paid"
	StatusDuplicate Status = "duplicate"
	StatusNA        Status = "n/a" // not applicable / rejected
)

// ValidStatus reports whether s is a known status.
func ValidStatus(s Status) bool {
	switch s {
	case StatusSubmitted, StatusTriaged, StatusAccepted, StatusPaid, StatusDuplicate, StatusNA:
		return true
	}
	return false
}

// Report is a tracked bug-bounty submission.
type Report struct {
	ID          string    `json:"id"`
	Title       string    `json:"title"`
	Program     string    `json:"program"`
	Platform    string    `json:"platform,omitempty"` // hackerone | bugcrowd | other
	Severity    string    `json:"severity,omitempty"`
	Status      Status    `json:"status"`
	Amount      float64   `json:"amount"`             // payout amount (when paid/accepted)
	Currency    string    `json:"currency,omitempty"` // e.g. USD, EUR
	ReportURL   string    `json:"report_url,omitempty"`
	ScanID      string    `json:"scan_id,omitempty"` // optional link back to the scan
	Notes       string    `json:"notes,omitempty"`
	SubmittedAt time.Time `json:"submitted_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 3 * 365 * 24 * time.Hour} // keep 3 years
}

func indexKey(userID string) string      { return "bounty:reports:" + userID }
func reportKey(userID, id string) string { return "bounty:report:" + userID + ":" + id }

// Save creates or updates a report.
func (s *Store) Save(ctx context.Context, userID string, r *Report) error {
	if userID == "" || r.Title == "" {
		return fmt.Errorf("userID and title required")
	}
	if r.Status == "" {
		r.Status = StatusSubmitted
	}
	if !ValidStatus(r.Status) {
		return fmt.Errorf("invalid status %q", r.Status)
	}
	now := time.Now().UTC()
	if r.ID == "" {
		r.ID = fmt.Sprintf("%d", now.UnixNano())
		r.SubmittedAt = now
	}
	if r.SubmittedAt.IsZero() {
		r.SubmittedAt = now
	}
	r.UpdatedAt = now
	if r.Currency == "" {
		r.Currency = "USD"
	}
	data, err := json.Marshal(r)
	if err != nil {
		return err
	}
	pipe := s.rdb.TxPipeline()
	pipe.ZAdd(ctx, indexKey(userID), redis.Z{Score: float64(r.SubmittedAt.Unix()), Member: r.ID})
	pipe.Expire(ctx, indexKey(userID), s.ttl)
	pipe.Set(ctx, reportKey(userID, r.ID), data, s.ttl)
	_, err = pipe.Exec(ctx)
	return err
}

// Get returns one report.
func (s *Store) Get(ctx context.Context, userID, id string) (*Report, error) {
	raw, err := s.rdb.Get(ctx, reportKey(userID, id)).Result()
	if err != nil {
		return nil, err
	}
	var r Report
	if err := json.Unmarshal([]byte(raw), &r); err != nil {
		return nil, err
	}
	return &r, nil
}

// List returns reports newest first.
func (s *Store) List(ctx context.Context, userID string) ([]*Report, error) {
	ids, err := s.rdb.ZRevRange(ctx, indexKey(userID), 0, 999).Result()
	if err != nil {
		return nil, err
	}
	out := make([]*Report, 0, len(ids))
	for _, id := range ids {
		if r, err := s.Get(ctx, userID, id); err == nil {
			out = append(out, r)
		}
	}
	return out, nil
}

// Delete removes a report.
func (s *Store) Delete(ctx context.Context, userID, id string) error {
	pipe := s.rdb.TxPipeline()
	pipe.ZRem(ctx, indexKey(userID), id)
	pipe.Del(ctx, reportKey(userID, id))
	_, err := pipe.Exec(ctx)
	return err
}

// Stats summarises the bounty pipeline + earnings.
type Stats struct {
	Total       int            `json:"total"`
	ByStatus    map[string]int `json:"by_status"`
	TotalEarned float64        `json:"total_earned"` // sum of paid amounts
	Pending     float64        `json:"pending"`      // accepted-but-not-yet-paid amounts
	Currency    string         `json:"currency"`
	AcceptRate  float64        `json:"accept_rate"` // accepted+paid / resolved
}

// Summary computes pipeline + earnings stats.
func (s *Store) Summary(ctx context.Context, userID string) (*Stats, error) {
	reports, err := s.List(ctx, userID)
	if err != nil {
		return nil, err
	}
	st := &Stats{ByStatus: map[string]int{}, Currency: "USD"}
	resolved, good := 0, 0
	for _, r := range reports {
		st.Total++
		st.ByStatus[string(r.Status)]++
		if r.Currency != "" {
			st.Currency = r.Currency // last one wins; most hunters use one currency
		}
		switch r.Status {
		case StatusPaid:
			st.TotalEarned += r.Amount
			resolved++
			good++
		case StatusAccepted:
			st.Pending += r.Amount
			resolved++
			good++
		case StatusDuplicate, StatusNA:
			resolved++
		}
	}
	if resolved > 0 {
		st.AcceptRate = float64(good) / float64(resolved)
	}
	return st, nil
}

// sortReports newest-first (helper for callers).
func sortReports(r []*Report) {
	sort.Slice(r, func(i, j int) bool { return r[i].SubmittedAt.After(r[j].SubmittedAt) })
}

// ParseStatus normalises a status string.
func ParseStatus(s string) (Status, bool) {
	st := Status(strings.ToLower(strings.TrimSpace(s)))
	return st, ValidStatus(st)
}

var _ = sortReports
