// Item #13: Refresh token rate limiting.
//
// Detects suspicious refresh patterns (max 10 / hour / user).
// Optionally tracks IP changes to flag credential theft.
//
// LIMITATION: Pure rate limit, no IP geolocation analysis.
// For production, integrate with MaxMind GeoIP for impossible-travel detection.

package auth

import (
	"context"
	"fmt"

	"github.com/bbounty-pro/orchestrator/internal/config"
	"github.com/redis/go-redis/v9"
)

const (
	refreshLimitWindow = config.RateLimitWindow
	refreshLimitMax    = config.MaxRefreshPerHour
)

func (m *Manager) checkRefreshRate(ctx context.Context, userID string) error {
	key := fmt.Sprintf("auth:refresh_count:%s", userID)
	count, err := m.cache.Raw().Incr(ctx, key).Result()
	if err != nil && err != redis.Nil {
		return nil // soft-fail: don't block on Redis errors
	}
	if count == 1 {
		m.cache.Raw().Expire(ctx, key, refreshLimitWindow)
	}
	if count > refreshLimitMax {
		return fmt.Errorf("too many token refreshes — possible credential theft")
	}
	return nil
}
