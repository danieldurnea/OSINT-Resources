#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BBounty Pro — Encrypted Backup Script
# Backup: Redis RDB + PostgreSQL dump → criptat AES-256 → /var/backups/bbounty
# Rulare: sudo bash scripts/backup-encrypted.sh
# Cron:   0 3 * * * sudo bash /opt/bbounty-pro/scripts/backup-encrypted.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

GRN='\033[0;32m'; YEL='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GRN}✓${NC} $1"; }
warn() { echo -e "${YEL}⚠${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; exit 1; }

BACKUP_DIR="/var/backups/bbounty"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-30}"
ENV_FILE="${ENV_FILE:-/opt/bbounty-pro/.env}"

# Load env
[[ -f "$ENV_FILE" ]] && source "$ENV_FILE"

REDIS_PASS="${REDIS_PASSWORD:-}"
PG_PASS="${POSTGRES_PASSWORD:-}"
ENC_KEY="${BACKUP_ENCRYPTION_KEY:-}"

[[ -z "$ENC_KEY" ]] && fail "BACKUP_ENCRYPTION_KEY nu e setat în .env"

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  BBounty Pro — Encrypted Backup"
echo "  $(date)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Redis Backup ──────────────────────────────────────────────────────────────
echo ""
echo "Redis..."
REDIS_BACKUP="${BACKUP_DIR}/redis_${DATE}.rdb"
REDIS_ENC="${REDIS_BACKUP}.enc"

if redis-cli -a "$REDIS_PASS" BGSAVE &>/dev/null; then
    # FIX: wait for BGSAVE to complete instead of blind sleep 3
    for i in $(seq 1 30); do
        STATUS=$(redis-cli -a "$REDIS_PASS" LASTSAVE 2>/dev/null)
        CURRENT=$(date +%s)
        [[ "$STATUS" -ge "$((CURRENT - 5))" ]] && break || sleep 1
    done
    RDB_PATH=$(redis-cli -a "$REDIS_PASS" CONFIG GET dir 2>/dev/null | tail -1)/bbounty-dump.rdb
    [[ -f "$RDB_PATH" ]] && cp "$RDB_PATH" "$REDIS_BACKUP" || \
        cp /var/lib/redis/dump.rdb "$REDIS_BACKUP" 2>/dev/null || \
        warn "Redis RDB nu a fost găsit"
    
    if [[ -f "$REDIS_BACKUP" ]]; then
        openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
            -pass pass:"$ENC_KEY" \
            -in "$REDIS_BACKUP" -out "$REDIS_ENC" 2>/dev/null
        rm -f "$REDIS_BACKUP"
        SIZE=$(du -sh "$REDIS_ENC" | cut -f1)
        ok "Redis: $REDIS_ENC ($SIZE)"
    fi
else
    warn "Redis backup: redis-cli nu e disponibil"
fi

# ── PostgreSQL Backup ─────────────────────────────────────────────────────────
echo ""
echo "PostgreSQL..."
PG_BACKUP="${BACKUP_DIR}/postgres_${DATE}.sql"
PG_ENC="${PG_BACKUP}.enc"

if command -v pg_dump &>/dev/null && [[ -n "$PG_PASS" ]]; then
    PGPASSWORD="$PG_PASS" pg_dump \
        -h 127.0.0.1 -U bbounty bbounty \
        --no-password \
        -f "$PG_BACKUP" 2>/dev/null || \
    docker exec bbounty-postgres pg_dump \
        -U bbounty bbounty \
        > "$PG_BACKUP" 2>/dev/null || \
    warn "PostgreSQL dump eșuat"

    if [[ -f "$PG_BACKUP" && -s "$PG_BACKUP" ]]; then
        openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
            -pass pass:"$ENC_KEY" \
            -in "$PG_BACKUP" -out "$PG_ENC" 2>/dev/null
        rm -f "$PG_BACKUP"
        SIZE=$(du -sh "$PG_ENC" | cut -f1)
        ok "PostgreSQL: $PG_ENC ($SIZE)"
    fi
else
    warn "PostgreSQL backup: pg_dump sau POSTGRES_PASSWORD lipsă"
fi

# ── Retention ─────────────────────────────────────────────────────────────────
echo ""
echo "Cleanup backup-uri vechi (>${RETENTION_DAYS} zile)..."
DELETED=$(find "$BACKUP_DIR" -name "*.enc" -mtime "+${RETENTION_DAYS}" -delete -print | wc -l)
ok "Șterse $DELETED backup-uri expirate"

# ── Summary ───────────────────────────────────────────────────────────────────
TOTAL_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
TOTAL_FILES=$(ls "$BACKUP_DIR"/*.enc 2>/dev/null | wc -l)
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ok "Backup complet: $TOTAL_FILES fișiere, $TOTAL_SIZE total"
echo "  Director: $BACKUP_DIR"
echo ""
echo "Restore Redis:"
echo "  openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \\"
echo "    -pass pass:\$BACKUP_ENCRYPTION_KEY \\"
echo "    -in redis_DATE.rdb.enc -out restore.rdb"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
