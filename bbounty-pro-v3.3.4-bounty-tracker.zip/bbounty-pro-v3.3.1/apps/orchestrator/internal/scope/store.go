// Package scope implements the Scope Manager: hunters save bug-bounty programs
// (scope + excluded + platform), import scope from HackerOne / Bugcrowd exports,
// and auto-check a target against a saved program before scanning. It builds on
// the existing roe package (the saved program is essentially a named roe.ROE).
package scope

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

// Program is a saved bug-bounty program scope, owned by a user.
type Program struct {
	ID        string    `json:"id"`       // slug, unique per user
	Name      string    `json:"name"`     // display name, e.g. "Acme Corp"
	Platform  string    `json:"platform"` // hackerone | bugcrowd | other
	Scope     []string  `json:"scope"`    // in-scope hosts/patterns (e.g. *.acme.com)
	Excluded  []string  `json:"excluded"` // out-of-scope patterns
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// Store persists programs per user in Redis.
type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 365 * 24 * time.Hour} // keep a year
}

func setKey(userID string) string      { return "scope:programs:" + userID }
func progKey(userID, id string) string { return "scope:program:" + userID + ":" + id }

// Save creates or updates a program for a user.
func (s *Store) Save(ctx context.Context, userID string, p *Program) error {
	if userID == "" || p.Name == "" {
		return fmt.Errorf("userID and program name required")
	}
	if p.ID == "" {
		p.ID = slugify(p.Name)
	}
	now := time.Now().UTC()
	if p.CreatedAt.IsZero() {
		p.CreatedAt = now
	}
	p.UpdatedAt = now
	data, err := json.Marshal(p)
	if err != nil {
		return err
	}
	pipe := s.rdb.TxPipeline()
	pipe.SAdd(ctx, setKey(userID), p.ID)
	pipe.Expire(ctx, setKey(userID), s.ttl)
	pipe.Set(ctx, progKey(userID, p.ID), data, s.ttl)
	_, err = pipe.Exec(ctx)
	return err
}

// Get returns a single program by id.
func (s *Store) Get(ctx context.Context, userID, id string) (*Program, error) {
	raw, err := s.rdb.Get(ctx, progKey(userID, id)).Result()
	if err != nil {
		return nil, err
	}
	var p Program
	if err := json.Unmarshal([]byte(raw), &p); err != nil {
		return nil, err
	}
	return &p, nil
}

// List returns all programs for a user, newest first.
func (s *Store) List(ctx context.Context, userID string) ([]*Program, error) {
	ids, err := s.rdb.SMembers(ctx, setKey(userID)).Result()
	if err != nil {
		return nil, err
	}
	out := make([]*Program, 0, len(ids))
	for _, id := range ids {
		if p, err := s.Get(ctx, userID, id); err == nil {
			out = append(out, p)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].UpdatedAt.After(out[j].UpdatedAt) })
	return out, nil
}

// Delete removes a program.
func (s *Store) Delete(ctx context.Context, userID, id string) error {
	pipe := s.rdb.TxPipeline()
	pipe.SRem(ctx, setKey(userID), id)
	pipe.Del(ctx, progKey(userID, id))
	_, err := pipe.Exec(ctx)
	return err
}

// ResolveScope returns a saved program's scope + excluded lists, for server-side
// enforcement at scan start (Scope Manager hard enforcement). Errors if missing.
func (s *Store) ResolveScope(ctx context.Context, userID, programID string) (scope, excluded []string, err error) {
	p, err := s.Get(ctx, userID, programID)
	if err != nil {
		return nil, nil, err
	}
	return p.Scope, p.Excluded, nil
}

// slugify turns a program name into a url-safe id.
func slugify(name string) string {
	var b strings.Builder
	prevDash := false
	for _, r := range strings.ToLower(strings.TrimSpace(name)) {
		switch {
		case r >= 'a' && r <= 'z', r >= '0' && r <= '9':
			b.WriteRune(r)
			prevDash = false
		default:
			if !prevDash {
				b.WriteByte('-')
				prevDash = true
			}
		}
	}
	return strings.Trim(b.String(), "-")
}
