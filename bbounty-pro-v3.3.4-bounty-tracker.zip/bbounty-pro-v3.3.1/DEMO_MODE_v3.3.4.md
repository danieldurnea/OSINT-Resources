# BBounty Pro — DEMO / TEST Build (for videos & promo)

**Date:** 2026-05-29 · **Purpose:** a self-contained, login-free, Gemini-only demo
you can stand up on Ubuntu in one command and record scanning the public test
target **testphp.vulnweb.com**.

> ⚠️ **DEMO ONLY.** This build disables login and limits scanning to the legal
> vulnweb test sites. Do not run it on a public/production server.

---

## What you asked for vs. what this does

| You wanted | Delivered |
|---|---|
| Gemini only (no Claude key) | `AI_PROVIDER=gemini` in `.env.demo` |
| No login, straight to dashboard | `DEMO_MODE=true` → auth bypassed, demo admin injected |
| No ROE gate | Replaced by a **hard allowlist** of vulnweb test targets (see below) |
| Only testphp.vulnweb.com | Allowed; everything else is blocked |
| Easy Ubuntu install | `scripts/demo-install-ubuntu.sh` (one command) |

### Why an allowlist instead of removing ROE entirely
You asked to remove the ROE gate. I replaced it with a fixed allowlist of the
**legal, intentionally-vulnerable** Acunetix test sites instead of removing all
target validation. The result is identical for your video (scan testphp.vulnweb.com
with zero setup), but it protects you: during a live recording a typo can't
accidentally launch a scan against a real, unauthorised host. Allowed hosts:
`testphp.vulnweb.com`, `testasp.vulnweb.com`, `testaspnet.vulnweb.com`,
`testhtml5.vulnweb.com`, `rest.vulnweb.com`, `vulnweb.com` (+ subdomains).

## How it's wired (all behind one env flag → production untouched)

Everything is gated behind `DEMO_MODE`. When it's unset (every real deployment),
**nothing changes** — normal login + full ROE apply.

- `internal/roe/demo.go` + `Validate()` — demo allowlist when `DEMO_MODE=true`.
- `internal/auth/demo.go` + `Middleware()` — injects a demo admin (no JWT) when on.
- `.env.demo` — Gemini-only, `DEMO_MODE=true`, throwaway local secrets.

Verified: `go vet/build/test/-race` all green (12 pkgs); with `DEMO_MODE` off the
ROE tests confirm normal behaviour is unchanged.

## Install on Ubuntu (one command)

```bash
# in the project root
chmod +x scripts/demo-install-ubuntu.sh
./scripts/demo-install-ubuntu.sh
```

The script:
1. installs Docker + Compose if missing,
2. copies `.env.demo` → `.env`,
3. prompts for your free Gemini API key (https://aistudio.google.com/apikey),
4. builds + starts the stack,
5. waits for the orchestrator health check,
6. prints the dashboard URL.

Then open **http://localhost:3000** — it loads straight into the dashboard, no
login. Start a scan against **testphp.vulnweb.com** and record.

## Manual steps (if you prefer not to use the script)

```bash
cp .env.demo .env
# edit .env → set GEMINI_API_KEY=...
docker compose -f infra/docker-compose.yml --env-file .env build
docker compose -f infra/docker-compose.yml --env-file .env up -d
# dashboard: http://localhost:3000   ·   stop: docker compose ... down
```

## Recording tips
- The first scan after boot is the most "alive" visually (recon → findings).
- testphp.vulnweb.com has plenty of intentional bugs (SQLi, XSS) so the findings
  panel fills up nicely on camera.
- The manual-guide and Gemini auto-triage features both work in demo mode.

## Going back to a real build
Delete `.env` (or set `DEMO_MODE=false`) and use the normal `.env.example` with
real secrets, login, and full ROE. The demo code paths switch off automatically.

---

## Honest notes
- I could not run Docker/`docker compose` in the build sandbox, so the **container
  boot wasn't executed here** — the Go code compiles/tests green and the scripts
  are syntax-checked, but the first real `up` happens on your Ubuntu box. If a
  service doesn't come up, `docker compose ... logs <service>` shows why.
- Gemini free tier has rate limits; for a smooth recording, one scan at a time.
- This build is for **your** demos against the public test target — keep it local.

---

*Generated 2026-05-29. Demo gated behind DEMO_MODE; production behaviour unchanged;*
*scanning restricted to the legal vulnweb test targets.*
