package scope

import (
	"reflect"
	"sort"
	"testing"
)

func sorted(s []string) []string { sort.Strings(s); return s }

func TestParseScopeText(t *testing.T) {
	text := `In scope:
*.example.com
https://api.example.com/v2
app.example.com

Out of scope:
blog.example.com
- legacy.example.com`
	scope, excluded := ParseScopeText(text)
	wantScope := sorted([]string{"*.example.com", "api.example.com", "app.example.com"})
	wantExcl := sorted([]string{"blog.example.com", "legacy.example.com"})
	if !reflect.DeepEqual(sorted(scope), wantScope) {
		t.Errorf("scope=%v want %v", sorted(scope), wantScope)
	}
	if !reflect.DeepEqual(sorted(excluded), wantExcl) {
		t.Errorf("excluded=%v want %v", sorted(excluded), wantExcl)
	}
}

func TestParseHackerOneJSON(t *testing.T) {
	data := []byte(`[
	  {"asset_identifier":"*.acme.com","asset_type":"WILDCARD","eligible_for_submission":true},
	  {"asset_identifier":"old.acme.com","asset_type":"URL","eligible_for_submission":false},
	  {"asset_identifier":"com.acme.app","asset_type":"OTHER","eligible_for_submission":true}
	]`)
	scope, excluded, ok := ParseHackerOneJSON(data)
	if !ok {
		t.Fatal("expected parse ok")
	}
	if len(scope) != 1 || scope[0] != "*.acme.com" {
		t.Errorf("scope=%v want [*.acme.com] (OTHER type skipped)", scope)
	}
	if len(excluded) != 1 || excluded[0] != "old.acme.com" {
		t.Errorf("excluded=%v want [old.acme.com]", excluded)
	}
}

func TestParseBugcrowdJSON(t *testing.T) {
	data := []byte(`{"targets":[
	  {"name":"*.bc.com","category":"website","in_scope":true},
	  {"name":"ios-app","category":"ios","in_scope":true},
	  {"name":"old.bc.com","category":"api","in_scope":false}
	]}`)
	scope, excluded, ok := ParseBugcrowdJSON(data)
	if !ok {
		t.Fatal("expected parse ok")
	}
	if len(scope) != 1 || scope[0] != "*.bc.com" {
		t.Errorf("scope=%v want [*.bc.com] (ios skipped)", scope)
	}
	if len(excluded) != 1 {
		t.Errorf("excluded=%v want 1", excluded)
	}
}

func TestSlugify(t *testing.T) {
	cases := map[string]string{"Acme Corp": "acme-corp", "  Foo!!Bar  ": "foo-bar", "X": "x"}
	for in, want := range cases {
		if got := slugify(in); got != want {
			t.Errorf("slugify(%q)=%q want %q", in, got, want)
		}
	}
}

func TestCleanAssetRejectsJunk(t *testing.T) {
	for _, junk := range []string{"not a host", "see the docs", ""} {
		if a := cleanAsset(junk); a != "" {
			t.Errorf("cleanAsset(%q)=%q, expected empty", junk, a)
		}
	}
	if cleanAsset("https://x.com/path") != "x.com" {
		t.Error("should strip protocol+path")
	}
}
