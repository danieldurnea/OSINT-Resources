// Adapter bridging the DSL engine's findings to BBounty Pro's findings store.
// This file is BBounty-Pro-specific glue (not from recon0).

package dsl

import (
	"fmt"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/google/uuid"
)

// categoryForTags derives a BBounty findings Category from a rule's tags.
// Falls back to "secret" (the DSL engine's primary purpose) when unknown.
func categoryForTags(tags []string) string {
	for _, t := range tags {
		switch t {
		case "secret":
			return "secret"
		case "cloud":
			return "cloud-asset"
		case "header", "cors", "csp":
			return "misconfiguration"
		case "path", "exposure":
			return "exposure"
		case "info-disclosure", "stacktrace":
			return "info-disclosure"
		}
	}
	if len(tags) > 0 {
		return tags[0]
	}
	return "secret"
}

// ToFindings converts the engine's deduplicated DSL findings into BBounty Pro
// findings.Finding records for a given scan. The engine's rules are used to
// enrich each finding with the originating rule's tags/category (dsl.Finding
// itself carries only the rule ID). Severity maps 1:1 — both type systems use
// the identical critical/high/medium/low/info vocabulary.
func (e *Engine) ToFindings(scanID string) []*findings.Finding {
	// index rule metadata by ID for tag/category enrichment
	ruleByID := make(map[string]Rule, len(e.rules))
	for _, r := range e.rules {
		ruleByID[r.ID] = r
	}

	dslFindings := e.DeduplicatedFindings()
	out := make([]*findings.Finding, 0, len(dslFindings))
	now := time.Now().UTC()

	for _, d := range dslFindings {
		rule := ruleByID[d.RuleID]
		tags := append([]string{"dsl", d.RuleID}, rule.Tags...)

		ctx := fmt.Sprintf("source=%s file=%s", d.Source, d.File)
		if d.Line > 0 {
			ctx += fmt.Sprintf(" line=%d", d.Line)
		}
		if d.Context != "" {
			ctx += " | " + d.Context
		}

		out = append(out, &findings.Finding{
			ID:        uuid.New().String(),
			ScanID:    scanID,
			Title:     fmt.Sprintf("[dsl/%s] %s", d.RuleID, d.RuleName),
			URL:       d.URL,
			Severity:  findings.Severity(d.Severity), // 1:1 vocabulary
			Category:  categoryForTags(rule.Tags),
			Payload:   truncateValue(d.Value, 500),
			Response:  ctx,
			Status:    findings.StatusNew,
			Source:    "dsl",
			Tags:      tags,
			CreatedAt: now,
			UpdatedAt: now,
		})
	}
	return out
}
