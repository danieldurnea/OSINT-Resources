package hunter

import "testing"

func TestProgramFromTarget(t *testing.T) {
	cases := map[string]string{
		"https://app.example.com/path?x=1": "example.com",
		"http://testphp.vulnweb.com":       "vulnweb.com",
		"https://example.com":              "example.com",
		"example.com":                      "example.com",
		"https://sub.deep.example.co":      "example.co",
		"":                                 "unknown",
	}
	for in, want := range cases {
		if got := programFromTarget(in); got != want {
			t.Errorf("programFromTarget(%q)=%q want %q", in, got, want)
		}
	}
}

func TestParseIntDefault(t *testing.T) {
	if parseIntDefault("", 50) != 50 {
		t.Error("empty should return default")
	}
	if parseIntDefault("25", 50) != 25 {
		t.Error("valid int should parse")
	}
	if parseIntDefault("abc", 50) != 50 {
		t.Error("invalid should return default")
	}
}

// TestSignalScoreMath verifies the ROI proxy formula directly.
func TestSignalScoreMath(t *testing.T) {
	p := ProgramStat{Scans: 2, Critical: 1, High: 2, Findings: 5}
	// (4*1 + 3*2 + 5) / 2 = 15/2 = 7.5
	want := 7.5
	got := float64(4*p.Critical+3*p.High+p.Findings) / float64(p.Scans)
	if got != want {
		t.Errorf("signal score = %v want %v", got, want)
	}
}
