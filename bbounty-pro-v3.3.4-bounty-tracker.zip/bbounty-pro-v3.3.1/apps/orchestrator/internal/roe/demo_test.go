package roe

import (
	"os"
	"testing"
)

func TestDemoModeAllowlist(t *testing.T) {
	os.Setenv("DEMO_MODE", "true")
	defer os.Unsetenv("DEMO_MODE")
	g := NewGate()
	// allowed test targets — no scope needed in demo mode
	for _, ok := range []string{"http://testphp.vulnweb.com", "testphp.vulnweb.com", "https://testasp.vulnweb.com/x"} {
		if err := g.Validate(ok, nil, nil); err != nil {
			t.Errorf("demo: %q should be allowed, got %v", ok, err)
		}
	}
	// everything else blocked, even in demo mode
	for _, bad := range []string{"http://example.com", "https://google.com", "http://192.168.1.1"} {
		if err := g.Validate(bad, nil, nil); err == nil {
			t.Errorf("demo: %q must be blocked", bad)
		}
	}
}

func TestDemoModeOffUnchanged(t *testing.T) {
	os.Unsetenv("DEMO_MODE")
	g := NewGate()
	// with demo off, normal ROE applies — empty scope is rejected
	if err := g.Validate("http://testphp.vulnweb.com", nil, nil); err == nil {
		t.Error("with DEMO_MODE off, empty scope must still be rejected (normal ROE)")
	}
}
