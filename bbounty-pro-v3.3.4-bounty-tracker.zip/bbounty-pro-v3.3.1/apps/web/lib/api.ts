// BBounty Pro — Typed API Client
// All requests go through /api/v1/* which Next.js proxies to the Go orchestrator

import type {
  Tool,
  ScanRequest,
  ScanStartResponse,
  LiveStats,
  ROEConfig,
  ROEValidationResult,
  Finding,
  AIChatRequest,
  AIChatResponse,
  AIMessage,
  AIPreset,
} from "@bbounty/shared-types";

// ─── Base fetcher ─────────────────────────────────────────────────────────────

class APIError extends Error {
  constructor(
    public status: number,
    message: string,
    public body?: unknown
  ) {
    super(message);
    this.name = "APIError";
  }
}

async function apiFetch<T>(
  path: string,
  init?: RequestInit
): Promise<T> {
  const res = await fetch(`/api/v1${path}`, {
    credentials: "include",  // always send httpOnly auth cookie
    headers: {
      "Content-Type": "application/json",
      "X-Request-ID": crypto.randomUUID(),
    },
    ...init,
  });

  if (!res.ok) {
    let body: unknown;
    try { body = await res.json(); } catch {}
    throw new APIError(
      res.status,
      (body as any)?.error ?? `HTTP ${res.status}`,
      body
    );
  }

  // 204 No Content — return empty
  if (res.status === 204) return undefined as T;

  return res.json();
}

// ─── Scan ─────────────────────────────────────────────────────────────────────

export const scanAPI = {
  start(req: ScanRequest): Promise<ScanStartResponse> {
    return apiFetch("/scan/start", {
      method: "POST",
      body: JSON.stringify(req),
    });
  },

  stop(scanID: string): Promise<{ status: string }> {
    return apiFetch(`/scan/stop?scan_id=${scanID}`, { method: "POST" });
  },

  pause(scanID: string): Promise<{ status: string }> {
    return apiFetch(`/scan/pause?scan_id=${scanID}`, { method: "POST" });
  },

  status(scanID: string): Promise<LiveStats> {
    return apiFetch(`/scan/status/${scanID}`);
  },

  stats(scanID: string): Promise<LiveStats> {
    return apiFetch(`/stats/${scanID}`);
  },
};

// ─── Tools ───────────────────────────────────────────────────────────────────

export const toolsAPI = {
  list(): Promise<Tool[]> {
    return apiFetch("/tools");
  },

  info(toolID: string): Promise<Tool> {
    return apiFetch(`/tools/${toolID}/info`);
  },

  runSingle(toolID: string, target: string): Promise<{ status: string }> {
    return apiFetch(`/tools/${toolID}/run`, {
      method: "POST",
      body: JSON.stringify({ target }),
    });
  },
};

// ─── ROE ─────────────────────────────────────────────────────────────────────

export const roeAPI = {
  validate(roe: Partial<ROEConfig> & { target: string }): Promise<ROEValidationResult> {
    return apiFetch("/roe/validate", {
      method: "POST",
      body: JSON.stringify(roe),
    });
  },

  checkScope(url: string, scope: string[], excluded: string[]): Promise<{ in_scope: boolean }> {
    return apiFetch("/roe/check-scope", {
      method: "POST",
      body: JSON.stringify({ url, scope, excluded }),
    });
  },
};

// ─── Findings ────────────────────────────────────────────────────────────────

export const findingsAPI = {
  list(scanID: string, severity?: string): Promise<Finding[]> {
    const q = severity ? `?severity=${severity}` : "";
    return apiFetch(`/findings/${scanID}${q}`);
  },

  create(finding: Omit<Finding, "id" | "created_at" | "updated_at">): Promise<Finding> {
    return apiFetch("/findings", {
      method: "POST",
      body: JSON.stringify(finding),
    });
  },

  update(id: string, updates: Partial<Finding>): Promise<Finding> {
    return apiFetch(`/findings/${id}`, {
      method: "PUT",
      body: JSON.stringify(updates),
    });
  },

  delete(id: string, scanID?: string): Promise<void> {
    const q = scanID ? `?scan_id=${scanID}` : "";
    return apiFetch(`/findings/${id}${q}`, { method: "DELETE" });
  },

  analyze(id: string, finding: Finding): Promise<{ analysis: string }> {
    return apiFetch(`/findings/${id}/analyze`, {
      method: "POST",
      body: JSON.stringify({ finding }),
    });
  },
};

// ─── AI ──────────────────────────────────────────────────────────────────────

export const aiAPI = {
  chat(req: AIChatRequest): Promise<AIChatResponse> {
    return apiFetch("/ai/chat", {
      method: "POST",
      body: JSON.stringify(req),
    });
  },

  reportReview(report: string): Promise<{ review: string }> {
    return apiFetch("/ai/report-review", {
      method: "POST",
      body: JSON.stringify({ report }),
    });
  },

  // Quick preset shortcuts
  analyzeRecon(reconOutput: string): Promise<AIChatResponse> {
    return aiAPI.chat({
      preset: "recon_analysis",
      messages: [{ role: "user", content: reconOutput }],
    });
  },

  wafBypass(wafName: string): Promise<AIChatResponse> {
    return aiAPI.chat({
      preset: "waf_bypass",
      messages: [{ role: "user", content: `WAF detected: ${wafName}` }],
    });
  },

  cvssScore(description: string): Promise<AIChatResponse> {
    return aiAPI.chat({
      preset: "cvss_calculator",
      messages: [{ role: "user", content: description }],
    });
  },
};

// ─── WebSocket factory ────────────────────────────────────────────────────────

type WSChannel = "terminal" | "stats" | "pipeline";

export function createWebSocket(
  scanID: string,
  channel: WSChannel,
  toolID?: string
): WebSocket {
  const proto = window.location.protocol === "https:" ? "wss" : "ws";
  const host = process.env.NEXT_PUBLIC_WS_HOST ?? window.location.hostname;
  const port = process.env.NEXT_PUBLIC_WS_PORT ?? "8080";

  let path: string;
  switch (channel) {
    case "terminal":
      path = `/ws/terminal/${scanID}/${toolID ?? "all"}`;
      break;
    case "stats":
      path = `/ws/stats/${scanID}`;
      break;
    case "pipeline":
      path = `/ws/pipeline/${scanID}`;
      break;
  }

  return new WebSocket(`${proto}://${host}:${port}${path}`);
}

// ─── SWR fetcher ─────────────────────────────────────────────────────────────

// H5-FIX: credentials: 'include' required — sends httpOnly auth cookie.
// Without this, authenticated SWR calls fail silently after cookie-based auth migration.
export const swrFetcher = (url: string) =>
  fetch(url, {
    credentials: "include",  // send bb_access httpOnly cookie
    headers: { "X-Request-ID": crypto.randomUUID() },
  }).then(r => {
    if (!r.ok) throw new APIError(r.status, `HTTP ${r.status}`);
    return r.json();
  });

export { APIError };
