import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import "./globals.css";

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
  weight: ["300", "400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "BBounty Pro Agent",
  description: "AI-Powered Bug Bounty Platform — 44 Tools, 5 Phases",
  robots: "noindex,nofollow", // Internal tool — do not index
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={jetbrains.variable}>
      <body className="bg-[#080c0e] text-[#c8d8e0] antialiased">{children}</body>
    </html>
  );
}
