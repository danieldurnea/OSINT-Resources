# BBounty Pro — Bounty Tracker v3.3.4

**Medium-tier module #1.** Track submitted reports through their lifecycle
(submitted → triaged → accepted → paid, or duplicate/n-a) with payout amounts —
a personal pipeline + earnings view. Complements the Hunter Dashboard (which tracks
scans/findings; this tracks the money after submission).

## Backend (Go) — `internal/bounty/`
- **`store.go`** — per-user reports in Redis (3-year TTL). Each report: title,
  program, platform, severity, status, amount, currency, optional report URL +
  scan link, notes. `Summary` computes total earned (paid), pending (accepted),
  and accept rate (accepted+paid ÷ resolved).
- **`handlers.go`** — `GET/POST /api/v1/bounty`, `DELETE /api/v1/bounty/{id}`,
  `GET /api/v1/bounty/stats`.

## Frontend (Next.js) — `app/bounty/`
- **`components/bounty/BountyTracker.tsx`** — earnings cards (earned, pending,
  reports, accept rate), an add-report form, and a reports list where you can
  change status inline (dropdown) and see the payout. Status colour-coded.
- **`bountyAPI`** added to `lib/api-client.ts`.

## Verified
Backend: vet ✅ · build ✅ · test ✅ (3 new tests inc. earnings/accept-rate math) ·
-race 0 races / 18 pkgs ✅ · gofmt ✅ · go.mod pristine (1.26).
Frontend: api-client strict-typechecks clean; component typechecks clean.

## Honest notes
- Reports are entered manually (you log what you submitted) — there's no live
  HackerOne/Bugcrowd API sync. That would need each platform's API + the hunter's
  token; a sensible later addition, but manual entry ships value now and avoids
  storing platform credentials.
- Currency is per-report free-text (defaults USD); the summary uses the last seen
  currency for display — fine for hunters who work in one currency, not a
  multi-currency accounting tool.
- Couldn't run the Next build here (no npm registry) — run npm install && build.

## Roadmap
Quick Wins: 1-5 ✅ (Report Gen, Hunter Dash, Scope Mgr, Collab, Vuln DB) + scope enforcement ✅
Medium: 1.✅ Bounty Tracker — next: Leaderboard · AI Chat Assistant · PDF export · advanced notifications.
