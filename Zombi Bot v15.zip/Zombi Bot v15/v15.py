import sys,os,re,socket,binascii,time,json,random,threading,pprint,smtplib,telnetlib,os.path,hashlib,string,urllib.request,urllib.error,urllib.parse,glob,sqlite3,urllib.request,urllib.parse,urllib.error,argparse,marshal,base64,requests
from colorama import *
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from queue import Queue
from time import strftime
from urllib.parse import urlparse
from urllib.request import urlopen
init()

la7mar  = '\033[91m'
lazra9  = '\033[94m'
la5dhar = '\033[92m'
movv    = '\033[95m'
lasfar  = '\033[93m'
ramadi  = '\033[90m'
blid    = '\033[1m'
star    = '\033[4m'
bigas   = '\033[07m'
bigbbs  = '\033[27m'
hell    = '\033[05m'
saker   = '\033[25m'
labyadh = '\033[00m'
cyan    = '\033[0;96m'

def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """ 

  ______                      _       _     ____            _      __      __  __   _____ 
 |___  /                     | |     (_)   |  _ \          | |     \ \    / / /_ | | ____|
    / /    ___    _ __ ___   | |__    _    | |_) |   ___   | |_     \ \  / /   | | | |__  
   / /    / _ \  | '_ ` _ \  | '_ \  | |   |  _ <   / _ \  | __|     \ \/ /    | | |___ \ 
  / /__  | (_) | | | | | | | | |_) | | |   | |_) | | (_) | | |_       \  /     | |  ___) |
 /_____|  \___/  |_| |_| |_| |_.__/  |_|   |____/   \___/   \__|       \/      |_| |____/ 
                                                                                          
                                                                                                                                                           
 Zombi Bot V15    | |  Ultra Powerful Priv8 Bot   | |  Code by Viper1337                           
                                             
                      
 [+] ICQ: @viper1337official
 
 [+] Telegram: https://t.me/viper133777


  1. Run Bot Zombi Bot v15 [ New ]
  2. All In One Account Checker
  3. CMS Checker Scanner
  4. PrestaShop Mass Shell upload 
  5. Zombi Bot V15 Scanner Pro
  6. Sub Domain Checker
  7. Viper 1337 SMTP Cracker v3 Pro
  8. Mass Laravel Get Smtp/UploadShell
  9. All CMS BruteForce
  10. Mass Adminpanel Bypass 
  11. Amazon Valid Email Checker 
  12. Viper 1337 0 Day Exploits
  13. Mass zone-h Grabber
  14. Cpanel Cracker V4.0
  15. Mass Create Smtp From Shells
  16. Auto Exploiter Shell Upload Bot
  17. Mass Upload Shell In Wordpress (user&password)
  18. Reverse ip Priv8 Unlimted
  19. Mass Viper1337 Mail Sender
  20. Check For Latest Update
 
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)


logo()


choice=input(' [+] Enter Number : ')
if choice=='1':
  t=input(' [+] Open Tools Tool1 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool1 && chmod +x v15.py list.txt && python v15.py list.txt")
   if system() == 'Windows':
    os.system('cd Tools/Tool1 && v15.py list.txt')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='2':
  t=input(' [+] Open Tools Tool2 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools\Tool2 && chmod +x checker.py list.txt && python checker.py list.txt")
   if system() == 'Windows':
    os.system('cd Tools\Tool2 && checker.py list.txt')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='3':
  t=input(' [+] Open Tools Tool3 And Save your list in folder Tool3 [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools\Tool3 && chmod +x cms.py && python cms.py")
   if system() == 'Windows':
    os.system('cd Tools\Tool3 && cms.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='4':
  t=input(' [+] Open Tools\Tool4 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools\Tool4 && chmod +x Pandshop.py list.txt && python3 Pandshop.py list.txt")
   if system() == 'Windows':
    os.system('cd Tools\Tool4 && Pandshop.py list.txt')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='5':
  t=input(' [+] Open Tools\Tool5 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools\Tool5 && chmod +x main.py && python3 main.py")
   if system() == 'Windows':
    os.system('cd Tools\Tool5 && main.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='6':
  t=input(' [+] Open File Tools/Tool6 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool6 && chmod +x subdoscan.py  && python subdoscan.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool6 && subdoscan.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='7':
  t=input(' [+] Open File Tools\Tool7 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool7 && chmod +x smtp.py && python smtp.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool7 && smtp.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='8':
  t=input(' [+] Open File Tools/Tool8 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool8 && chmod +x laravel.py list.txt && python laravel.py list.txt")
   if system() == 'Windows':
    os.system('cd Tools/Tool8 && laravel.py list.txt')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='9':
  t=input(' [+] Open File Tools/Tool9 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool9 && chmod +x brute.py && python brute.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool9 && brute.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='10':
  t=input(' [+] Open Tools/Tool10 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool10 && chmod +x cms.py && python cms.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool10 && cms.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !') 
if choice=='11':
  t=input(' [+] Open File Tools/Tool11 And Save ==> mail.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool11 && chmod +x amazon.py && python amazon.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool11 && amazon.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !') 
if choice=='12':
  t=input(' [+] Open File Tools/Tool12 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool12 && chmod +x 0day.py && python 0day.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool12 && 0day.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')    
if choice=='13':
  t=input(' [+]  [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool13 && chmod +x grab.py && python grab.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool13 && grab.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')   
if choice=='13':
  t=input('  ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool13 && chmod +x grab.py && python grab.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool13 && grab.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !') 
if choice=='14':
  t=input(' [+] Open File Tools/Tool14 And Save ==> domain.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool14 && chmod +x python bruter.py 50 domain.txt password.txt && python bruter.py 50 domain.txt password.txt")
   if system() == 'Windows':
    os.system('cd Tools/Tool14 && python bruter.py 50 domain.txt password.txt')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='15':
  t=input(' [+] Open File Tools/Tool15 And Save ==> Shells.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool15 && chmod +x v15.py && python v15.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool15 && v15.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='16':
  t=input(' [+] Open File Tools/Tool16 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool16 && chmod +x exploit.py && python exploit.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool16 && exploit.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')  
if choice=='17':
  t=input(' [+] Open File Tools\Tool17 And Save ==> list.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools\Tool17 && chmod +x up.py && python up.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool17 && up.py ')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='18':
  t=input(' [+] Open File Tools/Tool18 And Save ==> ips.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool18 && chmod +x reverseip.py && python reverseip.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool18 && reverseip.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !') 
if choice=='19':
  t=input(' [+] Open File Tools/Tool19 And Save ==> mailers.txt [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool19 && chmod +x private.py && python private.py")
   if system() == 'Windows':
    os.system('cd Tools/Tool19 && private.py')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')
if choice=='20':
  t=input(' [+] You Want Latest Update [y/n] : ')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Tools/Tool20 && chmod +x Update.txt && python Update.txt")
   if system() == 'Windows':
    os.system('cd Tools/Tool20 && Update.txt')
   else:
    print('ERROR GOBLOK !')
  elif t=='n':
   main()
  else :
   print('ERROR GOBLOK !')