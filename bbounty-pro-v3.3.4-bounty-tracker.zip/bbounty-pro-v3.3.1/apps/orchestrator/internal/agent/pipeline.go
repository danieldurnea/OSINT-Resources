package agent

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/billing"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/config"
	"github.com/bbounty-pro/orchestrator/internal/cors"
	"github.com/bbounty-pro/orchestrator/internal/dsl"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/bbounty-pro/orchestrator/internal/manualguide"
	"github.com/bbounty-pro/orchestrator/internal/payloads"
	"github.com/bbounty-pro/orchestrator/internal/profile"
	"github.com/bbounty-pro/orchestrator/internal/ratelimit"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"github.com/bbounty-pro/orchestrator/internal/ws"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
	"github.com/rs/zerolog/log"
	"golang.org/x/sync/errgroup"
	"golang.org/x/time/rate"
)

// ── Constants ─────────────────────────────────────────────────────────────────

const (
	outputBase = "/tmp/bbounty-scans"
	maxRetries = config.MaxToolRetries
)

// ── Phase + Status ────────────────────────────────────────────────────────────

// Lock pattern note: Throughout this file, mutex Lock/Unlock pairs are intentionally
// inline (no defer) for atomic 1-3 line operations. This is safe because:
//   1. No panics possible inside critical sections (no allocs, no I/O, no func calls)
//   2. defer would hold locks longer than needed, hurting contention
//   3. All Unlock calls are unconditional on next 1-3 lines, verified by go vet
// If you add code between Lock/Unlock, switch to defer pattern.

type Phase string
type ScanStatus string

const (
	PhaseAnalyze Phase = "ANALYZE"
	PhasePlan    Phase = "PLAN"
	PhaseExecute Phase = "EXECUTE"
	PhaseIterate Phase = "ITERATE"
)

const (
	StatusQueued  ScanStatus = "queued"
	StatusRunning ScanStatus = "running"
	StatusPaused  ScanStatus = "paused"
	StatusDone    ScanStatus = "done"
	StatusFailed  ScanStatus = "failed"
	StatusAborted ScanStatus = "aborted"
)

// ── LiveStats is broadcast in real-time ───────────────────────────────────────

type LiveStats struct {
	ScanID    string     `json:"scan_id"`
	Phase     Phase      `json:"phase"`
	Status    ScanStatus `json:"status"`
	Subs      int64      `json:"subs"`
	Live      int64      `json:"live"`
	URLs      int64      `json:"urls"`
	Vulns     int64      `json:"vulns"`
	Progress  float64    `json:"progress"`
	StartedAt time.Time  `json:"started_at"`
	Elapsed   float64    `json:"elapsed_sec"`
}

// ── ScanRequest from API ──────────────────────────────────────────────────────

type ScanRequest struct {
	Target    string   `json:"target"`
	Program   string   `json:"program"`
	Tester    string   `json:"tester"`
	Scope     []string `json:"scope"`
	Excluded  []string `json:"excluded"`
	Platform  string   `json:"platform"`
	ToolIDs   []string `json:"tool_ids"`
	MaxConc   int      `json:"max_concurrent"`
	OwnerID   string   `json:"owner_id"`
	Profile   string   `json:"profile,omitempty"`    // profile name: quick/deep/wordpress/api/stealth
	ProgramID string   `json:"program_id,omitempty"` // saved Scope Manager program to enforce against
}

// ── activeScan tracks a running scan ──────────────────────────────────────────

type activeScan struct {
	req       ScanRequest
	cancelFn  context.CancelFunc
	mu        sync.RWMutex
	startedAt time.Time // used by dead scan janitor
	userID    string    // JWT userID — retained for decrementScanRateLimit after request ctx is cancelled

	// FIXED: atomic fields — use atomic.Int64 (Go 1.19+) instead of raw int64.
	subs  atomic.Int64
	live  atomic.Int64
	urls  atomic.Int64
	vulns atomic.Int64

	phase  Phase
	status ScanStatus
}

func (s *activeScan) stats(scanID string) LiveStats {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return LiveStats{
		ScanID: scanID,
		Phase:  s.phase,
		Status: s.status,
		Subs:   s.subs.Load(),
		Live:   s.live.Load(),
		URLs:   s.urls.Load(),
		Vulns:  s.vulns.Load(),
	}
}

// ── Pipeline ──────────────────────────────────────────────────────────────────

// emailSender is a minimal interface so Pipeline doesn't import email package directly.
type emailSender interface {
	SendScanComplete(ctx context.Context, to, username, target string, crit, high, total int, scanID string) error
}

// findingsLister allows pipeline to list findings without importing findings package again.
type findingsLister interface {
	ListByScan(ctx context.Context, scanID string) ([]*findings.Finding, error)
}

// diffSaver is a minimal interface so pipeline doesn't import diff package directly.
type diffSaver interface {
	SaveSnapshot(ctx context.Context, snap interface{}) error
	CompareLatest(ctx context.Context, target string) (interface{}, error)
	ShouldNotifyIface(d interface{}) (bool, string)
}

type Pipeline struct {
	registry *tools.Registry
	hub      *ws.Hub
	gate     *roe.Gate
	findings *findings.Store
	cache    *cache.Client

	checkpoints   *CheckpointStore
	rateLimiter   *ratelimit.Registry
	profileLoader *profile.Loader
	emailSvc      emailSender
	findingsStore *findings.Store
	diffEngine    diffEngineIface
	notifier      notifierIface
	hunterRec     hunterRecorder
	scopeResolver scopeResolver

	scans       map[string]*activeScan
	scansMu     sync.RWMutex
	stopJanitor chan struct{} // closed on shutdown to stop deadScanJanitor goroutine
}

// diffEngineIface allows pipeline to call diff engine without circular import.
type diffEngineIface interface {
	SaveSnapshotRaw(ctx context.Context, target, scanID string, subs, liveHosts, ports, tech interface{}, fs interface{}) error
	CompareLatestRaw(ctx context.Context, target string) (bool, string, error)
}

// notifierIface minimal interface for sending alerts from pipeline.
type notifierIface interface {
	SendText(ctx context.Context, text string) error
}

func NewPipeline(
	r *tools.Registry, h *ws.Hub, g *roe.Gate,
	f *findings.Store, c *cache.Client,
) *Pipeline {
	p := &Pipeline{
		registry: r, hub: h, gate: g,
		findings: f, cache: c,
		scans:       make(map[string]*activeScan),
		stopJanitor: make(chan struct{}),
	}
	// Dead scan janitor — runs every 15 minutes.
	// Cancels and removes scans stuck in running/queued state > 2 hours.
	// Prevents Redis/memory leaks from crashed or abandoned scans.
	// Stopped cleanly on shutdown via p.stopJanitor channel.
	go p.deadScanJanitor()
	return p
}

// deadScanJanitor periodically cancels scans that have been running too long.
// A scan stuck > 2h is almost certainly crashed or orphaned.

// safeReadFile reads a file up to maxBytes — prevents OOM on large scan outputs.
func safeReadFile(path string, maxBytes int64) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return io.ReadAll(io.LimitReader(f, maxBytes))
}

// StopJanitor signals the deadScanJanitor goroutine to exit.
// Call on server shutdown to prevent goroutine leak.
func (p *Pipeline) StopJanitor() {
	close(p.stopJanitor)
}

func (p *Pipeline) deadScanJanitor() {
	const (
		checkInterval = 15 * time.Minute
		maxScanAge    = 2 * time.Hour
	)
	ticker := time.NewTicker(checkInterval)
	defer ticker.Stop()
	for {
		select {
		case <-p.stopJanitor:
			log.Info().Msg("[janitor] stopped — server shutdown")
			return
		case <-ticker.C:
		}
		p.scansMu.Lock()
		now := time.Now()
		for id, scan := range p.scans {
			scan.mu.Lock()
			age := now.Sub(scan.startedAt)
			status := scan.status
			scan.mu.Unlock()

			if (status == StatusRunning || status == StatusQueued) && age > maxScanAge {
				log.Warn().
					Str("scan", id).
					Dur("age", age).
					Str("status", string(status)).
					Msg("[janitor] canceling dead scan")
				scan.cancelFn()
				delete(p.scans, id)
				// Mark as failed in Redis for dashboard visibility
				p.cache.Raw().Set(
					context.Background(),
					"scan:status:"+id,
					"dead",
					24*time.Hour,
				)
				p.broadcastEvent(id, "scan_dead", map[string]string{
					"scan_id": id,
					"reason":  "exceeded max scan age (2h)",
				})
			}
		}
		p.scansMu.Unlock()
	}
}

func (p *Pipeline) SetCheckpointStore(cs *CheckpointStore) { p.checkpoints = cs }
func (p *Pipeline) SetRateLimiter(rl *ratelimit.Registry)  { p.rateLimiter = rl }
func (p *Pipeline) SetProfileLoader(pl *profile.Loader)    { p.profileLoader = pl }

// hunterRecorder records scans for the Hunter Dashboard. Defined with primitive
// args (not the hunter.ScanRecord type) to avoid an import cycle agent→hunter.
type hunterRecorder interface {
	RecordScanStartFields(ctx context.Context, userID, scanID, target, profile string) error
	UpdateScanResultFields(ctx context.Context, scanID, status string, findings map[string]int) error
}

// SetHunterRecorder wires the optional hunter-dashboard recorder.
func (p *Pipeline) SetHunterRecorder(h hunterRecorder) { p.hunterRec = h }

// scopeResolver loads a saved program's scope (Scope Manager). Interface avoids
// an import cycle agent->scope.
type scopeResolver interface {
	ResolveScope(ctx context.Context, userID, programID string) (scope, excluded []string, err error)
}

// SetScopeResolver wires the optional Scope Manager enforcement resolver.
func (p *Pipeline) SetScopeResolver(s scopeResolver) { p.scopeResolver = s }
func (p *Pipeline) SetEmailService(svc emailSender)  { p.emailSvc = svc; p.findingsStore = p.findings }
func (p *Pipeline) SetDiffEngine(de diffEngineIface) { p.diffEngine = de }
func (p *Pipeline) SetNotifier(n notifierIface)      { p.notifier = n }

// HandleStart validates ROE, creates a scan, and launches the pipeline.
func (p *Pipeline) HandleStart(w http.ResponseWriter, r *http.Request) {
	// ── Per-user scan limit bazat pe JWT userID ───────────────────────────────
	// FIX: folosim userID din JWT, nu IP sau header.
	// IP/header = bypass trivial via VPN sau alt tab.
	// userID din JWT = legat de cont, imposibil de bypass fără alt cont plătit.
	userID := fmt.Sprintf("%v", r.Context().Value("userID"))
	if userID == "" || userID == "<nil>" {
		http.Error(w, `{"error":"not authenticated"}`, http.StatusUnauthorized)
		return
	}

	// Verifică limita de scanuri concurente per user (din plan)
	if err := p.checkScanRateLimit(r.Context(), userID); err != nil {
		w.Header().Set("Retry-After", "60")
		http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusTooManyRequests)
		return
	}

	var req ScanRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}

	// Scope Manager enforcement (v3.3.4): if the request references a saved
	// program, load its scope server-side and enforce against THAT — so a client
	// cannot bypass scope by submitting an empty/forged scope list. The program's
	// scope is merged in (it takes precedence as the source of truth).
	if req.ProgramID != "" && p.scopeResolver != nil {
		uid := fmt.Sprintf("%v", r.Context().Value("userID"))
		scope, excluded, err := p.scopeResolver.ResolveScope(r.Context(), uid, req.ProgramID)
		if err != nil {
			http.Error(w, `{"error":"saved program not found for this user"}`, http.StatusBadRequest)
			return
		}
		req.Scope, req.Excluded = scope, excluded
	}

	if err := p.gate.Validate(req.Target, req.Scope, req.Excluded); err != nil {
		http.Error(w, fmt.Sprintf(`{"error":"ROE violation: %s"}`, err), http.StatusForbidden)
		return
	}
	if req.MaxConc <= 0 {
		req.MaxConc = config.MaxConcurrentTools
	}

	// Apply profile if specified — overrides tool_ids and max_concurrent
	if req.Profile != "" && p.profileLoader != nil {
		if prof := p.profileLoader.Get(req.Profile); prof != nil {
			// Profile tools override manual tool selection
			if len(req.ToolIDs) == 0 {
				req.ToolIDs = prof.Tools
			}
			if req.MaxConc == 8 && prof.MaxConcurrent > 0 {
				req.MaxConc = prof.MaxConcurrent
			}
			log.Info().Str("profile", prof.Name).
				Int("tools", len(req.ToolIDs)).
				Msg("pipeline: profile applied")
		} else {
			log.Warn().Str("profile", req.Profile).Msg("pipeline: unknown profile — ignored")
		}
	}

	scanID := uuid.New().String()
	// Scan context from Background() — scan outlives HTTP request.
	// userID is retained in scan.userID (below) for use after the request
	// ctx is cancelled; nothing in the scan goroutine reads JWT claims back
	// off the context, so we do not copy them onto the background context.
	ctx, cancel := context.WithCancel(context.Background())

	scan := &activeScan{
		req:       req,
		cancelFn:  cancel,
		phase:     PhaseAnalyze,
		status:    StatusQueued,
		startedAt: time.Now(),
		userID:    userID, // store for decrementScanRateLimit after ctx cancel
	}

	p.scansMu.Lock()
	p.scans[scanID] = scan
	p.scansMu.Unlock()

	// Debit billing AFTER scan is stored — only charge on successful scan creation
	billing.DebitScan(r.Context())

	// Store scan ownership + user info in Redis for:
	// 1. Findings ownership check (auth middleware)
	// 2. Scan complete email notification
	scanTTL := 48 * time.Hour
	p.cache.Raw().Set(context.Background(), "scan:owner:"+scanID,
		fmt.Sprintf("%v", r.Context().Value("userID")), scanTTL)
	if userEmail, _ := p.cache.Raw().Get(context.Background(),
		"user:email:"+fmt.Sprintf("%v", r.Context().Value("userID"))).Result(); userEmail != "" {
		p.cache.Raw().Set(context.Background(), "scan:email:"+scanID, userEmail, scanTTL)
	}
	if username, _ := p.cache.Raw().Get(context.Background(),
		"user:username:"+fmt.Sprintf("%v", r.Context().Value("userID"))).Result(); username != "" {
		p.cache.Raw().Set(context.Background(), "scan:user:"+scanID, username, scanTTL)
	}

	// Hunter Dashboard (v3.3.4): record the scan in the user's history index.
	if p.hunterRec != nil {
		uid := fmt.Sprintf("%v", r.Context().Value("userID"))
		if err := p.hunterRec.RecordScanStartFields(context.Background(), uid, scanID, scan.req.Target, scan.req.Profile); err != nil {
			log.Warn().Err(err).Str("scan", scanID).Msg("hunter: failed to record scan start")
		}
	}

	go p.run(ctx, scanID, scan)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusAccepted)
	json.NewEncoder(w).Encode(map[string]string{
		"scan_id": scanID,
		"ws_url":  fmt.Sprintf("/ws/pipeline/%s", scanID),
	})
}

// run executes the 4-phase pipeline.
func (p *Pipeline) run(ctx context.Context, scanID string, scan *activeScan) {
	start := time.Now()

	defer func() {
		scan.mu.Lock()
		scan.status = StatusDone
		scan.mu.Unlock()
		p.broadcastStats(scanID, scan, start)
		go CleanOldOutputs(config.OldOutputAge)
		log.Info().Str("scan", scanID).Dur("elapsed", time.Since(start)).Msg("scan complete")

		// Hunter Dashboard (v3.3.4): update the scan record with final status +
		// finding counts by severity. Background, never blocks.
		if p.hunterRec != nil {
			go func() {
				ctx2, cancel := context.WithTimeout(context.Background(), 15*time.Second)
				defer cancel()
				allF, _ := p.findings.ListByScan(ctx2, scanID)
				counts := map[string]int{}
				for _, f := range allF {
					counts[string(f.Severity)]++
				}
				if err := p.hunterRec.UpdateScanResultFields(ctx2, scanID, "done", counts); err != nil {
					log.Debug().Err(err).Str("scan", scanID).Msg("hunter: result update skipped")
				}
			}()
		}

		// Decrement concurrent scan counter — eliberează slot pentru userul ăsta
		go p.decrementScanRateLimit(context.Background(), scan.userID) // use scan.userID — ctx.Value("userID") is nil after WithCancel(context.Background())

		// ── Notify scan complete via Telegram/Slack/Discord ──────────────────
		if p.notifier != nil {
			go func() {
				ctx2, cancel := context.WithTimeout(context.Background(), 10*time.Second)
				defer cancel()
				allF, _ := p.findings.ListByScan(ctx2, scanID)
				crit, high, med := 0, 0, 0
				for _, f := range allF {
					switch f.Severity {
					case "critical":
						crit++
					case "high":
						high++
					case "medium":
						med++
					}
				}
				_ = p.notifier.SendText(ctx2, fmt.Sprintf(
					"[BBounty] Scan finished: %s | %d findings (crit:%d high:%d med:%d) | %s",
					scan.req.Target, len(allF), crit, high, med, time.Since(start).Round(time.Second),
				))
			}()
		}

		// ── Send scan complete email ──────────────────────────────────────────
		// Count findings by severity and notify the user that the scan finished.
		// Runs in background — never blocks the pipeline.
		if p.emailSvc != nil {
			go func() {
				ctx2, cancel := context.WithTimeout(context.Background(), 15*time.Second)
				defer cancel()
				allFindings, err := p.findings.ListByScan(ctx2, scanID)
				if err != nil {
					return
				}
				crit, high := 0, 0
				for _, f := range allFindings {
					switch f.Severity {
					case "critical":
						crit++
					case "high":
						high++
					}
				}
				// Get user email from Redis (stored when scan starts)
				userEmail, _ := p.cache.Raw().Get(ctx2, "scan:email:"+scanID).Result()
				username, _ := p.cache.Raw().Get(ctx2, "scan:user:"+scanID).Result()
				if userEmail != "" {
					if err := p.emailSvc.SendScanComplete(
						ctx2, userEmail, username, scan.req.Target,
						crit, high, len(allFindings), scanID,
					); err != nil {
						log.Warn().Err(err).Str("scan", scanID).Msg("[email] scan complete email failed")
					}
				}
			}()
		}

		// ── Asset DB: save snapshot + compare with previous scan ──────────────
		// This is the continuous monitoring core:
		// 1. Save current scan state (subdomains, ports, tech, findings)
		// 2. Compare with last snapshot for same target
		// 3. Alert on delta (new subdomain, new finding, port change)
		if p.diffEngine != nil {
			go func() {
				ctx2, cancel := context.WithTimeout(context.Background(), 30*time.Second)
				defer cancel()

				// Read subdomains from scan output
				subsFile := filepath.Join(outputBase, scanID[:8], scanID[:8]+"_subs.txt")
				var subs []string
				if data, err := safeReadFile(subsFile, 10<<20); err == nil {
					for _, line := range strings.Split(string(data), "\n") {
						if line = strings.TrimSpace(line); line != "" {
							subs = append(subs, line)
						}
					}
				}

				// Get findings for this scan
				allFindings, _ := p.findings.ListByScan(ctx2, scanID)
				findingIDs := make([]string, 0, len(allFindings))
				for _, f := range allFindings {
					findingIDs = append(findingIDs, f.ID)
				}

				// Save snapshot to Redis (90-day retention via TTL)
				if err := p.diffEngine.SaveSnapshotRaw(
					ctx2, scan.req.Target, scanID,
					subs, nil, nil, nil, findingIDs,
				); err != nil {
					log.Warn().Err(err).Msg("[diff] save snapshot failed")
					return
				}

				// Compare with previous scan — alert on delta
				shouldAlert, summary, err := p.diffEngine.CompareLatestRaw(ctx2, scan.req.Target)
				if err != nil {
					log.Debug().Err(err).Msg("[diff] compare failed (first scan?)")
					return
				}
				if shouldAlert && summary != "" {
					log.Info().Str("target", scan.req.Target).Str("delta", summary).Msg("[diff] new assets detected")
					p.broadcastEvent(scanID, "diff_alert", map[string]string{
						"target":  scan.req.Target,
						"summary": summary,
					})
				}
			}()
		}
	}()

	phases := []struct {
		phase   Phase
		toolSet string
	}{
		{PhaseAnalyze, tools.PhaseRecon},
		{PhasePlan, tools.PhaseEnum},
		{PhaseExecute, tools.PhaseScan},
		{PhaseIterate, tools.PhaseExploit},
	}

	sem := NewSemaphore(scan.req.MaxConc)

	// outDir is used by both runPhase (tool execution) and analyzeOutputs (conditional chaining)
	// SF-5: private 0700 dir; fallback is also private (never bare /tmp).
	outDir := secureOutputDir(scanID)

	// Load profile conditions (nil-safe)
	var cond profile.Conditions
	if p.profileLoader != nil && scan.req.Profile != "" {
		if prof := p.profileLoader.Get(scan.req.Profile); prof != nil {
			cond = prof.Conditions
			log.Info().Str("profile", scan.req.Profile).Msg("pipeline: using scan profile")
		}
	}

	// v3.3.4: when enabled, drop the curated payload wordlists into the scan dir
	// so disk-based fuzzers (ffuf/dalfox/nuclei-fuzz) can reference them via
	// $PAYLOADS_DIR. Opt-in (custom_payloads) → default scans unchanged. The set
	// is small/curated by design (≈50/category) to keep fuzzing fast.
	if cond.CustomPayloads {
		written := payloads.WriteWordlists(outDir, func(name string, content []byte) error {
			return os.WriteFile(filepath.Join(outDir, name), content, 0o600)
		})
		log.Info().Int("wordlists", len(written)).Int("total_payloads", payloads.Total()).
			Str("dir", outDir).Msg("pipeline: curated payload wordlists written")
		p.broadcastEvent(scanID, "payloads_ready", map[string]string{
			"wordlists": fmt.Sprintf("%d", len(written)),
			"payloads":  fmt.Sprintf("%d", payloads.Total()),
		})
	}

	// injectedScan/Exploit hold tools added by conditional chaining mid-run
	var injectedScanTools []string
	var injectedExploitTools []string

	for _, ph := range phases {
		select {
		case <-ctx.Done():
			scan.mu.Lock()
			scan.status = StatusAborted
			scan.mu.Unlock()
			return
		default:
		}

		scan.mu.Lock()
		scan.phase = ph.phase
		scan.status = StatusRunning
		scan.mu.Unlock()

		p.broadcastStats(scanID, scan, start)
		p.broadcastEvent(scanID, "phase_start", map[string]string{"phase": string(ph.phase)})

		// Persist checkpoint so we can resume if the process restarts.
		if p.checkpoints != nil {
			_ = p.checkpoints.Save(ctx, &Checkpoint{
				ScanID:    scanID,
				Phase:     ph.phase,
				Request:   scan.req,
				UpdatedAt: time.Now(),
			})
		}

		toolList := p.filterTools(scan.req.ToolIDs, ph.toolSet)

		// Merge conditionally injected tools for this phase
		switch ph.phase {
		case PhaseExecute:
			for _, id := range injectedScanTools {
				if t, ok := p.registry.Get(id); ok && t != nil {
					toolList = append(toolList, t)
					p.broadcastEvent(scanID, "tool_injected", map[string]string{
						"tool_id": id, "reason": "conditional_chain",
					})
					log.Info().Str("tool", id).Str("phase", "scan").Msg("pipeline: conditional tool injected")
				}
			}
		case PhaseIterate:
			for _, id := range injectedExploitTools {
				if t, ok := p.registry.Get(id); ok && t != nil {
					toolList = append(toolList, t)
					p.broadcastEvent(scanID, "tool_injected", map[string]string{
						"tool_id": id, "reason": "conditional_chain",
					})
					log.Info().Str("tool", id).Str("phase", "exploit").Msg("pipeline: conditional tool injected")
				}
			}
		}

		if err := p.runPhase(ctx, scanID, scan, sem, toolList); err != nil {
			p.broadcastEvent(scanID, "phase_error", map[string]string{
				"phase": string(ph.phase), "error": err.Error(),
			})
		}

		// Real scope enforcement on tool output files
		p.filterOutputsInScope(scanID, scan)

		// Conditional analysis — inject tools into subsequent phases
		injected := analyzeOutputs(scanID, outDir, cond)
		injectedScanTools = mergeUnique(injectedScanTools, injected.ScanTools)
		injectedExploitTools = mergeUnique(injectedExploitTools, injected.ExploitTools)
		for _, reason := range injected.Reasons {
			p.broadcastEvent(scanID, "condition_triggered", map[string]string{
				"reason": reason, "phase": string(ph.phase),
			})
		}
	}

	// T3 (v3.3.4): opt-in DSL content scan. After all phases, if the profile
	// enables it, run the regex secret/content engine over any JS/HAR/response
	// files crawlers (katana/cariddi/gospider/hakrawler) left in outDir. Default
	// OFF → zero change to existing behaviour. Scans files ALREADY on disk only
	// (no new network fetches).
	if cond.DSLScan {
		p.runDSLScan(ctx, scanID, scan, outDir)
	}

	// v3.3.4: generate a target-tailored MANUAL testing guide after automation.
	// Always on (cheap, text-only) — complements the automated findings with the
	// human-judgement steps (business logic, IDOR, auth bypass) adapted to the
	// detected stack/WAF. Best-effort; never blocks scan completion.
	p.generateManualGuide(ctx, scanID, scan, outDir)
}

// runDSLScan walks outDir for scannable content (JS files, HAR archives, stored
// HTTP responses) and runs the embedded DSL engine over them, persisting any
// secrets/tokens/cloud-assets it finds as regular findings. Best-effort: any
// per-file error is logged and skipped so a single bad file can't abort the scan.
func (p *Pipeline) runDSLScan(ctx context.Context, scanID string, scan *activeScan, outDir string) {
	rules, err := dsl.LoadDefaultRules()
	if err != nil {
		log.Warn().Err(err).Msg("dsl: load rules failed")
		return
	}
	if err := dsl.CompileRules(rules); err != nil {
		log.Warn().Err(err).Msg("dsl: compile rules failed")
		return
	}
	engine := dsl.NewEngine(rules)

	// v3.3.4+: download discovered .js URLs into outDir/js/ so the engine has
	// actual JS bodies to scan (crawlers write URL lists, not bodies). Best-effort
	// and bounded; if nothing is downloaded, the walk below still scans any JS/HAR/
	// response files already on disk.
	jsDir := filepath.Join(outDir, "js")
	if n := p.downloadJSForDSL(ctx, scanID, outDir, jsDir); n > 0 {
		log.Info().Int("downloaded", n).Msg("dsl: downloaded JS files for scanning")
	}

	scanned := 0
	_ = filepath.WalkDir(outDir, func(path string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return nil
		}
		// Cap files scanned to avoid pathological runs.
		if scanned > 5000 {
			return filepath.SkipAll
		}
		name := strings.ToLower(d.Name())
		switch {
		case strings.HasSuffix(name, ".js"):
			if e := engine.ScanJSFile(path); e == nil {
				scanned++
			}
		case strings.HasSuffix(name, ".har"):
			_ = engine.ScanHAR(path)
			_ = engine.ScanHARHeaders(path)
			scanned++
		case strings.HasSuffix(name, ".html") || strings.HasSuffix(name, ".txt"):
			// stored responses / body dumps — scan as JS-style content (line regex)
			if e := engine.ScanJSFile(path); e == nil {
				scanned++
			}
		}
		return nil
	})

	found := engine.ToFindings(scanID)
	if len(found) > 0 {
		p.saveFindings(ctx, scanID, scan, found)
	}
	log.Info().Int("files", scanned).Int("findings", len(found)).
		Msg("pipeline: DSL content scan complete")
	p.broadcastEvent(scanID, "dsl_scan_complete", map[string]string{
		"files":    fmt.Sprintf("%d", scanned),
		"findings": fmt.Sprintf("%d", len(found)),
	})
}

// generateManualGuide writes a target-tailored manual-testing checklist to
// outDir (manual_guide.md) and records its path. It reads detected technologies
// and WAF from the scan's output files and the already-stored finding categories,
// then renders the guide. Best-effort: any error is logged, never fatal.
func (p *Pipeline) generateManualGuide(ctx context.Context, scanID string, scan *activeScan, outDir string) {
	sig := manualguide.Signals{
		Domain:  scan.req.Target,
		BaseURL: "",
	}

	// Detected technologies / WAF — scan the whatweb/wafw00f outputs if present.
	s8 := scanID[:8]
	if data, err := safeReadFile(filepath.Join(outDir, s8+"_whatweb.json"), 5<<20); err == nil {
		sig.Technologies = detectTechNames(string(data))
	}
	if data, err := safeReadFile(filepath.Join(outDir, s8+"_waf.json"), 1<<20); err == nil {
		sig.WAF = detectWAFName(string(data))
	}

	// Finding categories already produced by automation (for prioritised follow-ups).
	if p.findings != nil {
		if list, err := p.findings.ListByScan(ctx, scanID); err == nil {
			seen := map[string]bool{}
			for _, f := range list {
				if f.Category != "" && !seen[f.Category] {
					seen[f.Category] = true
					sig.FindingCategs = append(sig.FindingCategs, f.Category)
				}
			}
		}
	}

	guide := manualguide.Generate(sig)
	dst := filepath.Join(outDir, "manual_guide.md")
	if err := os.WriteFile(dst, []byte(guide), 0o600); err != nil {
		log.Warn().Err(err).Msg("pipeline: manual guide write failed")
		return
	}
	log.Info().Str("file", dst).Int("techs", len(sig.Technologies)).
		Str("waf", sig.WAF).Msg("pipeline: manual testing guide generated")
	p.broadcastEvent(scanID, "manual_guide_ready", map[string]string{
		"file": "manual_guide.md",
	})
}

// detectTechNames extracts a small set of known technology names from a scan
// output blob (whatweb JSON or similar). Heuristic + case-insensitive.
func detectTechNames(blob string) []string {
	low := strings.ToLower(blob)
	candidates := []string{
		"WordPress", "Joomla", "Drupal", "Laravel", "Django", "Rails",
		"Express", "nginx", "Apache", "PHP", "ASP.NET", "Tomcat", "Spring",
	}
	var out []string
	for _, c := range candidates {
		if strings.Contains(low, strings.ToLower(c)) {
			out = append(out, c)
		}
	}
	return out
}

// detectWAFName pulls a WAF/CDN name out of a wafw00f JSON blob, best-effort.
func detectWAFName(blob string) string {
	low := strings.ToLower(blob)
	wafs := map[string]string{
		"cloudflare": "Cloudflare", "akamai": "Akamai", "sucuri": "Sucuri",
		"imperva": "Imperva", "incapsula": "Imperva Incapsula", "aws": "AWS WAF",
		"f5": "F5 BIG-IP", "barracuda": "Barracuda", "fortinet": "Fortinet",
	}
	for k, v := range wafs {
		if strings.Contains(low, k) {
			return v
		}
	}
	return ""
}

// isInternalOrMetadataURL reports whether a URL points at localhost, a private
// network, or a cloud metadata endpoint — such hosts must never be fetched by
// the orchestrator (SSRF protection for the JS-download step). Mirrors the
// blocklist used by tools.SafeTarget.
func isInternalOrMetadataURL(raw string) bool {
	u, err := url.Parse(raw)
	if err != nil {
		return true // unparseable → refuse to fetch
	}
	host := strings.ToLower(u.Hostname())
	if host == "" {
		return true
	}
	blocked := []string{
		"localhost", "127.", "::1", "0.0.0.0",
		"10.", "192.168.", "169.254.",
		"172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.",
		"172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.",
		"172.28.", "172.29.", "172.30.", "172.31.",
		"metadata.google", "metadata.azure", "169.254.169.254",
		"fd00:", "fc00:",
	}
	for _, b := range blocked {
		if host == b || strings.HasPrefix(host, b) {
			return true
		}
	}
	return false
}

// downloadJSForDSL extracts .js URLs from the scan's discovered-URL files and
// downloads them into jsDir so the DSL engine can scan their bodies. Crawlers
// (katana/gospider/hakrawler/gau) emit URL *lists*; this turns the relevant ones
// into on-disk files. Strictly bounded (count, size, time) and best-effort:
// failures are skipped, never abort the scan. Returns the number of files written.
func (p *Pipeline) downloadJSForDSL(ctx context.Context, scanID, outDir, jsDir string) int {
	const (
		maxFiles   = 300              // cap total JS files fetched
		maxBytes   = 5 << 20          // 5 MiB per file
		perReqTime = 15 * time.Second // per-download timeout
	)

	// Gather candidate URL files (the shared list + common crawler outputs).
	s8 := scanID[:8]
	candidates := []string{
		filepath.Join(outDir, s8+"_urls.txt"),
		filepath.Join(outDir, s8+"_katana.txt"),
		filepath.Join(outDir, s8+"_gospider.txt"),
		filepath.Join(outDir, s8+"_hakrawler.txt"),
		filepath.Join(outDir, s8+"_gau.txt"),
	}

	// Collect unique .js URLs.
	seen := make(map[string]bool)
	var jsURLs []string
	for _, f := range candidates {
		data, err := safeReadFile(f, 20<<20)
		if err != nil {
			continue
		}
		for _, line := range strings.Split(string(data), "\n") {
			u := strings.TrimSpace(line)
			if u == "" || seen[u] {
				continue
			}
			// match .js (optionally followed by ? or #) and http(s) scheme
			low := strings.ToLower(u)
			if !strings.HasPrefix(low, "http") {
				continue
			}
			base := low
			if i := strings.IndexAny(base, "?#"); i >= 0 {
				base = base[:i]
			}
			if strings.HasSuffix(base, ".js") {
				// SSRF guard (v3.3.4): never fetch internal/metadata hosts — a
				// malicious target could plant a link to 169.254.169.254 or an
				// internal service. Mirror SafeTarget's blocklist.
				if isInternalOrMetadataURL(u) {
					seen[u] = true
					continue
				}
				seen[u] = true
				jsURLs = append(jsURLs, u)
			}
		}
	}
	if len(jsURLs) == 0 {
		return 0
	}
	if len(jsURLs) > maxFiles {
		jsURLs = jsURLs[:maxFiles]
	}

	if err := os.MkdirAll(jsDir, 0o700); err != nil {
		log.Warn().Err(err).Msg("dsl: cannot create js dir")
		return 0
	}

	client := &http.Client{Timeout: perReqTime}
	written := 0
	for i, u := range jsURLs {
		select {
		case <-ctx.Done():
			return written
		default:
		}
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", "BBountyPro-DSL/1.0")
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		if resp.StatusCode != http.StatusOK {
			resp.Body.Close()
			continue
		}
		body, err := io.ReadAll(io.LimitReader(resp.Body, maxBytes))
		resp.Body.Close()
		if err != nil || len(body) == 0 {
			continue
		}
		dst := filepath.Join(jsDir, fmt.Sprintf("%05d.js", i))
		if err := os.WriteFile(dst, body, 0o600); err == nil {
			written++
		}
	}
	return written
}

// runPhase executes all tools in a phase with the shared semaphore.
func (p *Pipeline) runPhase(
	ctx context.Context, scanID string, scan *activeScan,
	sem *Semaphore, toolList []*tools.Tool,
) error {
	// Per-phase rate limiter shared across all tools.
	// Profile rate_limit overrides default 20 req/s.
	rateLimit := float64(20)
	if scan.req.Profile != "" && p.profileLoader != nil {
		if prof := p.profileLoader.Get(scan.req.Profile); prof != nil && prof.RateLimit > 0 {
			rateLimit = float64(prof.RateLimit)
		}
	}
	limiter := rate.NewLimiter(rate.Limit(rateLimit), int(rateLimit))

	g, gctx := errgroup.WithContext(ctx)

	// Split tools: parallel ones run concurrently, serial ones run in order
	// but still inside goroutines so they don't block the errgroup.
	var serialTools []*tools.Tool
	for _, tool := range toolList {
		tool := tool // capture
		if tool.Parallel {
			// Parallel tool → own goroutine, semaphore controls max concurrency
			g.Go(func() error {
				if err := p.executeTool(gctx, scanID, scan, tool, limiter, sem); err != nil {
					log.Warn().Err(err).Str("tool", tool.ID).Msg("tool error")
				}
				return nil // non-fatal — log and continue
			})
		} else {
			serialTools = append(serialTools, tool)
		}
	}

	// Serial tools run sequentially in a single goroutine
	// so they don't interleave (e.g. sqlmap after gf finds SQLi params)
	if len(serialTools) > 0 {
		g.Go(func() error {
			for _, tool := range serialTools {
				select {
				case <-gctx.Done():
					return gctx.Err()
				default:
				}
				if err := p.executeTool(gctx, scanID, scan, tool, limiter, sem); err != nil {
					log.Warn().Err(err).Str("tool", tool.ID).Msg("serial tool error")
				}
			}
			return nil
		})
	}

	return g.Wait()
}

// executeTool runs a single tool with retry and live streaming.
func (p *Pipeline) executeTool(
	ctx context.Context, scanID string, scan *activeScan,
	tool *tools.Tool, limiter *rate.Limiter, sem *Semaphore,
) error {
	if err := sem.Acquire(ctx); err != nil {
		return err
	}
	defer sem.Release()

	if err := limiter.Wait(ctx); err != nil {
		return err
	}

	// ── Native tools: Go functions, no subprocess ─────────────────────────────
	// These run directly in the orchestrator process — fully parallel,
	// no shell overhead, no binary dependency.
	if tool.Native {
		return p.executeNativeTool(ctx, scanID, scan, tool)
	}

	// SF-5: private 0700 dir; fallback is also private (never bare /tmp).
	outDir := secureOutputDir(scanID)

	// FIXED: use tools.BuildCommand() — single source of truth, no duplicates.
	// Returns "" if target failed strict sanitisation; skip the tool in that
	// case rather than spawning bash with a malformed command line.
	cmd := tools.BuildCommand(tool, tools.BuildContext{
		Target: scan.req.Target,
		ScanID: scanID,
		OutDir: outDir,
		Scope:  scan.req.Scope,
	})
	if cmd == "" {
		log.Warn().Str("tool", tool.ID).Str("target", scan.req.Target).
			Msg("pipeline: skipping tool — target failed strict sanitisation")
		p.broadcastEvent(scanID, "tool_skipped", map[string]string{
			"tool_id": tool.ID, "reason": "unsafe_target",
		})
		return nil
	}
	if tool.Phase == tools.PhaseRecon || tool.Phase == tools.PhaseEnum {
		cmd = tools.ScopeFilter(cmd, scan.req.Scope)
	}

	p.broadcastEvent(scanID, "tool_start", map[string]string{
		"tool_id":  tool.ID,
		"tool":     tool.Name,
		"phase":    tool.Phase,
		"parallel": fmt.Sprintf("%v", tool.Parallel),
	})

	var lastErr error
	for attempt := 0; attempt <= maxRetries; attempt++ {
		if attempt > 0 {
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(time.Duration(attempt*5) * time.Second):
			}
		}
		var buf bytes.Buffer
		lastErr = p.shell(ctx, cmd, tool, scanID, &buf, scan.req.Target, scan.req.Platform)
		if buf.Len() > 0 {
			if found, err := tools.Parse(tool.ID, &buf, scanID); err == nil {
				p.saveFindings(ctx, scanID, scan, found)
			}
			if p.rateLimiter != nil && (tool.ID == "httpx" || tool.ID == "nuclei") {
				p.observeHTTPStatuses(scan.req.Target, scan.req.Platform, &buf)
			}
		}

		// ── nuclei-fuzz special handling ──────────────────────────────────────
		// nuclei-fuzz writes findings to its -json-export file (scanID8_nuclei_fuzz.json),
		// while stdout (2>&1) carries scan logs — so the buf parse above won't see
		// them. Read the file after the process exits and ingest (same JSON format
		// as nuclei). Mirrors the afrog handling below.
		if tool.ID == "nuclei-fuzz" && lastErr == nil {
			fuzzFile := filepath.Join(outDir, scanID[:8]+"_nuclei_fuzz.json")
			if data, err := safeReadFile(fuzzFile, 25<<20); err == nil {
				if found, perr := tools.Parse("nuclei-fuzz", bytes.NewReader(data), scanID); perr == nil {
					p.saveFindings(ctx, scanID, scan, found)
					log.Info().Int("findings", len(found)).
						Str("file", fuzzFile).Msg("pipeline: nuclei-fuzz output integrated")
					p.broadcastEvent(scanID, "nuclei_fuzz_parsed", map[string]string{
						"findings": fmt.Sprintf("%d", len(found)),
					})
				} else {
					log.Warn().Err(perr).Str("file", fuzzFile).Msg("pipeline: nuclei-fuzz parse failed")
				}
			}
		}

		// ── reconFTW special handling ─────────────────────────────────────────
		// After reconFTW finishes, parse its output directory and feed the
		// results into both the findings store and the pipeline's canonical
		// output files (so conditional chaining can pick up signals).
		if tool.ID == "reconftw" && lastErr == nil {
			reconFTWDir := p.reconFTWOutputDir(scan.req.Target)
			if r, err := tools.ParseReconFTWOutput(scanID, reconFTWDir); err == nil {
				// Save findings from reconFTW to Redis
				p.saveFindings(ctx, scanID, scan, r.Findings)
				// Write subs/hosts/signals to pipeline canonical files
				tools.WriteReconFTWToPipeline(outDir, scanID, r)
				log.Info().
					Int("findings", len(r.Findings)).
					Int("subs", len(r.Subdomains)).
					Int("hosts", len(r.LiveHosts)).
					Msg("pipeline: reconFTW output integrated")
				p.broadcastEvent(scanID, "reconftw_parsed", map[string]string{
					"findings": fmt.Sprintf("%d", len(r.Findings)),
					"subs":     fmt.Sprintf("%d", len(r.Subdomains)),
					"hosts":    fmt.Sprintf("%d", len(r.LiveHosts)),
				})
			} else {
				log.Warn().Err(err).Str("dir", reconFTWDir).Msg("pipeline: reconFTW output parse failed")
			}
		}
		// ── afrog special handling ────────────────────────────────────────────
		// afrog writes findings to its `-json` file (scanID8_afrog.json), NOT to
		// stdout, so the buf-based Parse() above never sees them. Read the file
		// after the process exits and ingest. afrog only appends the closing `]`
		// at scan completion; ParseAfrogOutput tolerates a partial array.
		if tool.ID == "afrog" && lastErr == nil {
			afrogFile := filepath.Join(outDir, scanID[:8]+"_afrog.json")
			if data, err := safeReadFile(afrogFile, 25<<20); err == nil {
				if found, perr := tools.Parse("afrog", bytes.NewReader(data), scanID); perr == nil {
					p.saveFindings(ctx, scanID, scan, found)
					log.Info().Int("findings", len(found)).
						Str("file", afrogFile).Msg("pipeline: afrog output integrated")
					p.broadcastEvent(scanID, "afrog_parsed", map[string]string{
						"findings": fmt.Sprintf("%d", len(found)),
					})
				} else {
					log.Warn().Err(perr).Str("file", afrogFile).Msg("pipeline: afrog output parse failed")
				}
			}
		}

		if lastErr == nil || ctx.Err() != nil {
			break
		}
	}

	p.broadcastEvent(scanID, "tool_done", map[string]string{
		"tool_id": tool.ID, "status": errStatus(lastErr),
	})
	return lastErr
}

// executeNativeTool dispatches to built-in Go implementations.
// These run inside the orchestrator process — fully parallel, no subprocess.
func (p *Pipeline) executeNativeTool(
	ctx context.Context, scanID string, scan *activeScan,
	tool *tools.Tool,
) error {
	p.broadcastEvent(scanID, "tool_start", map[string]string{
		"tool_id":  tool.ID,
		"tool":     tool.Name,
		"phase":    tool.Phase,
		"parallel": "true",
		"native":   "true",
	})

	timeout := time.Duration(tool.Timeout) * time.Second
	if timeout <= 0 {
		timeout = 120 * time.Second
	}
	tctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	var err error

	switch tool.ID {
	case "cors-engine":
		err = p.runCORSEngine(tctx, scanID, scan)

	default:
		log.Warn().Str("tool", tool.ID).Msg("pipeline: unknown native tool — skipped")
	}

	status := "ok"
	if err != nil {
		status = "error"
		log.Warn().Err(err).Str("tool", tool.ID).Msg("pipeline: native tool error")
	}
	p.broadcastEvent(scanID, "tool_done", map[string]string{
		"tool_id": tool.ID, "status": status,
	})
	return err
}

// runCORSEngine runs the built-in CORS testing engine against discovered live hosts.
// It reads the httpx output file for live URLs, then tests all CORS vectors in parallel.
func (p *Pipeline) runCORSEngine(ctx context.Context, scanID string, scan *activeScan) error {
	outDir := filepath.Join("/tmp/bbounty-scans", scanID[:8])
	target := scan.req.Target

	// Collect URLs to test:
	// 1. Primary target
	// 2. Any live hosts discovered by httpx in this scan
	urls := []string{
		"https://" + target,
		"http://" + target,
	}

	// Parse httpx output if available
	httpxFile := filepath.Join(outDir, scanID[:8]+"_httpx.txt")
	if data, err := safeReadFile(httpxFile, 10<<20); err == nil {
		for _, line := range splitLines(string(data)) {
			line = trimLine(line)
			if line != "" && (hasPrefix(line, "http://") || hasPrefix(line, "https://")) {
				urls = append(urls, line)
			}
		}
	}

	// Deduplicate
	seen := make(map[string]bool)
	var deduped []string
	for _, u := range urls {
		if !seen[u] {
			seen[u] = true
			deduped = append(deduped, u)
		}
	}

	log.Info().
		Str("target", target).
		Int("urls", len(deduped)).
		Msg("[cors-engine] starting parallel CORS tests")

	engine := cors.New()
	corsFindings := engine.TestTargets(ctx, deduped)

	if len(corsFindings) == 0 {
		log.Info().Str("target", target).Msg("[cors-engine] no CORS vulnerabilities found")
		return nil
	}

	// Convert cors.Finding → findings.Finding and save
	for _, cf := range corsFindings {
		sev := findings.Severity(cf.Severity)
		f := &findings.Finding{
			ScanID:     scanID,
			Title:      fmt.Sprintf("CORS: %s — %s", cf.Vector, cf.URL),
			Severity:   sev,
			URL:        cf.URL,
			Category:   "cors",
			Payload:    cf.PoC,
			Response:   cf.Description,
			Source:     "cors-engine",
			AIAnalysis: cf.Remediation,
			Tags:       []string{"cors", cf.Vector},
		}
		p.saveFindings(ctx, scanID, scan, []*findings.Finding{f})

		// Notify on critical/high via WebSocket
		p.broadcastEvent(scanID, "finding", map[string]string{
			"tool_id":  "cors-engine",
			"severity": string(sev),
			"title":    f.Title,
			"url":      f.URL,
		})

		log.Info().
			Str("vector", cf.Vector).
			Str("severity", string(sev)).
			Str("url", cf.URL).
			Msg("[cors-engine] CORS vulnerability found")
	}

	return nil
}

// ── String helpers (avoid importing strings just for these) ───────────────────

func splitLines(s string) []string {
	var lines []string
	cur := ""
	for _, c := range s {
		if c == '\n' {
			lines = append(lines, cur)
			cur = ""
		} else {
			cur += string(c)
		}
	}
	if cur != "" {
		lines = append(lines, cur)
	}
	return lines
}

func trimLine(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\t' || s[0] == '\r') {
		s = s[1:]
	}
	for len(s) > 0 && (s[len(s)-1] == ' ' || s[len(s)-1] == '\t' || s[len(s)-1] == '\r') {
		s = s[:len(s)-1]
	}
	return s
}

func hasPrefix(s, prefix string) bool {
	return len(s) >= len(prefix) && s[:len(prefix)] == prefix
}

// shell runs a bash command, streaming output to WS and capturing for parsing.
func (p *Pipeline) shell(
	ctx context.Context, cmd string, tool *tools.Tool,
	scanID string, buf *bytes.Buffer,
	target, platform string,
) error {
	timeout := time.Duration(tool.Timeout) * time.Second
	if timeout == 0 {
		timeout = config.DefaultToolTimeout
	}
	tctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	// ── Binary availability check ─────────────────────────────────────────────
	// Skip gracefully if tool binary not installed.
	// Native tools already returned at the top of executeTool() (Native dispatch);
	// they never reach this point. Empty BinaryPath signals "no binary required"
	// (e.g. freq runs as an inline shell pipeline).
	if tool.BinaryPath != "" {
		checkCmd := exec.CommandContext(tctx, "command", "-v", tool.BinaryPath)
		if err := checkCmd.Run(); err != nil {
			// Try which as fallback
			whichCmd := exec.CommandContext(tctx, "which", tool.BinaryPath)
			if err2 := whichCmd.Run(); err2 != nil {
				log.Info().
					Str("tool", tool.ID).
					Str("binary", tool.BinaryPath).
					Msg("[pipeline] tool not installed — skipping gracefully")
				p.broadcastEvent(scanID, "tool_skip", map[string]string{
					"tool_id": tool.ID,
					"reason":  tool.BinaryPath + " not found",
				})
				return nil // Non-fatal — continue pipeline
			}
		}
	}

	// Tools rulează nativ pe Ubuntu — Kali container eliminat.
	// Toate cele 78 tooluri se instalează via scripts/install-ubuntu.sh
	execCmd := exec.CommandContext(tctx, "/bin/bash", "-c", cmd)

	tw := &teeWriter{hub: p.hub, scanID: scanID, toolID: tool.ID, buf: buf}
	execCmd.Stdout = tw
	execCmd.Stderr = tw

	// Inject pipeline context into subprocess env.
	// M6-FIX: explicit env allowlist — os.Environ() was passing JWT_SECRET,
	// ANTHROPIC_API_KEY, STRIPE_SECRET_KEY etc. to all subprocesses (security leak).
	// Only pass what tools actually need.
	subprocEnv := []string{
		"PATH=" + os.Getenv("PATH"),
		"HOME=" + os.Getenv("HOME"),
		"USER=" + os.Getenv("USER"),
		"TMPDIR=" + os.TempDir(),
		"SCAN_ID=" + scanID,
		// H3-FIX: BBOUNTY_API removed — tools don't need internal API URL
		// Reduces attack surface if a tool binary is compromised (supply chain)
		"BBOUNTY_TARGET=" + target,
		"BBOUNTY_PLATFORM=" + platform,
		"RECONFTW_OUTPUT=" + os.Getenv("RECONFTW_OUTPUT"),
		// Tool-specific API keys — only the ones tools actually use
		"SHODAN_API_KEY=" + os.Getenv("SHODAN_API_KEY"),
		"PDCP_API_KEY=" + os.Getenv("PDCP_API_KEY"),
		"GITHUB_TOKEN=" + os.Getenv("GITHUB_TOKEN"),
		"BOUNTYPLZ_PLATFORM=" + os.Getenv("BOUNTYPLZ_PLATFORM"),
		"BOUNTYPLZ_LIVE=" + os.Getenv("BOUNTYPLZ_LIVE"),
		"INTERACTSH_URL=" + os.Getenv("INTERACTSH_URL"),
	}
	// Native Ubuntu mode — no container needed
	execCmd.Env = subprocEnv

	if err := execCmd.Start(); err != nil {
		return fmt.Errorf("start %s: %w", tool.Name, err)
	}
	return execCmd.Wait()
}

// saveFindings persists new findings and updates stats atomically.
func (p *Pipeline) saveFindings(ctx context.Context, scanID string, scan *activeScan, items []*findings.Finding) {
	for _, f := range items {
		if err := p.findings.Save(ctx, f); err != nil {
			log.Warn().Err(err).Str("title", f.Title).Msg("finding: save failed")
			continue
		}
		scan.vulns.Add(1)
		p.broadcastEvent(scanID, "new_finding", map[string]any{
			"id": f.ID, "title": f.Title,
			"severity": string(f.Severity), "url": f.URL,
		})
	}
}

// ── teeWriter: write to WS hub AND capture buffer ─────────────────────────────

type teeWriter struct {
	hub    *ws.Hub
	scanID string
	toolID string
	buf    *bytes.Buffer
	lines  int
}

func (t *teeWriter) Write(p []byte) (int, error) {
	t.buf.Write(p)
	// Throttle WS broadcast: every 3rd chunk to avoid flooding slow clients.
	t.lines++
	if t.lines%3 == 0 {
		d := make([]byte, len(p))
		copy(d, p)
		t.hub.BroadcastTerminal(t.scanID, t.toolID, d)
	}
	return len(p), nil
}

// ── Output management ─────────────────────────────────────────────────────────

// CleanOldOutputs removes scan directories older than ttl.
// secureOutputDir returns a private (0700) output directory for a scan. It tries
// the primary location first; if that mkdir fails, it falls back to a private
// per-scan subdirectory under the system temp dir — NOT bare /tmp. The old
// behaviour (outDir = "/tmp") dumped scan findings into a world-writable, shared
// directory where any local user could read them (SF-5). The fallback subdir is
// created 0700 so the hardening holds even on the error path.
func secureOutputDir(scanID string) string {
	primary := filepath.Join(outputBase, scanID[:8])
	if err := os.MkdirAll(primary, 0o700); err == nil {
		return primary
	} else {
		log.Warn().Err(err).Str("dir", primary).Msg("pipeline: mkdir failed — using private temp fallback")
	}
	// Private fallback: <tmp>/bbounty-scans/<scanID8>, mode 0700 (never bare /tmp).
	fallback := filepath.Join(os.TempDir(), "bbounty-scans", scanID[:8])
	if err := os.MkdirAll(fallback, 0o700); err != nil {
		// Last resort: a private subdir directly under tmp. If even this fails,
		// return it anyway — the caller's writes will surface the real error.
		log.Error().Err(err).Str("dir", fallback).Msg("pipeline: temp fallback mkdir failed")
		fallback = filepath.Join(os.TempDir(), "bbounty-"+scanID[:8])
		_ = os.MkdirAll(fallback, 0o700)
	}
	return fallback
}

func CleanOldOutputs(ttl time.Duration) {
	entries, err := os.ReadDir(outputBase)
	if err != nil {
		return
	}
	cutoff := time.Now().Add(-ttl)
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		info, err := e.Info()
		if err != nil || !info.ModTime().Before(cutoff) {
			continue
		}
		path := filepath.Join(outputBase, e.Name())
		if err := os.RemoveAll(path); err != nil {
			log.Warn().Err(err).Str("path", path).Msg("cleanup failed")
		}
	}
}

// ── Broadcast helpers ─────────────────────────────────────────────────────────

func (p *Pipeline) broadcastStats(scanID string, scan *activeScan, start time.Time) {
	s := scan.stats(scanID)
	s.StartedAt = start
	s.Elapsed = time.Since(start).Seconds()
	data, _ := json.Marshal(s)
	p.hub.BroadcastStats(scanID, data)
}

func (p *Pipeline) broadcastEvent(scanID, event string, payload any) {
	data, _ := json.Marshal(map[string]any{
		"event": event, "payload": payload,
		"ts": time.Now().UnixMilli(),
	})
	p.hub.BroadcastPipeline(scanID, data)
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func (p *Pipeline) HandleStop(w http.ResponseWriter, r *http.Request) {
	scanID := r.URL.Query().Get("scan_id")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	scan.cancelFn()
	w.Write([]byte(`{"status":"stopping"}`))
}

func (p *Pipeline) HandlePause(w http.ResponseWriter, _ *http.Request) {
	w.Write([]byte(`{"status":"paused"}`))
}

func (p *Pipeline) HandleStatus(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(scan.stats(scanID))
}

func (p *Pipeline) HandleStats(w http.ResponseWriter, r *http.Request) {
	p.HandleStatus(w, r)
}

func (p *Pipeline) DrainAll(ctx context.Context) {
	p.scansMu.RLock()
	defer p.scansMu.RUnlock()
	for _, scan := range p.scans {
		scan.cancelFn()
	}
	select {
	case <-ctx.Done():
	case <-time.After(10 * time.Second):
	}
}

// ── Utilities ─────────────────────────────────────────────────────────────────

// filterTools returns tools for the given phase, honouring the registry's
// Enabled flag and any explicit ToolIDs request from the scan.
//
// Behaviour:
//   - When no ToolIDs are requested: return all phase tools that are Enabled.
//     Disabled tools (vigolium AGPL-gated, deprecated tools) are silently
//     excluded so they don't run by default.
//   - When ToolIDs ARE requested: return the intersection. An explicit
//     ToolID in the request COUNTS AS AN OPT-IN OVERRIDE and bypasses
//     the Enabled check — operators who pass `tool_ids=["wfuzz"]` are
//     telling us they want it despite the deprecation.
func (p *Pipeline) filterTools(requested []string, phase string) []*tools.Tool {
	all := p.registry.ByPhase(phase)
	if len(requested) == 0 {
		// No explicit list — apply default Enabled filter.
		var out []*tools.Tool
		for _, t := range all {
			if t.Enabled {
				out = append(out, t)
			}
		}
		return out
	}
	want := make(map[string]bool, len(requested))
	for _, id := range requested {
		want[id] = true
	}
	var out []*tools.Tool
	for _, t := range all {
		// Explicit request overrides Enabled — operator opt-in.
		if want[t.ID] {
			out = append(out, t)
		}
	}
	return out
}

func errStatus(err error) string {
	if err == nil {
		return "success"
	}
	return "error"
}

// ── Streaming io.ReadCloser helpers ───────────────────────────────────────────

// Ensure teeWriter implements io.Writer.
var _ io.Writer = (*teeWriter)(nil)

// ── Real scope enforcement on tool output files ───────────────────────────────
//
// filterOutputsInScope reads the canonical per-phase output files
// (subs.txt, live.txt, urls.txt) after each phase and removes any line whose
// host does not pass the ROE gate. This is the authoritative in-loop scope
// check; the ScopeFilter grep in executor.go is a best-effort pre-filter only.
func (p *Pipeline) filterOutputsInScope(scanID string, scan *activeScan) {
	if len(scan.req.Scope) == 0 {
		return // no scope configured — nothing to filter
	}
	scanID8 := scanID
	if len(scanID8) > 8 {
		scanID8 = scanID8[:8]
	}
	outDir := filepath.Join("/tmp/bb-scans", scanID8)

	fileNames := []string{
		scanID8 + "_subs.txt",
		scanID8 + "_live.txt",
		scanID8 + "_urls.txt",
	}
	for _, name := range fileNames {
		path := filepath.Join(outDir, name)
		if err := filterFileInScope(path, p.gate, scan.req.Scope, scan.req.Excluded); err != nil {
			log.Debug().Err(err).Str("file", name).Msg("pipeline: scope filter skipped")
		}
	}
}

// filterFileInScope reads a line-delimited file, removes lines whose host is
// out-of-scope, and writes the result back atomically.
func filterFileInScope(path string, g *roe.Gate, scope, excluded []string) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err // file may not exist yet — not an error
	}
	lines := bytes.Split(raw, []byte("\n"))
	kept := lines[:0]
	for _, line := range lines {
		s := string(bytes.TrimSpace(line))
		if s == "" {
			continue
		}
		if g.CheckURL(s, scope, excluded) {
			kept = append(kept, line)
		}
	}
	out := bytes.Join(kept, []byte("\n"))
	if len(out) > 0 {
		out = append(out, '\n')
	}
	return os.WriteFile(path, out, 0o644)
}

// ── Scan Resume ───────────────────────────────────────────────────────────────

// HandleListResumable lists scans that were interrupted and can be resumed.
func (p *Pipeline) HandleListResumable(w http.ResponseWriter, r *http.Request) {
	if p.checkpoints == nil {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`[]`))
		return
	}
	ids, err := p.checkpoints.ListResumable(r.Context(), 5*time.Minute)
	if err != nil {
		http.Error(w, `{"error":"failed to list resumable scans"}`, http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(ids)
}

// HandleResume restarts a previously interrupted scan from its checkpoint.
func (p *Pipeline) HandleResume(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	if p.checkpoints == nil {
		http.Error(w, `{"error":"checkpoints not configured"}`, http.StatusServiceUnavailable)
		return
	}
	cp, err := p.checkpoints.Load(r.Context(), scanID)
	if err != nil {
		http.Error(w, `{"error":"checkpoint not found"}`, http.StatusNotFound)
		return
	}

	scan := &activeScan{
		req:    cp.Request,
		phase:  Phase(cp.Phase),
		status: StatusRunning,
	}

	p.scansMu.Lock()
	if _, exists := p.scans[scanID]; exists {
		p.scansMu.Unlock()
		http.Error(w, `{"error":"scan already running"}`, http.StatusConflict)
		return
	}
	ctx, cancel := context.WithCancel(r.Context())
	scan.cancelFn = cancel
	p.scans[scanID] = scan
	p.scansMu.Unlock()

	go func() {
		defer func() {
			p.scansMu.Lock()
			delete(p.scans, scanID)
			p.scansMu.Unlock()
			_ = p.checkpoints.Delete(context.Background(), scanID)
		}()
		p.run(ctx, scanID, scan)
	}()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"scan_id": scanID,
		"status":  "resumed",
		"phase":   string(cp.Phase),
	})
}

// mergeUnique appends items from b to a, skipping duplicates.
func mergeUnique(a, b []string) []string {
	seen := make(map[string]bool, len(a))
	for _, v := range a {
		seen[v] = true
	}
	for _, v := range b {
		if !seen[v] {
			a = append(a, v)
			seen[v] = true
		}
	}
	return a
}

// ── Adaptive ratelimiter: observe HTTP status codes from tool output ───────────

// observeHTTPStatuses parses httpx/nuclei JSONL output and calls RecordResponse
// on the rate limiter for every line that has a "status_code" field.
// This is the missing link that makes the adaptive ratelimit engine actually work:
// instead of just counting requests, it now adjusts rate on observed 429/503 responses.
func (p *Pipeline) observeHTTPStatuses(target, platform string, buf *bytes.Buffer) {
	if p.rateLimiter == nil {
		return
	}
	limiter := p.rateLimiter.ForTarget(target, ratelimitPlatform(platform))

	data := buf.Bytes()
	for len(data) > 0 {
		// Find next line
		end := 0
		for end < len(data) && data[end] != '\n' {
			end++
		}
		line := data[:end]
		if end < len(data) {
			data = data[end+1:]
		} else {
			data = nil
		}
		if len(line) == 0 {
			continue
		}

		// Fast path: look for "status_code" without full JSON parse
		// httpx outputs: {"url":"...","status_code":429,...}
		const marker = `"status_code":`
		idx := bytes.Index(line, []byte(marker))
		if idx < 0 {
			continue
		}
		rest := line[idx+len(marker):]
		// Parse the integer
		code := 0
		for i, b := range rest {
			if b >= '0' && b <= '9' {
				code = code*10 + int(b-'0')
			} else if i > 0 {
				break
			}
		}
		if code > 0 {
			limiter.RecordResponse(code, 0)
		}
	}
}

// ratelimitPlatform converts a platform string to the ratelimit.Platform type.
func ratelimitPlatform(p string) ratelimit.Platform {
	switch p {
	case "hackerone":
		return ratelimit.PlatformHackerOne
	case "bugcrowd":
		return ratelimit.PlatformBugcrowd
	case "intigriti":
		return ratelimit.PlatformIntigriti
	case "private":
		return ratelimit.PlatformPrivate
	default:
		return ratelimit.PlatformBugcrowd // conservative default
	}
}

// ── reconFTW integration ──────────────────────────────────────────────────────

// reconFTWOutputDir returns the reconFTW output directory for a given target.
// reconFTW writes to ~/reconftw/Recon/<domain>/ by default.
// Can be overridden with RECONFTW_OUTPUT env var.
func (p *Pipeline) reconFTWOutputDir(target string) string {
	if dir := os.Getenv("RECONFTW_OUTPUT"); dir != "" {
		return filepath.Join(dir, target)
	}
	home, err := os.UserHomeDir()
	if err != nil {
		home = "/root"
	}
	return filepath.Join(home, "reconftw", "Recon", target)
}

// ── Scan rate limiter ─────────────────────────────────────────────────────────

const maxConcurrentScansPerUser = 3

// checkScanRateLimit enforces max concurrent scans per user bazat pe plan.
//
// FIX: userKey = JWT userID (nu IP sau header).
// Limita vine din planul de abonament stocat în Redis:
//
//	Solo:         1 scan concurent
//	Professional: 3 scanuri concurente
//	Team:         5 scanuri concurente (per seat)
//
// Cheia Redis: scan:concurrent:{userID} → nr scanuri active
// La final scan: decrementScanRateLimit() decrementează contorul.
// TTL 6h — safety net dacă decrement e ratat (crash, timeout).
func (p *Pipeline) checkScanRateLimit(ctx context.Context, userID string) error {
	// Citește limita din planul userului
	maxConc := p.getMaxConcurrentForUser(ctx, userID)

	key := "scan:concurrent:" + userID
	count, err := p.cache.Raw().Incr(ctx, key).Result()
	if err != nil {
		// Fail open pe eroare Redis — preferăm disponibilitate
		log.Warn().Err(err).Str("user", userID).Msg("[pipeline] scan rate limit Redis error — fail open")
		return nil
	}

	// Prima incrementare — setează TTL 6h (safety net)
	if count == 1 {
		p.cache.Raw().Expire(ctx, key, 6*time.Hour)
	}

	if int(count) > maxConc {
		// Decrement — nu am pornit scanul
		p.cache.Raw().Decr(ctx, key)
		return fmt.Errorf(
			"ai %d scan(uri) active — planul tău permite maxim %d concurent(e). "+
				"Așteaptă finalizarea unui scan sau upgradează planul",
			count-1, maxConc,
		)
	}

	// Stochează și numărul total de scanuri pornite luna asta
	// (folosit de billing pentru limita lunară)
	monthKey := fmt.Sprintf("scan:monthly:%s:%s", userID, time.Now().Format("2006-01"))
	p.cache.Raw().Incr(ctx, monthKey)
	p.cache.Raw().Expire(ctx, monthKey, 35*24*time.Hour) // TTL 35 zile

	return nil
}

// getMaxConcurrentForUser returnează numărul maxim de scanuri concurente
// bazat pe planul de abonament al userului din Redis.
func (p *Pipeline) getMaxConcurrentForUser(ctx context.Context, userID string) int {
	planKey := "billing:plan:" + userID
	plan, err := p.cache.Raw().Get(ctx, planKey).Result()
	if err != nil {
		// Fără plan = Solo (cel mai restrictiv)
		return 1
	}
	switch plan {
	case "professional":
		return 3
	case "team":
		return 5
	case "solo":
		return 1
	default:
		return 1
	}
}

// decrementScanRateLimit decrementează contorul când scanul se termină.
func (p *Pipeline) decrementScanRateLimit(ctx context.Context, userID string) {
	key := "scan:concurrent:" + userID
	val, _ := p.cache.Raw().Decr(ctx, key).Result()
	// Nu lăsa să scadă sub 0 (safety)
	if val < 0 {
		p.cache.Raw().Set(ctx, key, 0, 6*time.Hour)
	}
}
