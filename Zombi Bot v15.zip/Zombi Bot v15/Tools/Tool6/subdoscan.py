#python2.7
#Author : Viper 1337

# <-- Import Module -->
import os
import json
import requests
from colorama import Fore, init
from multiprocessing import Pool 
from multiprocessing.dummy import Pool as ThreadPool
init(autoreset=True)

def subdoscan(target):
  try:
    grab = requests.get('https://sonar.omnisint.io/subdomains/'+target)
    if 'null' in grab.text:
      print(('{}[FAILED] {}'.format(Fore.RED, Fore.YELLOW+target)))
    else:
      result = json.loads(grab.text)
      print("{}[GRABBED] {} | Total {} Subdomains".format(Fore.YELLOW, str(target), len(result)))
      for domain in result: 
        open('grabbed.txt', 'a').write('http://' + domain + "\n")
      
  except:
      pass

banner = """

  ______                      _       _     ____            _      __      __  __   _____ 
 |___  /                     | |     (_)   |  _ \          | |     \ \    / / /_ | | ____|
    / /    ___    _ __ ___   | |__    _    | |_) |   ___   | |_     \ \  / /   | | | |__  
   / /    / _ \  | '_ ` _ \  | '_ \  | |   |  _ <   / _ \  | __|     \ \/ /    | | |___ \ 
  / /__  | (_) | | | | | | | | |_) | | |   | |_) | | (_) | | |_       \  /     | |  ___) |
 /_____|  \___/  |_| |_| |_| |_.__/  |_|   |____/   \___/   \__|       \/      |_| |____/ 
                                                                                          
                                                                                          
 [+] ICQ: @viper1337official
 
 [+] Telegram: https://t.me/viper133777

""".format(Fore.WHITE, Fore.YELLOW)
print(banner)
target = open(input(Fore.WHITE+'input list:~# '),'r').read().replace('http://', '').replace('https://', '').splitlines()
Thread = input(Fore.WHITE+'Thread :~# ')
pool = ThreadPool(int(Thread))
pool.map(subdoscan, target)
pool.close()
pool.join()
