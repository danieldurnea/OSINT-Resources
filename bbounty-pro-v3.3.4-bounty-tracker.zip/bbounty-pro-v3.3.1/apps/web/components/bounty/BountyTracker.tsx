"use client";

import { useState } from "react";
import type { ReactNode } from "react";
import useSWR from "swr";
import { DollarSign, TrendingUp, Plus, Trash2, Clock } from "lucide-react";
import { bountyAPI } from "@/lib/api-client";

interface Report {
  id: string;
  title: string;
  program: string;
  platform?: string;
  severity?: string;
  status: string;
  amount: number;
  currency?: string;
  submitted_at: string;
}
interface Stats {
  total: number;
  by_status: Record<string, number>;
  total_earned: number;
  pending: number;
  currency: string;
  accept_rate: number;
}

const STATUS_COLOR: Record<string, string> = {
  submitted: "#4a8a9a",
  triaged: "#ffcc3a",
  accepted: "#7c6aff",
  paid: "#7fffd6",
  duplicate: "#8aa0aa",
  "n/a": "#ff5c7a",
};
const STATUSES = ["submitted", "triaged", "accepted", "paid", "duplicate", "n/a"];

export default function BountyTracker() {
  const { data: stats, mutate: mutateStats } = useSWR<Stats>(
    "bounty-stats",
    () => bountyAPI.stats() as Promise<Stats>
  );
  const { data: listData, mutate } = useSWR<{ reports: Report[] }>(
    "bounty-list",
    () => bountyAPI.list() as Promise<{ reports: Report[] }>
  );

  const [show, setShow] = useState(false);
  const [form, setForm] = useState({
    title: "",
    program: "",
    platform: "hackerone",
    severity: "medium",
    status: "submitted",
    amount: "",
    currency: "USD",
  });

  async function refresh() {
    mutate();
    mutateStats();
  }

  async function add() {
    if (!form.title || !form.program) return;
    await bountyAPI.save({
      ...form,
      amount: parseFloat(form.amount) || 0,
    });
    setForm({ ...form, title: "", program: "", amount: "" });
    setShow(false);
    refresh();
  }

  async function updateStatus(r: Report, status: string) {
    await bountyAPI.save({ ...r, status });
    refresh();
  }

  async function del(id: string) {
    await bountyAPI.delete(id);
    refresh();
  }

  const reports = listData?.reports || [];
  const cur = stats?.currency || "USD";

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <DollarSign className="text-[#7fffd6]" size={20} />
          <h1 className="text-lg tracking-wide">Bounty Tracker</h1>
        </div>
        <button
          onClick={() => setShow((v) => !v)}
          className="px-3 py-1.5 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                     text-[#7fffd6] hover:bg-[#13534781] transition-colors flex items-center gap-1"
        >
          <Plus size={13} /> Add report
        </button>
      </header>

      {/* ── Earnings cards ──────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card
          icon={<DollarSign size={16} className="text-[#7fffd6]" />}
          label={`Earned (${cur})`}
          value={(stats?.total_earned ?? 0).toLocaleString()}
        />
        <Card
          icon={<Clock size={16} className="text-[#7c6aff]" />}
          label={`Pending (${cur})`}
          value={(stats?.pending ?? 0).toLocaleString()}
        />
        <Card icon={<TrendingUp size={16} />} label="Reports" value={stats?.total ?? 0} />
        <Card
          icon={<TrendingUp size={16} className="text-[#7fffd6]" />}
          label="Accept rate"
          value={`${Math.round((stats?.accept_rate ?? 0) * 100)}%`}
        />
      </div>

      {/* ── Add form ────────────────────────────────────────────────────── */}
      {show && (
        <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 space-y-2">
          <div className="grid md:grid-cols-2 gap-2">
            <input
              placeholder="Report title"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className={inputCls}
            />
            <input
              placeholder="Program (e.g. Acme)"
              value={form.program}
              onChange={(e) => setForm({ ...form, program: e.target.value })}
              className={inputCls}
            />
            <select
              value={form.platform}
              onChange={(e) => setForm({ ...form, platform: e.target.value })}
              className={inputCls}
            >
              <option value="hackerone">HackerOne</option>
              <option value="bugcrowd">Bugcrowd</option>
              <option value="other">Other</option>
            </select>
            <select
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
              className={inputCls}
            >
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <input
              placeholder="Amount"
              type="number"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              className={inputCls}
            />
            <input
              placeholder="Currency"
              value={form.currency}
              onChange={(e) => setForm({ ...form, currency: e.target.value })}
              className={inputCls}
            />
          </div>
          <button
            onClick={add}
            disabled={!form.title || !form.program}
            className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                       text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors"
          >
            Save report
          </button>
        </section>
      )}

      {/* ── Reports list ────────────────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
        <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">Reports</h2>
        {reports.length === 0 ? (
          <p className="text-[#5a6b72] text-xs">
            No reports tracked yet — add the ones you&apos;ve submitted to see your pipeline & earnings.
          </p>
        ) : (
          <ul className="space-y-2">
            {reports.map((r) => (
              <li key={r.id} className="border-t border-[#141f23] pt-2 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[#c8d8e0] truncate max-w-[45%]">{r.title}</span>
                  <span className="text-[#5a6b72]">{r.program}</span>
                  <select
                    value={r.status}
                    onChange={(e) => updateStatus(r, e.target.value)}
                    className="bg-[#080c0e] border border-[#1c2a2e] rounded px-2 py-0.5 text-[11px] outline-none"
                    style={{ color: STATUS_COLOR[r.status] || "#c8d8e0" }}
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s} style={{ color: "#c8d8e0" }}>
                        {s}
                      </option>
                    ))}
                  </select>
                  <span className="text-[#7fffd6] w-20 text-right">
                    {r.amount > 0 ? `${r.amount} ${r.currency || ""}` : "—"}
                  </span>
                  <button
                    onClick={() => del(r.id)}
                    className="text-[#5a6b72] hover:text-[#ff5c7a] transition-colors"
                    aria-label="delete"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

const inputCls =
  "bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs text-[#c8d8e0] " +
  "placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none";

function Card({ icon, label, value }: { icon: ReactNode; label: string; value: string | number }) {
  return (
    <div className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
      <div className="flex items-center gap-2 text-[#5a6b72] text-[11px] uppercase tracking-wider">
        {icon}
        {label}
      </div>
      <div className="text-xl mt-1 text-[#c8d8e0]">{value}</div>
    </div>
  );
}
