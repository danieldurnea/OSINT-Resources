# Zombi Bot v15
# If u have problem in BOT
# Contact me ?
# ICQ: @viper1337official
# Telegram: https://t.me/viper133777

Install Python 2.7 To Run All Tools

Module :

-pip3 install -r requirements.txt

[Zombi Bot V15  - Only work for python 2.7]

Module :

-pip install requests
-pip install colorama
-pip install bs4
-pip install tldextract
-pip install termcolor
-pip install http_request_randomizer
-pip install requests.proxy
-pip install requestProxy
-pip install enum

Thanks you~

