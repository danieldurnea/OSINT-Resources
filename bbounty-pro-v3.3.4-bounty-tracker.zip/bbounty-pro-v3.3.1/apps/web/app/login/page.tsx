"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";

type Step = "credentials" | "totp" | "setup-2fa";

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>("credentials");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [totpCode, setTotpCode] = useState("");
  const [pendingToken, setPendingToken] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [qrCode, setQrCode] = useState("");
  const [secret, setSecret] = useState("");
  const [setupCode, setSetupCode] = useState("");
  const codeRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (step === "totp" || step === "setup-2fa") {
      setTimeout(() => codeRef.current?.focus(), 100);
    }
  }, [step]);

  // Step 1 — username + password
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const res = await fetch("/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Login failed");

      if (data.requires_2fa) {
        // Server wants TOTP — go to step 2
        setPendingToken(data.pending_token);
        setStep("totp");
      } else {
        // No 2FA — store tokens and redirect
        // Token stored in httpOnly cookie by server (bb_access).
        // sessionStorage.setItem REMOVED — was readable by XSS (C2/H1).
        router.push("/");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Step 2 — TOTP code (when 2FA already enabled)
  const handleTOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totpCode.length !== 6) { setError("Enter 6-digit code"); return; }
    setError(""); setLoading(true);
    try {
      const res = await fetch("/auth/2fa/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pending_token: pendingToken, code: totpCode }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Invalid code");
      // OPUS-FIX H3: do NOT store token in sessionStorage (XSS-readable).
      // Server sets httpOnly bb_access cookie on success — JS never touches it.
      router.push("/");
    } catch (err: any) {
      setError(err.message);
      setTotpCode("");
      codeRef.current?.focus();
    } finally {
      setLoading(false);
    }
  };

  // 2FA setup — request QR code
  const handleSetup2FA = async () => {
    setError(""); setLoading(true);
    try {
      // OPUS-FIX H3: use httpOnly cookie via credentials:include — no sessionStorage token
      const res = await fetch("/auth/2fa/setup", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Setup failed");
      setQrCode(data.qr_code);
      setSecret(data.secret);
      setStep("setup-2fa");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // 2FA setup — verify and enable
  const handleEnable2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (setupCode.length !== 6) { setError("Enter 6-digit code"); return; }
    setError(""); setLoading(true);
    try {
      // OPUS-FIX H3: use httpOnly cookie via credentials:include
      const res = await fetch("/auth/2fa/verify", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: setupCode }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Invalid code");
      router.push("/");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={S.root}>
      {/* Animated grid background */}
      <div style={S.grid} />

      <div style={S.box}>
        {/* Logo */}
        <div style={S.logoRow}>
          <div style={S.logoChip}>BB</div>
          <div>
            <div style={S.logoTitle}>BBOUNTY PRO</div>
            <div style={S.logoSub}>v3.3-zen · Authorized testing only</div>
          </div>
        </div>

        {/* Step indicators */}
        <div style={S.steps}>
          {[["01","Credentials"],["02","2FA Code"],["03","Dashboard"]].map(([n,l],i)=>{
            const active = (i===0&&step==="credentials")||(i===1&&(step==="totp"||step==="setup-2fa"))||(i===2&&false);
            const done = (i===0&&step!=="credentials");
            return (
              <div key={n} style={{...S.step, opacity: active?1:done?0.6:0.3}}>
                <div style={{...S.stepNum, color: active?"#00e5cc":done?"#54b35f":"#4a6a7a", borderColor: active?"#00e5cc44":done?"#54b35f44":"#1a2a32"}}>
                  {done?"✓":n}
                </div>
                <span style={{color:active?"#c8d8e0":"#4a6a7a",fontSize:10,letterSpacing:1}}>{l}</span>
              </div>
            );
          })}
        </div>

        {/* ── Step 1: Credentials ── */}
        {step === "credentials" && (
          <form onSubmit={handleLogin} autoComplete="off">
            <Field label="USERNAME" value={username} onChange={setUsername} placeholder="hunter1" autoFocus />
            <Field label="PASSWORD" value={password} onChange={setPassword} type="password" placeholder="••••••••••••" />
            {error && <Err msg={error} />}
            <button type="submit" style={S.btn} disabled={loading}>
              {loading ? "AUTHENTICATING..." : "AUTHENTICATE →"}
            </button>
          </form>
        )}

        {/* ── Step 2a: TOTP input (2FA already enabled) ── */}
        {step === "totp" && (
          <form onSubmit={handleTOTP}>
            <div style={S.totpLabel}>Open your authenticator app and enter the 6-digit code</div>
            <CodeInput
              ref={codeRef}
              value={totpCode}
              onChange={setTotpCode}
            />
            {error && <Err msg={error} />}
            <button type="submit" style={S.btn} disabled={loading || totpCode.length !== 6}>
              {loading ? "VERIFYING..." : "VERIFY CODE →"}
            </button>
            <button type="button" onClick={() => { setStep("credentials"); setTotpCode(""); setError(""); }}
              style={S.backBtn}>← Back
            </button>
          </form>
        )}

        {/* ── Step 2b: 2FA setup (new user, no 2FA yet) ── */}
        {step === "setup-2fa" && (
          <form onSubmit={handleEnable2FA}>
            <div style={S.totpLabel}>Scan with Google Authenticator, Authy, or any TOTP app</div>
            {qrCode && (
              <div style={S.qrWrap}>
                <img src={`data:image/png;base64,${qrCode}`} alt="QR Code" style={S.qr} />
              </div>
            )}
            {secret && (
              <div style={S.secretRow}>
                <span style={{color:"#4a6a7a",fontSize:10}}>Manual key:</span>
                <code style={{color:"#00e5cc",fontSize:11,letterSpacing:2}}>{secret}</code>
              </div>
            )}
            <div style={{marginTop:16}}>
              <CodeInput ref={codeRef} value={setupCode} onChange={setSetupCode} />
            </div>
            {error && <Err msg={error} />}
            <button type="submit" style={S.btn} disabled={loading || setupCode.length !== 6}>
              {loading ? "ENABLING..." : "ENABLE 2FA →"}
            </button>
            <button type="button" onClick={() => router.push("/")} style={S.backBtn}>
              Skip for now →
            </button>
          </form>
        )}

        {/* After first login — offer 2FA setup */}
        {step === "credentials" && (
          <div style={{marginTop:16,paddingTop:16,borderTop:"1px solid #1a2a32"}}>
            <div style={{color:"#2a4a5a",fontSize:10,textAlign:"center",marginBottom:8}}>
              Don't have an account? Register via invite code
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes gridMove { 0%{transform:translateY(0)} 100%{transform:translateY(40px)} }
        * { box-sizing: border-box; }
      `}</style>
    </div>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function Field({ label, value, onChange, type = "text", placeholder, autoFocus }: {
  label: string; value: string; onChange: (v: string) => void;
  type?: string; placeholder?: string; autoFocus?: boolean;
}) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ color: "#2a4a5a", fontSize: 10, letterSpacing: 2, marginBottom: 5 }}>{label}</div>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        autoFocus={autoFocus}
        required
        style={{
          width: "100%",
          background: "#050810",
          border: "1px solid #1a2a32",
          borderRadius: 4,
          padding: "10px 14px",
          color: "#c8d8e0",
          fontFamily: "monospace",
          fontSize: 13,
          outline: "none",
        }}
      />
    </div>
  );
}

import { forwardRef } from "react";
const CodeInput = forwardRef<HTMLInputElement, { value: string; onChange: (v: string) => void }>(
  ({ value, onChange }, ref) => (
    <div style={{ textAlign: "center", margin: "16px 0" }}>
      <input
        ref={ref}
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
        maxLength={6}
        value={value}
        onChange={e => onChange(e.target.value.replace(/\D/g, "").slice(0, 6))}
        placeholder="000000"
        style={{
          background: "#050810",
          border: "2px solid #00e5cc44",
          borderRadius: 6,
          padding: "16px 24px",
          color: "#00e5cc",
          fontFamily: "monospace",
          fontSize: 28,
          letterSpacing: 12,
          textAlign: "center",
          width: 200,
          outline: "none",
        }}
      />
    </div>
  )
);
CodeInput.displayName = "CodeInput";

function Err({ msg }: { msg: string }) {
  return (
    <div style={{
      background: "#ff3a5c18",
      border: "1px solid #ff3a5c44",
      borderRadius: 4,
      padding: "8px 12px",
      color: "#ff3a5c",
      fontSize: 11,
      marginBottom: 12,
    }}>{msg}</div>
  );
}

const S = {
  root: {
    minHeight: "100vh",
    background: "#080c0e",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "'JetBrains Mono','Fira Code',monospace",
    position: "relative" as const,
    overflow: "hidden",
  },
  grid: {
    position: "absolute" as const,
    inset: 0,
    backgroundImage: "linear-gradient(#0d1e2622 1px,transparent 1px),linear-gradient(90deg,#0d1e2622 1px,transparent 1px)",
    backgroundSize: "40px 40px",
    animation: "gridMove 4s linear infinite",
  },
  box: {
    position: "relative" as const,
    background: "#0a1018",
    border: "1px solid #1a2a32",
    borderRadius: 8,
    padding: 32,
    width: 380,
    boxShadow: "0 0 60px #00e5cc08",
  },
  logoRow: { display: "flex", alignItems: "center", gap: 12, marginBottom: 28 },
  logoChip: {
    background: "#00e5cc",
    color: "#080c0e",
    fontWeight: 900,
    fontSize: 14,
    padding: "6px 10px",
    borderRadius: 4,
    letterSpacing: 1,
  },
  logoTitle: { color: "#c8d8e0", fontWeight: 700, fontSize: 13, letterSpacing: 3 },
  logoSub:   { color: "#2a4a5a", fontSize: 10, marginTop: 2 },
  steps: { display: "flex", gap: 16, marginBottom: 28 },
  step: { display: "flex", alignItems: "center", gap: 8, flex: 1 },
  stepNum: {
    width: 28, height: 28,
    borderRadius: "50%",
    border: "1px solid",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 10, fontWeight: 700, flexShrink: 0,
  },
  btn: {
    width: "100%",
    padding: "12px 0",
    background: "#00e5cc18",
    border: "1px solid #00e5cc44",
    borderRadius: 4,
    color: "#00e5cc",
    fontFamily: "monospace",
    fontSize: 12,
    fontWeight: 700,
    letterSpacing: 2,
    cursor: "pointer",
    marginTop: 4,
  },
  backBtn: {
    background: "none", border: "none", color: "#2a4a5a",
    fontSize: 11, cursor: "pointer", marginTop: 10,
    fontFamily: "monospace", padding: 4,
  },
  totpLabel: {
    color: "#6a8a9a", fontSize: 12, textAlign: "center" as const,
    marginBottom: 8, lineHeight: 1.6,
  },
  qrWrap: { display: "flex", justifyContent: "center", margin: "12px 0" },
  qr: { width: 160, height: 160, imageRendering: "pixelated" as const, border: "4px solid #fff" },
  secretRow: {
    display: "flex", gap: 8, alignItems: "center", justifyContent: "center",
    background: "#050810", borderRadius: 4, padding: "6px 12px", marginBottom: 4,
  },
};
