// Item #11: Per-URL scope re-check during scan execution.
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// - This provides the validator function
// - Pipeline integration NOT done — pipeline.go must call CheckURL()
//   before each tool invocation. Currently only checks at scan start.

package roe

// CheckURL is a fast in-loop scope check called for every URL discovered
// during recon. Compared to Validate(), this is optimised for repeated calls.
func (g *Gate) CheckURL(url string, scope, excluded []string) bool {
	host := extractHost(url)
	if host == "" {
		return false
	}
	for _, exc := range excluded {
		if matchesScope(host, exc) {
			return false
		}
	}
	for _, s := range scope {
		if matchesScope(host, s) {
			return true
		}
	}
	return false
}

// FilterURLs removes out-of-scope URLs from a list. Used after recon
// to reduce attack surface to authorised targets only.
func (g *Gate) FilterURLs(urls []string, scope, excluded []string) []string {
	out := make([]string, 0, len(urls))
	for _, u := range urls {
		if g.CheckURL(u, scope, excluded) {
			out = append(out, u)
		}
	}
	return out
}
