// Package hunter provides the Hunter Dashboard data layer: a per-user index of
// scans plus aggregated personal statistics (scan history, findings by severity,
// and ROI per program). It is additive — it records lightweight scan metadata in
// Redis when a scan starts and reads it back for the dashboard, without changing
// the scan pipeline itself.
package hunter

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"time"

	"github.com/redis/go-redis/v9"
)

// ScanRecord is the lightweight per-scan metadata shown in history/stats.
type ScanRecord struct {
	ScanID    string         `json:"scan_id"`
	Target    string         `json:"target"`
	Program   string         `json:"program,omitempty"` // bug-bounty program name (optional)
	Profile   string         `json:"profile,omitempty"`
	StartedAt time.Time      `json:"started_at"`
	Status    string         `json:"status"`
	Findings  map[string]int `json:"findings"` // severity → count (critical/high/medium/low/info)
}

// Store records and reads hunter scan history from Redis.
type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 90 * 24 * time.Hour} // keep history 90 days
}

func indexKey(userID string) string  { return "hunter:scans:" + userID }
func recordKey(scanID string) string { return "hunter:scan:" + scanID }

// RecordScanStartFields is a primitive-args adapter for RecordScanStart, used by
// the pipeline (which can't import this package's ScanRecord type without a
// cycle). Builds the record with StartedAt=now and Status="running".
func (s *Store) RecordScanStartFields(ctx context.Context, userID, scanID, target, profile string) error {
	return s.RecordScanStart(ctx, userID, ScanRecord{
		ScanID:    scanID,
		Target:    target,
		Profile:   profile,
		StartedAt: time.Now().UTC(),
		Status:    "running",
		Findings:  map[string]int{},
	})
}

// RecordScanStart adds a scan to the user's history index (called when a scan
// starts). Best-effort: errors are returned but callers typically log-and-continue.
func (s *Store) RecordScanStart(ctx context.Context, userID string, rec ScanRecord) error {
	if userID == "" || rec.ScanID == "" {
		return fmt.Errorf("userID and scanID required")
	}
	if rec.Findings == nil {
		rec.Findings = map[string]int{}
	}
	data, err := json.Marshal(rec)
	if err != nil {
		return err
	}
	pipe := s.rdb.TxPipeline()
	// sorted set scored by start time → cheap reverse-chronological history
	pipe.ZAdd(ctx, indexKey(userID), redis.Z{
		Score:  float64(rec.StartedAt.Unix()),
		Member: rec.ScanID,
	})
	pipe.Expire(ctx, indexKey(userID), s.ttl)
	pipe.Set(ctx, recordKey(rec.ScanID), data, s.ttl)
	_, err = pipe.Exec(ctx)
	return err
}

// UpdateScanResultFields is the interface-friendly alias for UpdateScanResult,
// matching the pipeline's hunterRecorder interface.
func (s *Store) UpdateScanResultFields(ctx context.Context, scanID, status string, findings map[string]int) error {
	return s.UpdateScanResult(ctx, scanID, status, findings)
}

// UpdateScanResult updates a scan record's status + finding counts (called when a
// scan finishes). No-op if the record is missing (e.g. expired).
func (s *Store) UpdateScanResult(ctx context.Context, scanID, status string, findings map[string]int) error {
	raw, err := s.rdb.Get(ctx, recordKey(scanID)).Result()
	if err != nil {
		return err // missing/expired — nothing to update
	}
	var rec ScanRecord
	if err := json.Unmarshal([]byte(raw), &rec); err != nil {
		return err
	}
	rec.Status = status
	if findings != nil {
		rec.Findings = findings
	}
	data, _ := json.Marshal(rec)
	return s.rdb.Set(ctx, recordKey(scanID), data, s.ttl).Err()
}

// History returns the user's scans, newest first, up to limit.
func (s *Store) History(ctx context.Context, userID string, limit int) ([]ScanRecord, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	ids, err := s.rdb.ZRevRange(ctx, indexKey(userID), 0, int64(limit-1)).Result()
	if err != nil {
		return nil, err
	}
	out := make([]ScanRecord, 0, len(ids))
	for _, id := range ids {
		raw, err := s.rdb.Get(ctx, recordKey(id)).Result()
		if err != nil {
			continue // skip expired records
		}
		var rec ScanRecord
		if json.Unmarshal([]byte(raw), &rec) == nil {
			out = append(out, rec)
		}
	}
	return out, nil
}

// Stats is the aggregated dashboard payload.
type Stats struct {
	TotalScans    int            `json:"total_scans"`
	TotalFindings int            `json:"total_findings"`
	BySeverity    map[string]int `json:"by_severity"`
	ByStatus      map[string]int `json:"by_status"`
	PerProgram    []ProgramStat  `json:"per_program"`
	Recent        []ScanRecord   `json:"recent"`
	GeneratedAt   time.Time      `json:"generated_at"`
}

// ProgramStat is the per-program ROI view (findings density per program).
type ProgramStat struct {
	Program  string `json:"program"`
	Scans    int    `json:"scans"`
	Findings int    `json:"findings"`
	Critical int    `json:"critical"`
	High     int    `json:"high"`
	// SignalScore is a simple ROI proxy: weighted findings per scan. Higher = a
	// program that has been more productive for this hunter.
	SignalScore float64 `json:"signal_score"`
}

// Aggregate computes dashboard stats from the user's history.
func (s *Store) Aggregate(ctx context.Context, userID string) (*Stats, error) {
	history, err := s.History(ctx, userID, 500)
	if err != nil {
		return nil, err
	}
	st := &Stats{
		BySeverity:  map[string]int{},
		ByStatus:    map[string]int{},
		GeneratedAt: time.Now().UTC(),
	}
	progAgg := map[string]*ProgramStat{}

	for _, rec := range history {
		st.TotalScans++
		st.ByStatus[rec.Status]++

		prog := rec.Program
		if prog == "" {
			prog = programFromTarget(rec.Target)
		}
		p := progAgg[prog]
		if p == nil {
			p = &ProgramStat{Program: prog}
			progAgg[prog] = p
		}
		p.Scans++

		for sev, n := range rec.Findings {
			st.BySeverity[sev] += n
			st.TotalFindings += n
			p.Findings += n
			switch sev {
			case "critical":
				p.Critical += n
			case "high":
				p.High += n
			}
		}
	}

	// Signal score = (4*crit + 3*high + findings) / scans — a rough ROI proxy.
	for _, p := range progAgg {
		if p.Scans > 0 {
			p.SignalScore = float64(4*p.Critical+3*p.High+p.Findings) / float64(p.Scans)
		}
		st.PerProgram = append(st.PerProgram, *p)
	}
	sort.Slice(st.PerProgram, func(i, j int) bool {
		return st.PerProgram[i].SignalScore > st.PerProgram[j].SignalScore
	})

	if len(history) > 10 {
		st.Recent = history[:10]
	} else {
		st.Recent = history
	}
	return st, nil
}

// programFromTarget derives a program label from a target host when none was set
// (e.g. "https://app.example.com/x" → "example.com").
func programFromTarget(target string) string {
	t := target
	for _, p := range []string{"https://", "http://"} {
		if len(t) > len(p) && t[:len(p)] == p {
			t = t[len(p):]
		}
	}
	// strip path
	for i := 0; i < len(t); i++ {
		if t[i] == '/' {
			t = t[:i]
			break
		}
	}
	// strip port
	for i := 0; i < len(t); i++ {
		if t[i] == ':' {
			t = t[:i]
			break
		}
	}
	// reduce to last two labels (eTLD+1 approximation)
	dots := []int{}
	for i, c := range t {
		if c == '.' {
			dots = append(dots, i)
		}
	}
	if len(dots) >= 2 {
		return t[dots[len(dots)-2]+1:]
	}
	if t == "" {
		return "unknown"
	}
	return t
}

// parseIntDefault is a small helper for query params.
func parseIntDefault(s string, def int) int {
	if s == "" {
		return def
	}
	n, err := strconv.Atoi(s)
	if err != nil {
		return def
	}
	return n
}
