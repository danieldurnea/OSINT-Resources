// Allow TypeScript to accept bare CSS imports (e.g. dynamic import of xterm.css).
// Next.js handles the actual bundling; this declaration satisfies the type checker.
declare module "*.css" {
  const styles: Record<string, string>;
  export default styles;
}
