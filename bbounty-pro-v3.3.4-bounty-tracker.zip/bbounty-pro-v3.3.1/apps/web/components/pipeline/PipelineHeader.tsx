"use client";

import { cn } from "@/lib/utils";
import { Shield, Wifi, WifiOff } from "lucide-react";
import { useEffect, useState } from "react";

type Phase = "ANALYZE" | "PLAN" | "EXECUTE" | "ITERATE" | "IDLE";

interface Props {
  phase: Phase;
  isScanning: boolean;
  scanID: string | null;
}

const PHASE_ORDER: Phase[] = ["ANALYZE", "PLAN", "EXECUTE", "ITERATE"];

const PHASE_COLORS: Record<Phase, string> = {
  ANALYZE: "#00e5cc",
  PLAN:    "#7c6aff",
  EXECUTE: "#ff9b3a",
  ITERATE: "#ff3a5c",
  IDLE:    "#2a4a5a",
};

export function PipelineHeader({ phase, isScanning, scanID }: Props) {
  const [tick, setTick] = useState(0);
  const [wsConnected, setWsConnected] = useState(false);

  // Blink tick for scanning animation
  useEffect(() => {
    if (!isScanning) return;
    const id = setInterval(() => setTick(t => t + 1), 800);
    return () => clearInterval(id);
  }, [isScanning]);

  const currentIdx = PHASE_ORDER.indexOf(phase as any);

  return (
    <header className="flex items-center justify-between px-6 py-3 bg-[#080c0e] border-b border-[#1a2a32]">
      {/* Branding */}
      <div className="flex items-center gap-3">
        <Shield size={20} className="text-[#00e5cc]" strokeWidth={2} />
        <div>
          <div className="text-sm font-bold tracking-[0.15em] text-[#c8d8e0]">
            BBOUNTY<span className="text-[#00e5cc]">·PRO</span>
          </div>
          <div className="text-[10px] text-[#2a5a6a] tracking-widest">
            AI-POWERED BUG BOUNTY AGENT v2.0
          </div>
        </div>
      </div>

      {/* Phase indicators — the centrepiece */}
      <div className="flex items-center gap-1">
        {PHASE_ORDER.map((p, i) => {
          const isActive = p === phase && isScanning;
          const isDone = currentIdx > i && isScanning;
          const color = PHASE_COLORS[p];

          return (
            <div key={p} className="flex items-center gap-1">
              {/* Phase pill */}
              <div
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold tracking-widest",
                  "transition-all duration-300 border",
                  isActive
                    ? "border-current text-current shadow-lg"
                    : isDone
                    ? "border-[#1a4a3a] text-[#2a9a7a] bg-[#0a1f19]"
                    : "border-[#1a2a32] text-[#2a4a5a] bg-transparent"
                )}
                style={{
                  color: isActive ? color : undefined,
                  borderColor: isActive ? color : undefined,
                  boxShadow: isActive ? `0 0 12px ${color}30` : undefined,
                }}
              >
                {/* Activity dot */}
                <span
                  className={cn(
                    "w-1.5 h-1.5 rounded-full",
                    isActive && tick % 2 === 0 ? "opacity-100" : isActive ? "opacity-30" : "opacity-20"
                  )}
                  style={{ background: isActive ? color : isDone ? "#2a9a7a" : "#2a4a5a" }}
                />
                {p}
                {isDone && <span className="text-[#2a9a7a]">✓</span>}
              </div>

              {/* Connector arrow */}
              {i < PHASE_ORDER.length - 1 && (
                <div
                  className="text-[10px] mx-0.5"
                  style={{
                    color: isDone || isActive ? "#2a4a5a" : "#1a2a32",
                  }}
                >
                  →
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Right: scan ID + WS status */}
      <div className="flex items-center gap-4 text-[10px]">
        {scanID && (
          <div className="text-[#2a5a6a] font-mono">
            SCAN <span className="text-[#4a8a9a]">{scanID.slice(0, 8).toUpperCase()}</span>
          </div>
        )}
        <div className={cn("flex items-center gap-1.5", wsConnected ? "text-[#00e5cc]" : "text-[#4a3a3a]")}>
          {wsConnected ? <Wifi size={12} /> : <WifiOff size={12} />}
          <span className="tracking-widest">{wsConnected ? "LIVE" : "OFFLINE"}</span>
        </div>
      </div>
    </header>
  );
}
