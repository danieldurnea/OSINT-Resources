"use client";

import { useMemo } from "react";
import type { ReactNode } from "react";
import useSWR from "swr";
import { Database, ShieldOff, Layers } from "lucide-react";
import { vulndbAPI } from "@/lib/api-client";

interface Entry {
  fingerprint: string;
  title: string;
  url: string;
  category: string;
  severity: string;
  status: string;
  times_seen: number;
  last_seen: string;
}
interface Stats {
  total_entries: number;
  false_positives: number;
  by_category: Record<string, number>;
  by_status: Record<string, number>;
}

const SEV_COLOR: Record<string, string> = {
  critical: "#ff3a5c", high: "#ff9b3a", medium: "#ffcc3a", low: "#7c6aff", info: "#4a8a9a",
};

export default function VulnDatabase() {
  const { data: stats } = useSWR<Stats>(
    "vulndb-stats",
    () => vulndbAPI.stats() as Promise<Stats>,
    { revalidateOnFocus: true }
  );
  const { data: listData, isLoading } = useSWR<{ entries: Entry[] }>(
    "vulndb-list",
    () => vulndbAPI.list(200) as Promise<{ entries: Entry[] }>,
    { revalidateOnFocus: true }
  );

  const entries = useMemo(() => listData?.entries || [], [listData]);

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center gap-3">
        <Database className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Vulnerability Database</h1>
      </header>

      {/* ── Stat cards ──────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <Card icon={<Layers size={16} />} label="Total entries" value={stats?.total_entries ?? 0} />
        <Card
          icon={<ShieldOff size={16} className="text-[#ff9b3a]" />}
          label="Known false positives"
          value={stats?.false_positives ?? 0}
        />
        <Card
          icon={<Database size={16} />}
          label="Categories"
          value={stats ? Object.keys(stats.by_category || {}).length : 0}
        />
      </div>

      {/* ── History table ───────────────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
        <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">
          History{" "}
          <span className="text-[#5a6b72] normal-case tracking-normal">
            (fingerprinted — repeats across scans are merged)
          </span>
        </h2>

        {isLoading ? (
          <p className="text-[#5a6b72] text-xs animate-pulse">▸ loading…</p>
        ) : entries.length === 0 ? (
          <p className="text-[#5a6b72] text-xs">
            Empty for now — findings are recorded here as you scan.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-[#5a6b72] text-left">
                  <th className="py-1 pr-3 font-normal">Title</th>
                  <th className="py-1 pr-3 font-normal">Category</th>
                  <th className="py-1 pr-3 font-normal">Sev</th>
                  <th className="py-1 pr-3 font-normal">Status</th>
                  <th className="py-1 pr-3 font-normal">Seen</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => {
                  const fp = e.status === "invalid" || e.status === "duplicate";
                  return (
                    <tr
                      key={e.fingerprint}
                      className={`border-t border-[#141f23] ${fp ? "opacity-50" : ""}`}
                    >
                      <td className="py-1.5 pr-3 text-[#c8d8e0] truncate max-w-[260px]">
                        {e.title}
                        {fp && (
                          <span className="ml-2 text-[10px] text-[#ff9b3a]">[FP]</span>
                        )}
                      </td>
                      <td className="py-1.5 pr-3 text-[#8aa0aa]">{e.category}</td>
                      <td
                        className="py-1.5 pr-3"
                        style={{ color: SEV_COLOR[e.severity] || "#8aa0aa" }}
                      >
                        {e.severity}
                      </td>
                      <td className="py-1.5 pr-3 text-[#8aa0aa]">{e.status}</td>
                      <td className="py-1.5 pr-3 text-[#5a6b72]">{e.times_seen}×</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <p className="text-[11px] text-[#5a6b72]">
        When you mark a finding invalid or duplicate, its fingerprint is remembered
        as a false positive — future identical findings are flagged automatically,
        cutting repeat noise across scans.
      </p>
    </div>
  );
}

function Card({
  icon,
  label,
  value,
}: {
  icon: ReactNode;
  label: string;
  value: number;
}) {
  return (
    <div className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
      <div className="flex items-center gap-2 text-[#5a6b72] text-[11px] uppercase tracking-wider">
        {icon}
        {label}
      </div>
      <div className="text-2xl mt-1 text-[#c8d8e0]">{value}</div>
    </div>
  );
}
