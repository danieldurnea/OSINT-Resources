// Package vps — Deployment mode enforcement
//
// BBounty Pro supports two runtime modes:
//
//   MODE=vps     (default in production)
//     - Refuses startup on localhost
//     - Requires public network interface
//     - Refuses empty JWT_SECRET
//
//   MODE=local
//     - Allows localhost binding (Kali native install)
//     - Skips public IP requirement
//     - Still requires JWT_SECRET (security never optional)
//     - Logs prominent warning at startup
//
// Backwards compatible: ALLOW_LOCAL=true still works as MODE=local.
//
// The orchestrator picks mode in this order:
//   1. MODE env var (preferred)
//   2. ALLOW_LOCAL=true → MODE=local
//   3. default → MODE=vps

package vps

import (
	"errors"
	"fmt"
	"net"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/rs/zerolog/log"
)

// Mode represents the deployment mode.
type Mode string

const (
	ModeVPS   Mode = "vps"   // production / public server
	ModeLocal Mode = "local" // local Kali install or dev workstation
)

// CurrentMode returns the active deployment mode.
func CurrentMode() Mode {
	if m := strings.ToLower(os.Getenv("MODE")); m == "local" || m == "vps" {
		return Mode(m)
	}
	if os.Getenv("ALLOW_LOCAL") == "true" {
		return ModeLocal
	}
	return ModeVPS
}

// EnforceMode validates the runtime environment matches the chosen mode.
// Returns nil on success, an error explaining the failure on rejection.
func EnforceMode() error {
	mode := CurrentMode()
	log.Info().Str("mode", string(mode)).Msg("vps: deployment mode")

	switch mode {
	case ModeLocal:
		return enforceLocal()
	case ModeVPS:
		return enforceVPS()
	}
	return fmt.Errorf("unknown mode: %s", mode)
}

// EnforceVPSOnly is the legacy entrypoint kept for backwards compatibility.
// New code should call EnforceMode() instead.
func EnforceVPSOnly() error {
	return EnforceMode()
}

// ── Local mode ────────────────────────────────────────────────────────────────

func enforceLocal() error {
	log.Warn().Msg("vps: MODE=local — running on workstation, NOT for public scanning")
	log.Warn().Msg("vps: localhost binding allowed; bug bounty programs see your residential IP")
	log.Warn().Msg("vps: for HackerOne/Bugcrowd targets, use a real VPS with MODE=vps")

	bindAddr := bindOrDefault("127.0.0.1")
	log.Info().Str("bind", bindAddr).Msg("vps: local mode active")

	// JWT_SECRET still required even locally — never compromise on auth.
	if os.Getenv("JWT_SECRET") == "" {
		return errors.New("JWT_SECRET required even in local mode — generate with: openssl rand -hex 32")
	}
	return nil
}

// ── VPS mode ──────────────────────────────────────────────────────────────────

func enforceVPS() error {
	bindAddr := bindOrDefault("0.0.0.0")
	if isLoopback(bindAddr) {
		return fmt.Errorf("BIND_ADDR=%q is loopback in VPS mode — set MODE=local for workstation, or use 0.0.0.0", bindAddr)
	}

	hasPublic, err := hasPublicInterface()
	if err != nil {
		log.Warn().Err(err).Msg("vps: interface enumeration failed")
	}
	if !hasPublic {
		return errors.New("no public network interface detected — set MODE=local if running on workstation")
	}

	if !canReachInternet() {
		log.Warn().Msg("vps: outbound internet check failed — AI/external APIs may not work")
	}

	if os.Getenv("ENV") == "production" && os.Getenv("VPS_DOMAIN") == "" {
		log.Warn().Msg("vps: ENV=production but VPS_DOMAIN unset — CORS may break")
	}

	log.Info().Str("bind", bindAddr).Bool("public_iface", hasPublic).Msg("vps: deployment checks passed")
	return nil
}

// ── Helpers ───────────────────────────────────────────────────────────────────

func bindOrDefault(def string) string {
	addr := os.Getenv("BIND_ADDR")
	if addr == "" {
		return def
	}
	return addr
}

func isLoopback(addr string) bool {
	if addr == "" {
		return false
	}
	if i := strings.LastIndex(addr, ":"); i > 0 {
		addr = addr[:i]
	}
	addr = strings.Trim(addr, "[]")
	if addr == "localhost" {
		return true
	}
	ip := net.ParseIP(addr)
	if ip == nil {
		ips, err := net.LookupIP(addr)
		if err != nil || len(ips) == 0 {
			return false
		}
		ip = ips[0]
	}
	return ip.IsLoopback()
}

func hasPublicInterface() (bool, error) {
	ifaces, err := net.Interfaces()
	if err != nil {
		return false, err
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip == nil || ip.IsLoopback() || ip.IsLinkLocalUnicast() {
				continue
			}
			if ip.To4() != nil {
				return true, nil
			}
		}
	}
	return false, nil
}

func canReachInternet() bool {
	conn, err := net.DialTimeout("tcp", "1.1.1.1:443", 3*time.Second)
	if err != nil {
		return false
	}
	conn.Close()
	return true
}

// PublicIP queries an external service for the host's public IP.
// Returns "127.0.0.1" in local mode, "unknown" on failure.
func PublicIP() string {
	if CurrentMode() == ModeLocal {
		return "127.0.0.1"
	}
	client := http.Client{Timeout: 3 * time.Second}
	resp, err := client.Get("https://api.ipify.org")
	if err != nil {
		return "unknown"
	}
	defer resp.Body.Close()
	buf := make([]byte, 64)
	n, _ := resp.Body.Read(buf)
	return strings.TrimSpace(string(buf[:n]))
}

// RequirePublicAccess is HTTP middleware that rejects loopback requests
// in VPS mode unless they're proxied (X-Forwarded-For set).
// Pass-through in local mode.
func RequirePublicAccess(next http.Handler) http.Handler {
	mode := CurrentMode()
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if mode == ModeLocal {
			next.ServeHTTP(w, r)
			return
		}
		ip := extractIP(r)
		parsed := net.ParseIP(ip)
		if parsed != nil && parsed.IsLoopback() {
			if r.Header.Get("X-Forwarded-For") == "" && r.Header.Get("X-Real-IP") == "" {
				http.Error(w,
					`{"error":"local access not permitted in VPS mode"}`,
					http.StatusForbidden)
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

func extractIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		if i := strings.Index(xff, ","); i > 0 {
			return strings.TrimSpace(xff[:i])
		}
		return strings.TrimSpace(xff)
	}
	if xri := r.Header.Get("X-Real-IP"); xri != "" {
		return xri
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}
