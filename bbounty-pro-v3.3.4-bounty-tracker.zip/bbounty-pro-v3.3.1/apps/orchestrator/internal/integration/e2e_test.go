// Integration test for the complete BBounty Pro workflow.
// Spins up an in-memory orchestrator with miniredis and tests:
//   1. User registration → first user becomes admin
//   2. Admin generates invite code
//   3. Hunter registers with invite code
//   4. ROE validation
//   5. Scan start (mocked tools)
//   6. Findings creation + retrieval
//   7. Diff snapshot save + compare
//
// Limitations:
//   - Uses miniredis, not real Redis cluster
//   - Tools are stubbed (no actual nuclei/httpx execution)
//   - No real WebSocket testing (race conditions on goroutines)
//
// Run: cd apps/orchestrator && go test ./... -tags=integration

//go:build integration

package integration_test

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/alicebob/miniredis/v2"
	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/diff"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/go-chi/chi/v5"
	"github.com/redis/go-redis/v9"
)

func setupTestServer(t *testing.T) (*chi.Mux, *miniredis.Miniredis, func()) {
	t.Helper()
	mr, err := miniredis.Run()
	if err != nil {
		t.Fatalf("miniredis: %v", err)
	}
	rdb := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	c := cache.NewFromClient(rdb)

	authMgr := auth.NewManager(c, "test-secret-32-bytes-minimum-len!")
	roeGate := roe.NewGate()
	store := findings.NewStore(c)
	diffEngine := diff.NewEngine(c)

	r := chi.NewRouter()
	r.Route("/auth", func(r chi.Router) {
		r.Post("/register", authMgr.HandleRegister)
		r.Post("/login", authMgr.HandleLogin)
		r.Group(func(r chi.Router) {
			r.Use(authMgr.Middleware)
			r.Post("/invite", authMgr.HandleInvite)
		})
	})
	r.Route("/api/v1", func(r chi.Router) {
		r.Use(authMgr.Middleware)
		r.Post("/roe/validate", roeGate.HandleValidate)
		r.Post("/findings", store.HandleCreate)
		r.Get("/findings/{scanID}", store.HandleList)
	})

	cleanup := func() {
		rdb.Close()
		mr.Close()
	}
	_ = diffEngine
	return r, mr, cleanup
}

// helper: POST JSON, return decoded response
func postJSON(t *testing.T, r http.Handler, path, token string, body any) (int, map[string]any) {
	t.Helper()
	data, _ := json.Marshal(body)
	req := httptest.NewRequest("POST", path, bytes.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	var out map[string]any
	json.NewDecoder(w.Body).Decode(&out)
	return w.Code, out
}

// TestE2E_FullWorkflow runs the full happy-path flow end-to-end.
func TestE2E_FullWorkflow(t *testing.T) {
	srv, _, cleanup := setupTestServer(t)
	defer cleanup()

	// ── Step 1: First user registers (becomes admin) ────────────────────
	code, resp := postJSON(t, srv, "/auth/register", "", map[string]string{
		"username": "alice",
		"email":    "alice@example.com",
		"password": "alice-strong-password-2026",
	})
	if code != 201 {
		t.Fatalf("register admin: got %d, want 201; body=%v", code, resp)
	}
	adminToken, _ := resp["access_token"].(string)
	if adminToken == "" {
		t.Fatal("admin: no access token returned")
	}
	user, _ := resp["user"].(map[string]any)
	if role, _ := user["role"].(string); role != "admin" {
		t.Errorf("first user role = %q, want admin", role)
	}

	// ── Step 2: Admin generates invite for hunter ────────────────────────
	code, resp = postJSON(t, srv, "/auth/invite", adminToken, map[string]string{
		"role": "hunter",
	})
	if code != 200 {
		t.Fatalf("generate invite: got %d, want 200", code)
	}
	inviteCode, _ := resp["invite_code"].(string)
	if inviteCode == "" {
		t.Fatal("no invite_code returned")
	}

	// ── Step 3: Hunter registers with invite ─────────────────────────────
	code, resp = postJSON(t, srv, "/auth/register", "", map[string]string{
		"username":    "bob-hunter",
		"email":       "bob@example.com",
		"password":    "bob-strong-password-2026",
		"invite_code": inviteCode,
	})
	if code != 201 {
		t.Fatalf("hunter register: got %d, want 201", code)
	}
	hunterToken, _ := resp["access_token"].(string)
	user, _ = resp["user"].(map[string]any)
	if role, _ := user["role"].(string); role != "hunter" {
		t.Errorf("hunter role = %q, want hunter", role)
	}

	// ── Step 4: ROE validation — valid scope ──────────────────────────────
	code, resp = postJSON(t, srv, "/api/v1/roe/validate", hunterToken, map[string]any{
		"target":   "test.example.com",
		"program":  "test-program",
		"tester":   "bob-hunter",
		"scope":    []string{"*.example.com"},
		"excluded": []string{"prod.example.com"},
		"platform": "private",
	})
	if code != 200 {
		t.Errorf("ROE validate: got %d, want 200; body=%v", code, resp)
	}
	if valid, _ := resp["valid"].(bool); !valid {
		t.Errorf("ROE valid = false, want true")
	}

	// ── Step 5: ROE rejects out-of-scope target ──────────────────────────
	code, resp = postJSON(t, srv, "/api/v1/roe/validate", hunterToken, map[string]any{
		"target": "other.com",
		"scope":  []string{"*.example.com"},
	})
	if valid, _ := resp["valid"].(bool); valid {
		t.Errorf("ROE accepted out-of-scope target")
	}

	// ── Step 6: Hunter creates a finding ─────────────────────────────────
	code, resp = postJSON(t, srv, "/api/v1/findings", hunterToken, map[string]any{
		"scan_id":  "scan-test-001",
		"title":    "Test SQL Injection",
		"url":      "https://test.example.com/api/users?id=1",
		"severity": "high",
		"category": "SQLi",
		"source":   "manual",
	})
	if code != 201 {
		t.Errorf("create finding: got %d, want 201; body=%v", code, resp)
	}
	if id, _ := resp["id"].(string); id == "" {
		t.Errorf("finding has no id")
	}

	// ── Step 7: Hunter lists findings ────────────────────────────────────
	req := httptest.NewRequest("GET", "/api/v1/findings/scan-test-001", nil)
	req.Header.Set("Authorization", "Bearer "+hunterToken)
	w := httptest.NewRecorder()
	srv.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Errorf("list findings: got %d", w.Code)
	}

	var listResp []any
	json.NewDecoder(w.Body).Decode(&listResp)
	if len(listResp) != 1 {
		t.Errorf("findings list has %d items, want 1", len(listResp))
	}
}

// TestE2E_AuthFailures verifies authentication failure modes.
func TestE2E_AuthFailures(t *testing.T) {
	srv, _, cleanup := setupTestServer(t)
	defer cleanup()

	// Register first user
	postJSON(t, srv, "/auth/register", "", map[string]string{
		"username": "admin", "email": "a@a.com", "password": "passwd1234567",
	})

	// Second user without invite — should fail
	code, resp := postJSON(t, srv, "/auth/register", "", map[string]string{
		"username": "intruder", "email": "x@x.com", "password": "passwd1234567",
	})
	if code == 201 {
		t.Errorf("second user registered without invite — security failure")
	}
	if errMsg, _ := resp["error"].(string); !strings.Contains(errMsg, "invite") {
		t.Errorf("expected invite error, got: %v", errMsg)
	}

	// Login with wrong password
	code, _ = postJSON(t, srv, "/auth/login", "", map[string]string{
		"username": "admin", "password": "wrong-password",
	})
	if code != 401 {
		t.Errorf("wrong password: got %d, want 401", code)
	}

	// Access protected endpoint without token
	req := httptest.NewRequest("POST", "/api/v1/roe/validate", strings.NewReader("{}"))
	w := httptest.NewRecorder()
	srv.ServeHTTP(w, req)
	if w.Code != 401 {
		t.Errorf("no token: got %d, want 401", w.Code)
	}

	// Access protected endpoint with bad token
	req = httptest.NewRequest("POST", "/api/v1/roe/validate", strings.NewReader("{}"))
	req.Header.Set("Authorization", "Bearer fake.token.value")
	w = httptest.NewRecorder()
	srv.ServeHTTP(w, req)
	if w.Code != 401 {
		t.Errorf("bad token: got %d, want 401", w.Code)
	}
}

// TestE2E_ConcurrentScans ensures concurrent operations don't corrupt state.
func TestE2E_ConcurrentScans(t *testing.T) {
	srv, _, cleanup := setupTestServer(t)
	defer cleanup()

	_, resp := postJSON(t, srv, "/auth/register", "", map[string]string{
		"username": "alice", "email": "a@a.com", "password": "passwd123456",
	})
	token, _ := resp["access_token"].(string)

	// 10 concurrent finding creations
	const N = 10
	done := make(chan int, N)
	for i := 0; i < N; i++ {
		go func(i int) {
			code, _ := postJSON(t, srv, "/api/v1/findings", token, map[string]any{
				"scan_id":  "concurrent-scan",
				"title":    "Finding-" + string(rune('A'+i)),
				"url":      "https://test.com/" + string(rune('A'+i)),
				"severity": "medium",
				"category": "test",
			})
			done <- code
		}(i)
	}

	successes := 0
	for i := 0; i < N; i++ {
		select {
		case code := <-done:
			if code == 201 {
				successes++
			}
		case <-time.After(5 * time.Second):
			t.Fatal("timeout waiting for concurrent finds")
		}
	}
	if successes != N {
		t.Errorf("concurrent: %d/%d succeeded", successes, N)
	}
}
