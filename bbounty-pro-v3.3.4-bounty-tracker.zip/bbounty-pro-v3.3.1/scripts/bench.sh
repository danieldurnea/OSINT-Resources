#!/usr/bin/env bash
# BBounty Pro — Performance Benchmark
# Tests: API latency, WS throughput, tool startup time, Go binary size
set -euo pipefail

ORCHESTRATOR="${ORCHESTRATOR_URL:-http://localhost:8080}"
CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'; BOLD='\033[1m'

section() { echo -e "\n${BOLD}${CYAN}── $1 ──${NC}"; }
result()  { printf "  %-30s ${GREEN}%s${NC}\n" "$1" "$2"; }

echo -e "${BOLD}${CYAN}BBounty Pro — Performance Benchmark${NC}"
echo -e "$(date)"

# ─── Binary Size ──────────────────────────────────────────────────────────────
section "Binary Sizes"
[[ -f bin/orchestrator ]] && \
    result "Go orchestrator" "$(du -sh bin/orchestrator | cut -f1)"
[[ -d apps/web/.next ]] && \
    result "Next.js build" "$(du -sh apps/web/.next | cut -f1)"

# ─── API Latency ──────────────────────────────────────────────────────────────
section "API Latency (100 requests)"
if command -v hey &>/dev/null; then
    hey -n 100 -c 10 -q 0 "$ORCHESTRATOR/healthz" 2>&1 | grep -E "Requests/sec|Average|99th"
elif command -v ab &>/dev/null; then
    ab -n 100 -c 10 "$ORCHESTRATOR/healthz" 2>&1 | grep -E "Requests per|Time per request"
else
    # Simple latency test with curl
    TOTAL=0
    for i in $(seq 1 20); do
        T=$(curl -o /dev/null -s -w "%{time_total}" "$ORCHESTRATOR/healthz" 2>/dev/null || echo 0)
        TOTAL=$(echo "$TOTAL + $T" | bc -l 2>/dev/null || echo $TOTAL)
    done
    AVG=$(echo "scale=3; $TOTAL / 20 * 1000" | bc -l 2>/dev/null || echo "?")
    result "Avg healthz latency" "${AVG}ms"
fi

# ─── Tool Startup Times ───────────────────────────────────────────────────────
section "Tool Startup Benchmarks"
bench_tool() {
    local name="$1"; shift
    if ! command -v "$1" &>/dev/null; then echo "  - $name (not installed)"; return; fi
    local start=$(date +%s%3N)
    "$@" &>/dev/null 2>&1 || true
    local end=$(date +%s%3N)
    result "$name startup" "$((end - start))ms"
}

bench_tool "subfinder -version" subfinder -version
bench_tool "httpx -version"     httpx -version
bench_tool "nuclei -version"    nuclei -version
bench_tool "ffuf -V"            ffuf -V
bench_tool "naabu -version"     naabu -version
bench_tool "gf (list)"          gf -list

# ─── Scan API ─────────────────────────────────────────────────────────────────
section "Scan API Response Time"
if command -v curl &>/dev/null; then
    T=$(curl -o /dev/null -s -w "%{time_total}" \
        -X POST "$ORCHESTRATOR/api/v1/roe/validate" \
        -H "Content-Type: application/json" \
        -d '{"target":"test.example.com","scope":["*.example.com"],"tester":"bench"}' \
        2>/dev/null || echo 0)
    result "ROE validate latency" "$(echo "$T * 1000" | bc -l | cut -d. -f1)ms"
fi

# ─── Concurrent Pipeline Capacity ─────────────────────────────────────────────
section "Semaphore / Concurrency"
result "Max concurrent tools config" "${MAX_CONCURRENT_TOOLS:-8}"
result "CPU cores available" "$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo '?')"
result "RAM available" "$(free -h 2>/dev/null | awk '/^Mem:/{print $7}' || echo '?')"

# ─── Build Speed ──────────────────────────────────────────────────────────────
section "Build Performance"
if [[ -f apps/orchestrator/go.mod ]]; then
    START=$(date +%s%3N)
    cd apps/orchestrator && \
        CGO_ENABLED=0 go build -ldflags='-s -w' -trimpath -o /dev/null ./cmd/server 2>/dev/null
    END=$(date +%s%3N)
    cd ../..
    result "Go build (cold)" "$((END-START))ms"
fi

echo ""
echo -e "${GREEN}Benchmark complete${NC}"
