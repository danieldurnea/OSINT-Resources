# BBounty Pro v3.3 — Known Issues & Architectural Debt

## Fixed in this build (v3.3-zen)

| # | Bug | Where | Fix |
|---|-----|-------|-----|
| 1 | `PasswordHash json:"-"` → all logins fail | `auth/manager.go` | Renamed tag, added `redact()` helper, all HTTP handlers sanitise |
| 2 | Unused imports break compile | `tools/registry.go`, `skills/registry.go`, `agent/checkpoint.go` | Removed |
| 3 | `_ = redis.Nil` dead shim + unused redis import | `findings/postgres_sync.go` | Removed |
| 4 | Phantom `@radix-ui/react-badge` dep | `web/package.json` | Removed |
| 5 | JSX in `.ts` file | `hooks/useAuth.ts` | Renamed to `.tsx` |
| 6 | `ScanRequest`, `ScanStartResponse` missing from shared-types | `packages/shared-types/index.ts` | Added |
| 7 | `store.ts` missing interface methods + implicit `any` params | `lib/store.ts` | Full typed rewrite |
| 8 | `target` interpolated into bash without validation | `tools/executor.go` | Added `SafeTarget()` + `SafeScope()` strict validators |
| 9 | `ScopeFilter` passed unsanitised scope entries | `tools/executor.go` | Uses `SafeScope()` now; CIDR entries skipped gracefully |
| 10 | `phases[].runFn` field never read | `agent/pipeline.go` | Removed dead field |
| 11 | `parseStats()` defined, never called | `agent/pipeline.go` | Removed |
| 12 | `os.MkdirAll` error silently ignored | `agent/pipeline.go` | Now logged + falls back to `/tmp` |
| 13 | Pipeline skipped on empty `BuildCommand` | `agent/pipeline.go` | Now broadcasts `tool_skipped` event |
| 14 | `filterOutputsInScope` wired into pipeline loop | `agent/pipeline.go` | Now runs `roe.Gate.CheckURL` on tool output files between phases |
| 15 | `roe.CheckURL` / `FilterURLs` defined but never called | `roe/recheck.go` | Now wired via `filterOutputsInScope` |
| 16 | `checkRefreshRate` defined but never wired | `auth/refresh_limit.go` | Wired into `Refresh()` |
| 17 | `GenerateInvite` ignores `rand.Read` error | `auth/manager.go` | Error now propagates |
| 18 | CSRF `rand.Read` error silently ignored | `auth/cookies.go` | Now returns 500 instead of issuing weak token |
| 19 | `ws.CheckOrigin` always returns true | `ws/hub.go` | Restricted to `FRONTEND_URL` env var; falls back to localhost |
| 20 | `aiEnrichAsync` comment/doc misleading | `priority/scorer.go` | Clarified |
| 21 | CSS `*.d.ts` missing | `web/types/css.d.ts` | Added — fixes `tsc --noEmit` for xterm CSS dynamic import |

## Remaining architectural debt (not fixed — documented)

### Partially-implemented modules (wired for compilation, not wired into main.go)

These modules exist and compile but are **not started** by `cmd/server/main.go`.
They need explicit wiring if you want them active:

| Module | What it does | Wire-up needed | Status |
|--------|-------------|----------------|--------|
| `internal/auditlog` | Redis pub/sub → Postgres audit trail | `go logger.Run(ctx)` in main.go; pass `pgxpool` | ✅ Wired |
| `internal/health` | `/livez` + `/readyz` probes | Mount `checker.HandleLive` + `checker.HandleReady` routes | ✅ Wired |
| `internal/metrics` | Prometheus-compatible `/metrics` endpoint | Mount `metrics.HandleMetrics` route | ✅ Wired |
| `internal/notify` | Slack/Discord/Telegram webhooks | `notify.New()` in main.go; call from diff engine | ✅ Wired — now also injected into pipeline via `SetNotifier()` |
| `internal/findings/postgres_sync.go` | Redis → Postgres sync loop | `go syncer.Run(ctx)` in main.go | ✅ Wired |
| `internal/findings/stream.go` | SSE stream of findings | Mount `stream.Handle` route | ✅ Wired |
| `internal/auth/cookies.go` | HttpOnly cookie auth | Use `MiddlewareWithCookies` instead of `Middleware` | ⚠️ Backend done; frontend still uses sessionStorage |
| `internal/agent/checkpoint.go` | Redis-backed scan resume | Call `checkpointStore.Save()` on each phase transition | ✅ Fixed (v3.3.1) — `Save()` is real (called every phase in pipeline.go); MANUAL resume live via `GET /scan/resumable` + `POST /scan/{id}/resume`. Auto-resume-at-boot intentionally not wired (by design). |
| `internal/ai/fallback.go` | Cache-backed AI fallback | Use `NewCachedClient(primary, cache)` instead of raw `Client` | ✅ Fixed — `/findings/{id}/analyze` now uses `cachedAI` |
| `internal/ai/zen_proxy.go` | HTTP → Python AI proxy | n/a | ✅ Resolved — file no longer exists in the tree (removed in a prior pass). Stale entry. |
| `internal/config/constants.go` | Centralised TTL constants | Replace magic numbers in other packages | ✅ Wired (v3.3.2) — 18/20 constants now referenced from their owning packages (auth/findings/checkpoint/ai/diff/notify/pipeline/main). 2 left intentionally unwired (DefaultRateLimit, OldOutputCleanup — no genuine single owner; see file header). |

### Adaptive rate-limiter — ✅ FIXED (v3.3.1, no longer dead)

`internal/ratelimit/adaptive.go` has a Token Bucket + stats collector. This was
previously "effectively dead" because the pipeline never observed HTTP status
codes. **It is now wired:** the pipeline calls `observeHTTPStatuses()` on httpx
and nuclei output, which feeds `limiter.RecordResponse()` (pipeline.go), so the
adaptive back-off on 429s can fire. Historical description retained below for
context:

- httpx output is JSONL — status codes are parsed from it.
- `RecordResponse(host, statusCode)` is called when 429 is seen.
- The limiter is constructed in main.go and `RecordResponse` IS now called from
  the pipeline.

### `internal/tools/durnea_framework.go` — ✅ DELETED (v3.3.1)

Was 474 lines of static methodology metadata with zero importers (compile-clean
dead code). It has since been removed from the tree. Stale entry — nothing to do.

### auth TOCTOU race on first-user promotion — ✅ FIXED (v3.3.2)

`isFirstUser()` previously did a non-atomic check-then-set: under concurrent
first registration, two users could both become admin (privilege escalation on
SaaS). Now promotion is **atomic** via `SETNX auth:bootstrap:admin <uid>` in
`Register()` — only the single SETNX winner is promoted to admin; the dead
`isFirstUser()` helper was removed. Covered by `TestRegister_AtomicAdminBootstrap`.

### PostgreSQL is optional but sync is not automatic

If you provide `DATABASE_URL`, findings are stored in Redis **and** Postgres.
But `PostgresSync.Run()` must be started manually in main.go. Without it,
Postgres stays empty even if the pool connects.

## VPS first-run checklist

```
# 1. Copy env template
cp .env.example .env
# Edit: ANTHROPIC_API_KEY, JWT_SECRET (>=32 chars), FRONTEND_URL, REDIS_URL

# 2. Start infra
docker compose up -d postgres redis

# 3. Build orchestrator
cd apps/orchestrator && go build -o ../../dist/orchestrator ./cmd/server
# (Requires Go 1.26+)

# 4. Build frontend
cd apps/web && npm install && npm run build

# 5. Start AI proxy
cd apps/ai-proxy && pip install -r requirements.txt && uvicorn main:app --port 8001

# 6. Start orchestrator
./dist/orchestrator

# 7. Start frontend
cd apps/web && npm start
```

## Environment variables

| Variable | Default | Required |
|----------|---------|----------|
| `ANTHROPIC_API_KEY` | — | Yes (AI proxy) |
| `JWT_SECRET` | — | Yes (≥32 chars) |
| `REDIS_URL` | `redis://localhost:6379` | Yes |
| `DATABASE_URL` | — | No (Redis-only mode if absent) |
| `FRONTEND_URL` | `http://localhost:3000` | Recommended (WS origin check) |
| `AI_PROXY_URL` | `http://ai-proxy:8001` | Yes for AI features |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-20250514` | No |  <!-- SE-L3-FIX: corrected model string -->
| `ENV` | `development` | Set to `production` for Secure cookies |
| `PORT` | `8080` | No |
