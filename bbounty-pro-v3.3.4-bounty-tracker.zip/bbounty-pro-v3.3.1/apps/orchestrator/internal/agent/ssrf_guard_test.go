package agent

import "testing"

func TestIsInternalOrMetadataURL(t *testing.T) {
	blocked := []string{
		"http://169.254.169.254/latest/meta-data/x.js",
		"http://localhost/app.js",
		"http://127.0.0.1:8080/a.js",
		"https://10.0.0.5/x.js",
		"http://192.168.1.1/x.js",
		"http://metadata.google.internal/x.js",
		"not a url",
	}
	for _, u := range blocked {
		if !isInternalOrMetadataURL(u) {
			t.Errorf("expected %q to be blocked", u)
		}
	}
	allowed := []string{
		"https://cdn.example.com/app.bundle.js",
		"http://target.com/static/main.js",
	}
	for _, u := range allowed {
		if isInternalOrMetadataURL(u) {
			t.Errorf("expected %q to be allowed", u)
		}
	}
}
