"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Download, Bot, Copy, CheckCircle, Loader2, FileText } from "lucide-react";
import useSWR from "swr";

const fetcher = (url: string) => fetch(url).then(r => r.json());

interface Props { scanID: string | null }

export function ReportTab({ scanID }: Props) {
  const { data: findings = [] } = useSWR(
    scanID ? `/api/v1/findings/${scanID}` : null,
    fetcher
  );
  const [aiReview, setAiReview] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState<"draft" | "review">("draft");

  const report = generateMarkdownReport(findings, scanID);

  const copyReport = () => {
    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadReport = () => {
    const blob = new Blob([report], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bbounty-report-${scanID?.slice(0, 8) || "draft"}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const reviewWithAI = async () => {
    setReviewing(true);
    setTab("review");
    try {
      const res = await fetch("/api/v1/ai/report-review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ report }),
      });
      const json = await res.json();
      setAiReview(json.review);
    } catch {
      setAiReview("⚠ Failed to connect to AI agent. Check ANTHROPIC_API_KEY.");
    } finally {
      setReviewing(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1a2a32] bg-[#0a1015]">
        <div className="flex gap-1">
          {(["draft", "review"] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "px-4 py-1.5 rounded text-xs font-semibold border transition-all",
                tab === t
                  ? "border-[#00e5cc]/40 text-[#00e5cc] bg-[#00e5cc]/10"
                  : "border-[#1a2a32] text-[#4a6a7a] hover:border-[#2a4a5a]"
              )}
            >
              {t === "draft" ? "📄 Draft Report" : "🤖 AI Review"}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 ml-auto">
          <span className="text-[10px] text-[#2a5a6a]">
            {findings.length} finding{findings.length !== 1 ? "s" : ""}
          </span>

          <button
            onClick={copyReport}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded border border-[#1a2a32] text-[10px] text-[#4a6a7a] hover:border-[#2a4a5a] hover:text-[#8ab4c4] transition-all"
          >
            {copied ? <CheckCircle size={12} className="text-[#00e5cc]" /> : <Copy size={12} />}
            {copied ? "Copied!" : "Copy"}
          </button>

          <button
            onClick={downloadReport}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded border border-[#1a2a32] text-[10px] text-[#4a6a7a] hover:border-[#2a4a5a] hover:text-[#8ab4c4] transition-all"
          >
            <Download size={12} />
            Export .md
          </button>

          <button
            onClick={reviewWithAI}
            disabled={reviewing || findings.length === 0}
            className={cn(
              "flex items-center gap-1.5 px-4 py-1.5 rounded text-[10px] font-bold border transition-all",
              "border-[#7c6aff]/40 text-[#7c6aff] hover:bg-[#7c6aff]/10",
              "disabled:opacity-40 disabled:cursor-not-allowed"
            )}
          >
            {reviewing ? (
              <Loader2 size={12} className="animate-spin" />
            ) : (
              <Bot size={12} />
            )}
            {reviewing ? "Reviewing..." : "AI REVIEW"}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {tab === "draft" ? (
          <pre className="p-6 text-[11px] text-[#8ab4c4] font-mono leading-relaxed whitespace-pre-wrap">
            {report}
          </pre>
        ) : (
          <div className="p-6">
            {reviewing && (
              <div className="flex items-center gap-3 text-sm text-[#4a8a9a]">
                <Loader2 size={16} className="animate-spin text-[#7c6aff]" />
                Claude is reviewing your report...
              </div>
            )}
            {!reviewing && aiReview && (
              <div className="prose prose-invert max-w-none">
                <div className="flex items-center gap-2 mb-4">
                  <Bot size={16} className="text-[#7c6aff]" />
                  <span className="text-xs font-bold text-[#7c6aff] tracking-widest">
                    AI REVIEW COMPLETE
                  </span>
                </div>
                <pre className="text-[11px] text-[#c8d8e0] font-mono leading-relaxed whitespace-pre-wrap bg-[#0a1015] border border-[#1a2a32] rounded-xl p-4">
                  {aiReview}
                </pre>
              </div>
            )}
            {!reviewing && !aiReview && (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <Bot size={32} className="text-[#1a2a32] mb-3" />
                <div className="text-[#2a4a5a] text-sm">Click "AI REVIEW" to get Claude's feedback</div>
                <div className="text-[#1a2a32] text-xs mt-1">
                  The agent will rate your report, find gaps, and improve it for submission
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Generate a structured Markdown bug bounty report
function generateMarkdownReport(findings: any[], scanID: string | null): string {
  const now = new Date().toISOString().split("T")[0];
  const criticals = findings.filter(f => f.severity === "critical");
  const highs = findings.filter(f => f.severity === "high");
  const mediums = findings.filter(f => f.severity === "medium");
  const lows = findings.filter(f => f.severity === "low");

  const severitySection = (label: string, items: any[]) => {
    if (!items.length) return "";
    return items.map((f, i) => `
### ${label}-${String(i + 1).padStart(2, "0")}: ${f.title}

**Severity:** ${f.severity.toUpperCase()}${f.cvss ? ` (CVSS ${f.cvss.toFixed(1)})` : ""}
**URL:** \`${f.url}\`
**Category:** ${f.category || "N/A"}
${f.parameter ? `**Parameter:** \`${f.parameter}\`` : ""}
**Status:** ${f.status}
**Discovered by:** ${f.source}

#### Description
${f.ai_analysis || "_Description pending AI analysis_"}

#### Steps to Reproduce
1. Navigate to \`${f.url}\`
2. _[Add reproduction steps]_
3. Observe the vulnerability

#### Impact
_[Describe business impact]_

#### Remediation
_[Add remediation steps]_

---`).join("\n");
  };

  return `# Bug Bounty Report
**Date:** ${now}
**Scan ID:** ${scanID || "N/A"}
**Generated by:** BBounty Pro Agent v2.0

---

## Executive Summary

This report documents vulnerabilities discovered during authorized security testing.

| Severity  | Count |
|-----------|-------|
| 🔴 Critical | ${criticals.length} |
| 🟠 High     | ${highs.length} |
| 🟡 Medium   | ${mediums.length} |
| 🔵 Low      | ${lows.length} |
| **Total**   | **${findings.length}** |

---

## Findings

${severitySection("CRIT", criticals)}
${severitySection("HIGH", highs)}
${severitySection("MED", mediums)}
${severitySection("LOW", lows)}

${findings.length === 0 ? "_No findings recorded yet. Run a scan to populate this report._\n" : ""}

---

## Methodology

Scan pipeline: **ANALYZE → PLAN → EXECUTE → ITERATE**

Tools used: subfinder, assetfinder, puredns, httpx, naabu, nuclei-ai, ffuf, wfuzz, and additional tools from the BBounty Pro Arsenal.

---

## Disclosure

This report is submitted in good faith under the program's responsible disclosure policy. All testing was conducted on authorized assets within the defined scope.
`;
}
