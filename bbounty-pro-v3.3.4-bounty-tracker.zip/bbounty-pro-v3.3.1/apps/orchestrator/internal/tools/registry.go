package tools

import (
	"encoding/json"
	"net/http"
	"sort"

	"github.com/go-chi/chi/v5"
)

// Phase constants
const (
	PhaseRecon   = "recon"
	PhaseEnum    = "enumeration"
	PhaseScan    = "scanning"
	PhaseExploit = "exploitation"
	PhaseReport  = "reporting"
)

// ROIRating represents tool effectiveness score
type ROIRating int

const (
	ROILow      ROIRating = 1
	ROIMedium   ROIRating = 2
	ROIHigh     ROIRating = 3
	ROICritical ROIRating = 4
)

// Tool represents a single security tool in the registry
type Tool struct {
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	Phase       string    `json:"phase"`
	Category    string    `json:"category"`
	Description string    `json:"description"`
	InstallCmd  string    `json:"install_cmd"`
	BinaryPath  string    `json:"binary_path"`
	ROI         ROIRating `json:"roi"`
	Flags       []Flag    `json:"flags"`
	Enabled     bool      `json:"enabled"`
	Parallel    bool      `json:"parallel"` // safe to run in parallel
	Timeout     int       `json:"timeout"`  // seconds, 0 = phase default
	Tags        []string  `json:"tags"`
	// Native marks tools implemented as Go functions inside the orchestrator.
	// These are NOT spawned as subprocesses — pipeline calls them directly.
	Native bool `json:"native"`
}

type Flag struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Default     string `json:"default"`
	Required    bool   `json:"required"`
}

// Registry holds all tool definitions
type Registry struct {
	tools map[string]*Tool
}

// NewRegistry returns a registry with all 79 tools pre-loaded.
//
// Of those 79:
//   - 10 are kept registered but DEPRECATED (Enabled:false) — abandoned upstream,
//     redundant with a better-maintained alternative already in the registry,
//     or inappropriate for a headless orchestrator. Operators can re-enable
//     them manually if they really want; the installer does NOT install them.
//   - 1 is native (cors-engine — runs as a Go function in-process)
//   - The remaining 68 are subprocess tools installed by scripts/install-ubuntu.sh
//     (or scripts/install-reconftw.sh for reconftw specifically)
//
// vigolium: AGPL-3.0, now ENABLED. Per written approval from Jessie Ho (Vigolium
// creator, 2026-05-28): unmodified SaaS use via external CLI requires NO
// commercial license, only attribution via a public source link
// (see THIRD_PARTY_LICENSES.md). Only the native scan is invoked — agentic
// modes are excluded as they run unsandboxed.
//
// Deprecated tools (see ORCHESTRATOR_TOOL_INTEGRATION.md for rationale):
//
//	aquatone, 403fuzzer, astra, corsy, dnsvalidator, osmedeus,
//	race-the-web, tplmap, wfuzz, zap
func NewRegistry() *Registry {
	r := &Registry{tools: make(map[string]*Tool)}
	r.loadAll()
	return r
}

func (r *Registry) loadAll() {
	tools := []*Tool{
		// ─────────────── PHASE 1: RECON ───────────────
		// subfinder smart-mode — see executor.go:155 for the actual command.
		// Default flags in registry document the *intent*; the executor uses:
		//   -all          → all 30+ passive sources (not just default 6)
		//   -silent       → suppress banner/progress noise in logs
		//   -t 20         → 20 concurrent source workers (fast, safe rate)
		//   -timeout 30   → per-source timeout (avoid hanging sources)
		//   -sources …    → explicit source list to skip ones requiring keys we lack
		{
			ID: "subfinder", Name: "subfinder", Phase: PhaseRecon, Category: "subdomain",
			Description: "Fast passive subdomain enumeration tool",
			InstallCmd:  "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
			BinaryPath:  "subfinder", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
				{Name: "-all", Description: "Use all sources (smart-mode)", Default: "true"},
				{Name: "-silent", Description: "Silent mode (no banner/progress)"},
				{Name: "-t", Description: "Concurrent source workers", Default: "20"},
				{Name: "-timeout", Description: "Per-source timeout (seconds)", Default: "30"},
				{Name: "-o", Description: "Output file", Default: "subs.txt"},
			},
			Tags: []string{"passive", "recon", "dns"},
		},
		{
			ID: "assetfinder", Name: "assetfinder", Phase: PhaseRecon, Category: "subdomain",
			Description: "Find domains and subdomains related to a given domain",
			InstallCmd:  "go install github.com/tomnomnom/assetfinder@latest",
			BinaryPath:  "assetfinder", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{{Name: "--subs-only", Description: "Only show subdomains"}},
			Tags:  []string{"passive", "recon"},
		},
		{
			ID: "puredns", Name: "puredns", Phase: PhaseRecon, Category: "dns",
			Description: "Powerful DNS bruteforcing and resolution tool",
			InstallCmd:  "go install github.com/d3mondev/puredns/v2@latest",
			BinaryPath:  "puredns", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "bruteforce", Description: "Mode: bruteforce or resolve"},
				{Name: "--resolvers", Description: "Resolvers file", Default: "/opt/resolvers.txt"},
				{Name: "--rate-limit", Description: "Rate limit", Default: "3000"},
			},
			Tags: []string{"active", "dns", "bruteforce"},
		},
		{
			ID: "bbot", Name: "bbot", Phase: PhaseRecon, Category: "osint",
			Description: "OSINT automation tool — recursive recon powerhouse",
			InstallCmd:  "pipx install bbot",
			BinaryPath:  "bbot", ROI: ROICritical, Parallel: true, Timeout: 600,
			Flags: []Flag{
				{Name: "-t", Description: "Targets", Required: true},
				{Name: "-p", Description: "Presets", Default: "subdomain-enum"},
				{Name: "-o", Description: "Output dir"},
			},
			Tags: []string{"osint", "recon", "comprehensive"},
		},
		{
			ID: "whatweb", Name: "whatweb", Phase: PhaseRecon, Category: "fingerprint",
			Description: "Web technology fingerprinting — identifies CMS, frameworks, headers",
			InstallCmd:  "gem install whatweb",
			BinaryPath:  "whatweb", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-a", Description: "Aggression level (1-4)", Default: "3"},
				{Name: "--log-json", Description: "JSON output"},
			},
			Tags: []string{"fingerprint", "recon"},
		},
		{
			ID: "wafw00f", Name: "wafw00f", Phase: PhaseRecon, Category: "waf",
			Description: "WAF detection & fingerprinting — critical for bypass planning",
			InstallCmd:  "pip install wafw00f",
			BinaryPath:  "wafw00f", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{
				{Name: "-a", Description: "Find all WAFs"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"waf", "recon", "fingerprint"},
		},
		// gitleaks smart-mode — see executor.go:226 for the actual command.
		//   detect            → scan working tree + git history
		//   -f json           → JSON report (parsed by ParseGitleaksOutput)
		//   --redact          → cenzurează secretele în loguri (defense in depth;
		//                       findings store still maskSecret()s for display)
		//   --no-banner       → quiet output for log readability
		{
			ID: "gitleaks", Name: "gitleaks", Phase: PhaseRecon, Category: "secrets",
			Description: "Detect secrets leaked in git repos — API keys, tokens, creds",
			InstallCmd:  "go install github.com/gitleaks/gitleaks/v8@latest",
			BinaryPath:  "gitleaks", ROI: ROICritical, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "detect", Description: "Mode: detect or protect"},
				{Name: "--source", Description: "Path to repo"},
				{Name: "-f", Description: "Report format", Default: "json"},
				{Name: "-r", Description: "Report output file"},
				{Name: "--redact", Description: "Redact secrets in output (smart-mode)"},
				{Name: "--no-banner", Description: "Suppress banner"},
			},
			Tags: []string{"secrets", "recon", "passive"},
		},

		// ─────────────── PHASE 2: ENUMERATION ───────────────
		// httpx smart-mode — see executor.go:242 for the actual command.
		// One-pass probe: title + tech-detect + status-code + content-length + response-time + JSON.
		// Rate 150 + 50 threads + 10s timeout: aggressive enough for fast probes,
		// gentle enough not to set off most WAFs. JSON output feeds nuclei tech-aware logic.
		{
			ID: "httpx", Name: "httpx", Phase: PhaseEnum, Category: "http",
			Description: "Fast multi-purpose HTTP toolkit — probe, tech-detect, screenshot",
			InstallCmd:  "go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest",
			BinaryPath:  "httpx", ROI: ROICritical, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-l", Description: "Input file"},
				{Name: "-title", Description: "Page titles (smart-mode)"},
				{Name: "-tech-detect", Description: "Tech detection (smart-mode)"},
				{Name: "-status-code", Description: "Status codes"},
				{Name: "-content-length", Description: "Content length"},
				{Name: "-response-time", Description: "Response time"},
				{Name: "-json", Description: "JSON output (feeds nuclei tech-aware logic)"},
				{Name: "-silent", Description: "Silent (no banner)"},
				{Name: "-rate-limit", Description: "Requests/sec per host", Default: "150"},
				{Name: "-threads", Description: "Worker threads", Default: "50"},
				{Name: "-timeout", Description: "Per-request timeout (seconds)", Default: "10"},
			},
			Tags: []string{"http", "probe", "active"},
		},
		{
			ID: "naabu", Name: "naabu", Phase: PhaseEnum, Category: "ports",
			Description: "Fast port scanner — SYN scan, optimized for bug bounty scale",
			InstallCmd:  "go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",
			BinaryPath:  "naabu", ROI: ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-l", Description: "Input file"},
				{Name: "-p", Description: "Ports", Default: "80,443,8080,8443,8888"},
				{Name: "-rate", Description: "Rate limit", Default: "1000"},
				{Name: "-json", Description: "JSON output"},
			},
			Tags: []string{"ports", "active", "scan"},
		},
		{
			// DEPRECATED — upstream michenriksen/aquatone archived 2018.
			// gowitness (sensepost) is the actively-maintained equivalent.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "aquatone", Name: "aquatone", Phase: PhaseEnum, Category: "screenshot",
			Description: "Visual website inspection — DEPRECATED (upstream archived 2018), use gowitness instead",
			InstallCmd:  "go install github.com/michenriksen/aquatone@latest",
			BinaryPath:  "aquatone", ROI: ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-threads", Description: "Threads", Default: "5"},
				{Name: "-timeout", Description: "Timeout ms", Default: "30000"},
				{Name: "-out", Description: "Output dir"},
			},
			Tags: []string{"screenshot", "visual", "enum", "deprecated"},
		},
		{
			ID: "hakrawler", Name: "hakrawler", Phase: PhaseEnum, Category: "crawl",
			Description: "Web crawler — extracts endpoints, JS files, forms",
			InstallCmd:  "go install github.com/hakluke/hakrawler@latest",
			BinaryPath:  "hakrawler", ROI: ROIHigh, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-depth", Description: "Crawl depth", Default: "3"},
				{Name: "-subs", Description: "Include subdomains"},
				{Name: "-js", Description: "Extract JS files"},
				{Name: "-forms", Description: "Extract forms"},
			},
			Tags: []string{"crawl", "enum", "js"},
		},
		{
			ID: "gospider", Name: "gospider", Phase: PhaseEnum, Category: "crawl",
			Description: "Fast web spider — JS parser + sitemap + robots.txt",
			InstallCmd:  "go install github.com/jaeles-project/gospider@latest",
			BinaryPath:  "gospider", ROI: ROIHigh, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-s", Description: "Site URL"},
				{Name: "-t", Description: "Threads", Default: "5"},
				{Name: "-c", Description: "Concurrent", Default: "5"},
				{Name: "--json", Description: "JSON output"},
			},
			Tags: []string{"crawl", "spider", "enum"},
		},
		{
			ID: "gf", Name: "gf", Phase: PhaseEnum, Category: "pattern",
			Description: "Grep patterns for interesting parameters — XSS, SQLi, SSRF, etc.",
			InstallCmd:  "go install github.com/tomnomnom/gf@latest && git clone https://github.com/1ndianl33t/Gf-Patterns ~/.gf",
			BinaryPath:  "gf", ROI: ROICritical, Parallel: true, Timeout: 30,
			Flags: []Flag{
				{Name: "xss|sqli|ssrf|redirect|rce|idor", Description: "Pattern name", Required: true},
			},
			Tags: []string{"pattern", "filter", "enum"},
		},

		// ─────────────── PHASE 3: SCANNING ───────────────
		// nuclei smart-mode — see executor.go:411 for the actual tech-aware command.
		// The executor parses httpx JSON tech-detect → derives template tags → runs
		// only relevant CVE/exposure/misconfig templates (NOT all 9000+).
		// Excludes dos,intrusive: bug bounty Rules of Engagement usually forbid these.
		// Severity filter cuts info/low noise; only medium+ findings reach triage.
		{
			ID: "nuclei", Name: "nuclei", Phase: PhaseScan, Category: "vuln",
			Description: "AI-assisted vulnerability scanner — 9000+ templates",
			InstallCmd:  "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
			BinaryPath:  "nuclei", ROI: ROICritical, Parallel: true, Timeout: 600,
			Flags: []Flag{
				{Name: "-l", Description: "Targets list"},
				{Name: "-tags", Description: "Tag filter (tech-aware, set dynamically)", Default: "cve,exposure,misconfiguration,takeover,default-login"},
				{Name: "-exclude-tags", Description: "Block dangerous tags", Default: "dos,intrusive"},
				{Name: "-severity", Description: "Severity filter (cuts info/low noise)", Default: "medium,high,critical"},
				{Name: "-rate-limit", Description: "Requests/sec global", Default: "50"},
				{Name: "-bulk-size", Description: "Hosts per template batch", Default: "25"},
				{Name: "-concurrency", Description: "Concurrent templates", Default: "10"},
				{Name: "-timeout", Description: "Per-request timeout (seconds)", Default: "10"},
				{Name: "-retries", Description: "Retries on failure", Default: "1"},
				{Name: "-silent", Description: "Suppress progress"},
				{Name: "-json-export", Description: "JSON export file (parsed by ParseNucleiOutput)"},
			},
			Tags: []string{"vuln", "scan", "templates"},
		},
		{
			ID: "nikto", Name: "nikto", Phase: PhaseScan, Category: "web",
			Description: "Enhanced web server scanner — misconfigs, outdated software",
			InstallCmd:  "apt install nikto -y",
			BinaryPath:  "nikto", ROI: ROIMedium, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-h", Description: "Target host", Required: true},
				{Name: "-Format", Description: "Output format", Default: "json"},
				{Name: "-Tuning", Description: "Scan tuning", Default: "x6"},
				{Name: "-maxtime", Description: "Max scan time", Default: "300s"},
			},
			Tags: []string{"web", "scan", "misconfig"},
		},
		// ffuf smart-mode — see executor.go:472 for the actual command.
		// -mc covers all interesting redirect/auth codes; -fc 404 hides the noise;
		// -se ("stop on errors") + -recursion-depth 2 finds dirs and their children
		// without runaway recursion. Rate 100 is a defensible bug-bounty default.
		{
			ID: "ffuf", Name: "ffuf", Phase: PhaseScan, Category: "fuzz",
			Description: "Fast web fuzzer — directory/file discovery, parameter bruteforce",
			InstallCmd:  "go install github.com/ffuf/ffuf/v2@latest",
			BinaryPath:  "ffuf", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL with FUZZ marker", Required: true},
				{Name: "-w", Description: "Wordlist", Default: "/opt/wordlists/raft-medium.txt"},
				{Name: "-mc", Description: "Match interesting codes", Default: "200,201,204,301,302,307,401,403,405"},
				{Name: "-fc", Description: "Filter noise codes", Default: "404"},
				{Name: "-rate", Description: "Requests/sec per host", Default: "100"},
				{Name: "-timeout", Description: "Per-request timeout (seconds)", Default: "10"},
				{Name: "-recursion", Description: "Recurse into found dirs"},
				{Name: "-recursion-depth", Description: "Max recursion depth", Default: "2"},
				{Name: "-se", Description: "Stop on errors"},
				{Name: "-json", Description: "JSON output"},
			},
			Tags: []string{"fuzz", "discovery", "scan"},
		},
		{
			// DEPRECATED — wfuzz upstream is maintenance-only since 2020.
			// ffuf (active) + ffuf-custom (custom wordlist from discovered URLs) cover the same use cases.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "wfuzz", Name: "wfuzz", Phase: PhaseScan, Category: "fuzz",
			Description: "Web fuzzer — DEPRECATED (upstream maintenance-only), use ffuf + ffuf-custom instead",
			InstallCmd:  "pip install wfuzz",
			BinaryPath:  "wfuzz", ROI: ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-w", Description: "Wordlist", Required: true},
				{Name: "--hc", Description: "Hide codes", Default: "404"},
				{Name: "-t", Description: "Threads", Default: "50"},
			},
			Tags: []string{"fuzz", "web", "scan", "deprecated"},
		},
		{
			// DEPRECATED — nomore403 (Go, active) and byp4xx (Go, active) cover the same surface.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "403fuzzer", Name: "403fuzzer", Phase: PhaseScan, Category: "bypass",
			Description: "403 Forbidden bypass fuzzer — DEPRECATED, use nomore403 or byp4xx instead",
			InstallCmd:  "git clone https://github.com/yunemse48/403fuzzer /opt/403fuzzer && pip install -r /opt/403fuzzer/requirements.txt",
			BinaryPath:  "python3", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-t", Description: "Threads", Default: "10"},
			},
			Tags: []string{"bypass", "403", "scan", "deprecated"},
		},
		{
			ID: "nomore403", Name: "nomore403", Phase: PhaseScan, Category: "bypass",
			Description: "Advanced 403/401 bypass — headers, methods, path variants",
			InstallCmd:  "go install github.com/devploit/nomore403@latest",
			BinaryPath:  "nomore403", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "--url", Description: "Target URL", Required: true},
				{Name: "--verbose", Description: "Verbose output"},
			},
			Tags: []string{"bypass", "403", "scan"},
		},
		{
			ID: "graphw00f", Name: "graphw00f", Phase: PhaseScan, Category: "graphql",
			Description: "GraphQL engine fingerprinting — identify backend implementation",
			InstallCmd:  "pip install graphw00f",
			BinaryPath:  "graphw00f", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{
				{Name: "-t", Description: "Target URL", Required: true},
				{Name: "-d", Description: "Detect mode"},
				{Name: "-f", Description: "Fingerprint"},
			},
			Tags: []string{"graphql", "fingerprint", "scan"},
		},

		// ─────────────── PHASE 4: EXPLOITATION ───────────────
		{
			ID: "commix", Name: "commix", Phase: PhaseExploit, Category: "injection",
			Description: "OS command injection exploiter — automated parameter testing",
			InstallCmd:  "git clone https://github.com/commixproject/commix /opt/commix",
			// BinaryPath kept as bare "python3" so pipeline's `command -v` check
			// succeeds; the executor case at executor.go builds the full
			// `python3 /opt/commix/commix.py ...` command from scratch.
			BinaryPath: "python3", ROI: ROICritical, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "--url", Description: "Target URL", Required: true},
				{Name: "--level", Description: "Test level (1-3)", Default: "2"},
				{Name: "--output-dir", Description: "Output directory"},
			},
			Tags: []string{"rce", "injection", "exploit"},
		},
		{
			// DEPRECATED — covered by native cors-engine (Native: true, runs in-process).
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "corsy", Name: "corsy", Phase: PhaseExploit, Category: "cors",
			Description: "CORS misconfiguration scanner — DEPRECATED, use cors-engine (native Go) instead",
			InstallCmd:  "git clone https://github.com/s0md3v/Corsy /opt/Corsy && pip install -r /opt/Corsy/requirements.txt",
			BinaryPath:  "python3", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-i", Description: "Input file"},
				{Name: "-t", Description: "Threads", Default: "10"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"cors", "exploit", "misconfig", "deprecated"},
		},
		{
			ID: "crlfuzz", Name: "crlfuzz", Phase: PhaseExploit, Category: "injection",
			Description: "CRLF injection scanner — header injection vulnerabilities",
			InstallCmd:  "go install github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest",
			BinaryPath:  "crlfuzz", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-c", Description: "Concurrency", Default: "25"},
				{Name: "-s", Description: "Silent mode"},
			},
			Tags: []string{"crlf", "injection", "exploit"},
		},
		{
			ID: "ssrfmap", Name: "ssrfmap", Phase: PhaseExploit, Category: "ssrf",
			Description: "SSRF detection & exploitation — supports 14 protocols",
			InstallCmd:  "git clone https://github.com/swisskyrepo/SSRFmap /opt/ssrfmap && pip install -r requirements.txt",
			// BinaryPath="python3" — executor builds full `python3 /opt/ssrfmap/...` path.
			BinaryPath: "python3", ROI: ROICritical, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-r", Description: "Request file", Required: true},
				{Name: "-p", Description: "Parameter"},
				{Name: "-m", Description: "Module"},
			},
			Tags: []string{"ssrf", "exploit"},
		},
		{
			ID: "smuggler", Name: "smuggler", Phase: PhaseExploit, Category: "http",
			Description: "HTTP request smuggling detection — CL.TE, TE.CL, TE.TE variants",
			InstallCmd:  "git clone https://github.com/defparam/smuggler /opt/smuggler",
			// BinaryPath="python3" — executor builds full `python3 /opt/smuggler/...` path.
			BinaryPath: "python3", ROI: ROICritical, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-t", Description: "Threads", Default: "5"},
				{Name: "--log", Description: "Log file"},
			},
			Tags: []string{"smuggling", "http", "exploit"},
		},
		{
			ID: "jwt-tool", Name: "jwt-tool", Phase: PhaseExploit, Category: "jwt",
			Description: "JWT attack toolkit — alg confusion, none, cracking, tampering",
			InstallCmd:  "git clone https://github.com/ticarpi/jwt_tool /opt/jwt-tool && pip install -r requirements.txt",
			// BinaryPath="python3" — executor builds full `python3 /opt/jwt-tool/...` path.
			BinaryPath: "python3", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-t", Description: "Target URL"},
				{Name: "-rh", Description: "Request headers"},
				{Name: "-M", Description: "Mode: at,ab,as,ao,ar,au,rs,er,ec,es,eo,ep,eb"},
			},
			Tags: []string{"jwt", "auth", "exploit"},
		},
		{
			// DEPRECATED — upstream stale, modern race-condition testing uses
			// Turbo Intruder or custom Go single-packet attacks.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "race-the-web", Name: "race-the-web", Phase: PhaseExploit, Category: "race",
			Description: "Race condition testing — DEPRECATED (upstream stale), use Turbo Intruder or custom scripts",
			InstallCmd:  "go install github.com/nicowillis/race-the-web@latest",
			BinaryPath:  "race-the-web", ROI: ROIHigh, Parallel: false, Timeout: 120,
			Flags: []Flag{
				{Name: "-config", Description: "Config TOML file", Required: true},
			},
			Tags: []string{"race", "condition", "exploit", "deprecated"},
		},

		// ─────────────── 17 ADDITIONAL TOOLS (reaching 44 total) ────────────

		// RECON (+3)
		{
			ID: "dnsx", Name: "dnsx", Phase: PhaseRecon, Category: "dns",
			Description: "Fast DNS resolver — bulk A/CNAME/MX/TXT record lookup",
			InstallCmd:  "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
			BinaryPath:  "dnsx", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-l", Description: "Domains list"},
				{Name: "-a", Description: "A record"},
				{Name: "-resp", Description: "Print response"},
			},
			Tags: []string{"dns", "resolve", "recon"},
		},
		// katana smart-mode — see executor.go:1402 for the actual command.
		// JS crawling enabled (-jc -jsl) — essential for SPA targets where most
		// endpoints are JS-side. Excludes static asset extensions to keep
		// the URL pool focused on dynamic endpoints.
		{
			ID: "katana", Name: "katana", Phase: PhaseRecon, Category: "crawl",
			Description: "Next-gen crawler — JS parsing, headless, form submission",
			InstallCmd:  "go install github.com/projectdiscovery/katana/cmd/katana@latest",
			BinaryPath:  "katana", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-d", Description: "Crawl depth", Default: "3"},
				{Name: "-jc", Description: "Enable JS crawling (smart-mode)"},
				{Name: "-jsl", Description: "JS lookup — parses linked JS files"},
				{Name: "-ef", Description: "Exclude file extensions", Default: "woff,css,png,svg,jpg,woff2,jpeg,gif"},
				{Name: "-rate-limit", Description: "Requests/sec", Default: "150"},
				{Name: "-timeout", Description: "Per-request timeout (seconds)", Default: "10"},
				{Name: "-silent", Description: "Suppress banner"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"crawl", "js", "headless"},
		},
		{
			ID: "cariddi", Name: "cariddi", Phase: PhaseRecon, Category: "crawl",
			Description: "All-in-one crawler: endpoints + secrets + API keys + juicy files + errors. " +
				"Replaces hakrawler+secretfinder+gf in one pass. Go-based, fast, parallelizable.",
			InstallCmd: "go install github.com/edoardottt/cariddi/cmd/cariddi@latest",
			BinaryPath: "cariddi", ROI: ROICritical, Parallel: true, Timeout: 360,
			Flags: []Flag{
				{Name: "-s", Description: "Hunt for secrets"},
				{Name: "-e", Description: "Hunt for juicy endpoints"},
				{Name: "-err", Description: "Hunt for errors in pages"},
				{Name: "-info", Description: "Hunt for useful info"},
				{Name: "-ext", Description: "Juicy file extensions (1-7)", Default: "2"},
				{Name: "-intensive", Description: "Crawl subdomains too"},
				{Name: "-c", Description: "Concurrency", Default: "20"},
				{Name: "-json", Description: "JSON output"},
				{Name: "-rua", Description: "Random user agent"},
			},
			Tags: []string{"crawl", "secrets", "endpoints", "files", "recon"},
		},
		{
			ID: "trufflehog", Name: "trufflehog", Phase: PhaseRecon, Category: "secrets",
			Description: "Deep secrets scanner — git history, S3, GCS, filesystem",
			InstallCmd:  "go install github.com/trufflesecurity/trufflehog/v3@latest",
			BinaryPath:  "trufflehog", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "git", Description: "Git repo URL"},
				{Name: "--json", Description: "JSON output"},
				{Name: "--only-verified", Description: "Only verified secrets"},
			},
			Tags: []string{"secrets", "git", "recon"},
		},

		// ENUMERATION (+3)
		{
			ID: "waybackurls", Name: "waybackurls", Phase: PhaseEnum, Category: "urls",
			Description: "Fetch all URLs from Wayback Machine for a domain",
			InstallCmd:  "go install github.com/tomnomnom/waybackurls@latest",
			BinaryPath:  "waybackurls", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "", Description: "Domain (stdin or arg)", Required: true},
				{Name: "-dates", Description: "Include fetch dates"},
			},
			Tags: []string{"urls", "wayback", "passive"},
		},
		{
			ID: "subzy", Name: "subzy", Phase: PhaseEnum, Category: "takeover",
			Description: "Subdomain takeover detector — checks CNAME dangling pointers",
			InstallCmd:  "go install github.com/PentestPad/subzy@latest",
			BinaryPath:  "subzy", ROI: ROICritical, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "--targets", Description: "Subdomains file", Required: true},
				{Name: "--concurrency", Description: "Threads", Default: "50"},
				{Name: "--verify-ssl", Description: "Verify SSL"},
			},
			Tags: []string{"takeover", "subdomain", "enum"},
		},
		{
			ID: "gowitness", Name: "gowitness", Phase: PhaseEnum, Category: "screenshot",
			Description: "Web screenshot tool — headless Chrome, generates report",
			InstallCmd:  "go install github.com/sensepost/gowitness@latest",
			BinaryPath:  "gowitness", ROI: ROIMedium, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "file", Description: "Subcommand for file input"},
				{Name: "-f", Description: "URLs file", Required: true},
				{Name: "--screenshot-path", Description: "Output dir"},
			},
			Tags: []string{"screenshot", "enum", "visual"},
		},

		// SCANNING (+5)
		// dalfox smart-mode — runs via `pipe --silence --skip-bav --timeout 10`
		// from the gf-xss output (executor.go:397). NOT executed against full URL list.
		//   --skip-bav    → skip basic-auth-vuln pre-check (faster, fewer false positives)
		//   --silence     → no banner/progress noise
		//   pipe mode     → reads URLs from stdin (composable with gf output)
		{
			ID: "dalfox", Name: "dalfox", Phase: PhaseScan, Category: "xss",
			Description: "Parameter XSS scanner — DOM, reflected, stored, blind",
			InstallCmd:  "go install github.com/hahwul/dalfox/v2@latest",
			BinaryPath:  "dalfox", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "pipe", Description: "Pipe mode — reads URLs from stdin (smart-mode)"},
				{Name: "url", Description: "Subcommand: single URL"},
				{Name: "file", Description: "Subcommand: URL list"},
				{Name: "--skip-bav", Description: "Skip basic-auth-vuln pre-check (less FP, faster)"},
				{Name: "--silence", Description: "Silence mode"},
				{Name: "--timeout", Description: "Per-request timeout (seconds)", Default: "10"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"xss", "param", "scan"},
		},
		// sqlmap smart-mode — see executor.go:1323 for the actual command.
		//   --batch          → never ask for input (CRITICAL — pipeline is non-interactive)
		//   --random-agent   → rotate UA to dodge simple WAF heuristics
		//   --level=2        → enough payloads for most modern apps without 10x runtime of level 5
		//   --risk=2         → safe-ish payloads; risk 3 includes destructive UPDATE/DELETE
		//   --threads=4      → multi-threaded but capped to avoid hammering the target
		//   --timeout=30     → per-request timeout
		// IMPORTANT: sqlmap is Parallel:false because it hammers a single endpoint with many payloads.
		{
			ID: "sqlmap", Name: "sqlmap", Phase: PhaseScan, Category: "sqli",
			Description: "SQL injection detection and exploitation — full DB extraction",
			InstallCmd:  "pip3 install sqlmap",
			BinaryPath:  "sqlmap", ROI: ROICritical, Parallel: false, Timeout: 600,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "--batch", Description: "Never ask for input (smart-mode, required)"},
				{Name: "--random-agent", Description: "Rotate User-Agent (smart-mode)"},
				{Name: "--level", Description: "Test level (1-5)", Default: "2"},
				{Name: "--risk", Description: "Risk level (1-3) — 3 includes destructive payloads", Default: "2"},
				{Name: "--threads", Description: "Concurrent threads per scan", Default: "4"},
				{Name: "--timeout", Description: "Per-request timeout (seconds)", Default: "30"},
				{Name: "--dbs", Description: "Enumerate databases"},
				{Name: "--output-dir", Description: "Output directory (per-scan isolation)"},
			},
			Tags: []string{"sqli", "injection", "scan"},
		},
		{
			// DEPRECATED — repo archived since 2019, last meaningful commit older.
			// SSTI detection is partially covered by nuclei SSTI templates.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "tplmap", Name: "tplmap", Phase: PhaseScan, Category: "ssti",
			Description: "Server-side template injection scanner — DEPRECATED (upstream archived 2019), use nuclei SSTI tags",
			InstallCmd:  "git clone https://github.com/epinna/tplmap /opt/tplmap && pip install -r /opt/tplmap/requirements.txt",
			BinaryPath:  "python3", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-e", Description: "Template engine"},
				{Name: "-d", Description: "POST data"},
			},
			Tags: []string{"ssti", "template", "injection", "deprecated"},
		},
		{
			ID: "arjun", Name: "arjun", Phase: PhaseScan, Category: "params",
			Description: "HTTP parameter discovery — finds hidden GET/POST/JSON params",
			InstallCmd:  "pipx install arjun",
			BinaryPath:  "arjun", ROI: ROIHigh, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-m", Description: "Method (GET/POST)", Default: "GET"},
				{Name: "-o", Description: "Output file"},
				{Name: "--stable", Description: "Reduce request rate"},
			},
			Tags: []string{"params", "discovery", "scan"},
		},
		{
			ID: "feroxbuster", Name: "feroxbuster", Phase: PhaseScan, Category: "fuzz",
			Description: "Fast recursive content discovery — Rust-based, auto-recurse",
			InstallCmd:  "curl -sL https://raw.githubusercontent.com/epi052/feroxbuster/main/install-nix.sh | bash",
			BinaryPath:  "feroxbuster", ROI: ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-w", Description: "Wordlist"},
				{Name: "-t", Description: "Threads", Default: "50"},
				{Name: "--extract-links", Description: "Extract links from responses"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"fuzz", "discovery", "scan"},
		},

		// EXPLOITATION (+6)
		{
			ID: "xsstrike", Name: "xsstrike", Phase: PhaseExploit, Category: "xss",
			Description: "XSStrike — advanced XSS detection with fuzzing and AI",
			InstallCmd:  "git clone https://github.com/s0md3v/XSStrike",
			BinaryPath:  "xsstrike", ROI: ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "--crawl", Description: "Crawl the target"},
				{Name: "--fuzzer", Description: "Enable fuzzer"},
				{Name: "-t", Description: "Threads", Default: "2"},
			},
			Tags: []string{"xss", "exploit", "fuzzing"},
		},
		{
			ID: "linkfinder", Name: "linkfinder", Phase: PhaseExploit, Category: "js",
			Description: "Discover endpoints in JS files — regex-based hidden route extraction",
			InstallCmd:  "git clone https://github.com/GerbenJavado/LinkFinder /opt/LinkFinder && pip install -r /opt/LinkFinder/requirements.txt",
			// BinaryPath="python3" so `command -v` succeeds; the executor case
			// at executor.go:1065 builds `python3 /opt/LinkFinder/linkfinder.py ...`.
			BinaryPath: "python3", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-i", Description: "Input (JS file or URL)", Required: true},
				{Name: "-o", Description: "Output format", Default: "cli"},
				{Name: "-d", Description: "Enable domain crawl"},
			},
			Tags: []string{"js", "endpoints", "recon"},
		},
		{
			ID: "secretfinder", Name: "secretfinder", Phase: PhaseExploit, Category: "secrets",
			Description: "Find API keys, tokens, secrets in JS files",
			InstallCmd:  "git clone https://github.com/m4ll0k/SecretFinder /opt/SecretFinder && pip install -r /opt/SecretFinder/requirements.txt",
			// BinaryPath="python3" so `command -v` succeeds; the executor case
			// at executor.go:1081 builds `python3 /opt/SecretFinder/SecretFinder.py ...`.
			BinaryPath: "python3", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-i", Description: "Input JS file or URL", Required: true},
				{Name: "-o", Description: "Output", Default: "cli"},
			},
			Tags: []string{"secrets", "js", "exploit"},
		},
		{
			ID: "paramspider", Name: "paramspider", Phase: PhaseExploit, Category: "params",
			Description: "Mine parameters from web archives for fuzzing",
			InstallCmd:  "pipx install paramspider",
			BinaryPath:  "paramspider", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
				{Name: "--level", Description: "Param level (high/medium/low)", Default: "high"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"params", "mining", "exploit"},
		},
		{
			ID: "graphql-cop", Name: "graphql-cop", Phase: PhaseExploit, Category: "graphql",
			Description: "GraphQL security audit — introspection, batching, IDOR",
			InstallCmd:  "pip3 install graphql-cop",
			BinaryPath:  "graphql-cop", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-t", Description: "Target GraphQL endpoint", Required: true},
				{Name: "-o", Description: "Output format (json)", Default: "json"},
			},
			Tags: []string{"graphql", "api", "exploit"},
		},
		// ── NucleiFuzzer-style chain (v3.3.4) ─────────────────────────────────
		// Replicates 0xKayala/NucleiFuzzer natively: discovered parameterized URLs
		// → uro (dedup) → httpx (live) → nuclei DAST/fuzzing-templates. We do NOT
		// import the upstream bash script (it would duplicate katana/hakrawler/
		// waybackurls/paramspider/httpx/nuclei we already ship); instead we add the
		// two missing helpers (uro, gau) and a dedicated nuclei fuzzing tool.
		{
			ID: "uro", Name: "uro", Phase: PhaseExploit, Category: "params",
			Description: "Deduplicate & filter URLs for fuzzing — collapses near-identical " +
				"parameterized URLs (same endpoint, different values) so nuclei fuzzing isn't wasted.",
			InstallCmd: "pipx install uro",
			BinaryPath: "uro", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-i", Description: "Input file of URLs"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"params", "dedup", "exploit"},
		},
		{
			ID: "gau", Name: "gau", Phase: PhaseRecon, Category: "urls",
			Description: "getallurls — fetch known URLs from Wayback, Common Crawl, URLScan, OTX. " +
				"Complements waybackurls for broader passive URL coverage.",
			InstallCmd: "go install github.com/lc/gau/v2/cmd/gau@latest",
			BinaryPath: "gau", ROI: ROIHigh, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "--threads", Description: "Concurrency", Default: "5"},
				{Name: "--subs", Description: "Include subdomains"},
			},
			Tags: []string{"urls", "passive", "recon"},
		},
		{
			ID: "nuclei-fuzz", Name: "nuclei-fuzz", Phase: PhaseExploit, Category: "fuzzing",
			Description: "Nuclei in DAST/fuzzing mode (-dast) over discovered parameterized URLs, " +
				"using fuzzing-templates to find reflected XSS, SQLi, SSRF, Open Redirect, " +
				"CMDi via parameter fuzzing. Equivalent to NucleiFuzzer's core scan step. " +
				"Fuzzing templates are excluded by default in nuclei — this tool enables them.",
			InstallCmd: "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
			BinaryPath: "nuclei", ROI: ROICritical, Parallel: false, Timeout: 1800,
			Flags: []Flag{
				{Name: "-dast", Description: "Enable DAST/fuzzing-templates"},
				{Name: "-l", Description: "List of URLs to fuzz", Required: true},
			},
			Tags: []string{"fuzzing", "dast", "xss", "sqli", "ssrf", "exploit"},
		},
		{
			ID: "kiterunner", Name: "kiterunner", Phase: PhaseScan, Category: "api",
			Description: "API route discovery using 20k+ Swagger-derived routes. " +
				"Sends correct HTTP method+params per route. Finds endpoints missed by ffuf.",
			InstallCmd: "go install github.com/assetnote/kiterunner/cmd/kr@latest",
			BinaryPath: "kr", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-A", Description: "Assetnote wordlist alias", Default: "apiroutes-210328:20000"},
				{Name: "-x", Description: "Max connections per host", Default: "5"},
			},
			Tags: []string{"api", "discovery", "routes", "swagger"},
		},
		{
			ID: "vulnapi", Name: "vulnapi", Phase: PhaseScan, Category: "api",
			Description: "OWASP API Top 10 automated DAST scanner. " +
				"Tests BOLA, broken auth, mass assignment, injection, security misconfiguration.",
			InstallCmd: "go install github.com/cerberauth/vulnapi@latest",
			BinaryPath: "vulnapi", ROI: ROIHigh, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "scan curl", Description: "Scan mode for HTTP APIs", Required: true},
			},
			Tags: []string{"api", "owasp", "dast", "auth", "bola"},
		},
		{
			// DEPRECATED — original Flipkart "Astra" REST API tester is Python 2.7
			// and archived. Coverage replaced by vulnapi (OWASP API Top 10),
			// nuclei, and sqlmap chains in the pipeline.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "astra", Name: "Astra", Phase: PhaseScan, Category: "api",
			Description: "REST API security testing — DEPRECATED (upstream archived), covered by vulnapi + nuclei + sqlmap",
			InstallCmd:  "pip3 install astra --break-system-packages",
			BinaryPath:  "astra", ROI: ROIHigh, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-t", Description: "Target URL or OpenAPI spec", Required: true},
				{Name: "-o", Description: "Output file (json)"},
			},
			Tags: []string{"api", "rest", "injection", "openapi", "deprecated"},
		},
		{
			ID: "apifuzzer", Name: "APIFuzzer", Phase: PhaseScan, Category: "api",
			Description: "HTTP API fuzzer from OpenAPI/Swagger specs. " +
				"Generates malicious payloads for injection, boundary value, logic errors.",
			InstallCmd: "pip3 install APIFuzzer --break-system-packages",
			BinaryPath: "APIFuzzer", ROI: ROIMedium, Parallel: false, Timeout: 240,
			Flags: []Flag{
				{Name: "-s", Description: "OpenAPI/Swagger spec URL", Required: true},
				{Name: "--report_dir", Description: "Output directory"},
			},
			Tags: []string{"api", "fuzzing", "openapi", "swagger"},
		},
		{
			ID: "gotestwaf", Name: "gotestwaf", Phase: PhaseScan, Category: "api",
			Description: "WAF bypass testing for APIs by Wallarm. " +
				"Tests if WAF correctly blocks SQL injection, XSS, RCE through API endpoints.",
			InstallCmd: "go install github.com/wallarm/gotestwaf@latest",
			BinaryPath: "gotestwaf", ROI: ROIMedium, Parallel: false, Timeout: 180,
			Flags: []Flag{
				{Name: "--url", Description: "Target URL", Required: true},
				{Name: "--format", Description: "Output format", Default: "json"},
			},
			Tags: []string{"api", "waf", "bypass", "injection"},
		},
		{
			ID: "wpscan", Name: "wpscan", Phase: PhaseExploit, Category: "cms",
			Description: "WordPress vulnerability scanner — plugins, themes, users",
			InstallCmd:  "gem install wpscan",
			BinaryPath:  "wpscan", ROI: ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "--url", Description: "WordPress URL", Required: true},
				{Name: "--api-token", Description: "WPScan API token"},
				{Name: "-e", Description: "Enumerate (p=plugins, u=users)", Default: "p,u"},
				{Name: "--format", Description: "Output format", Default: "json"},
			},
			Tags: []string{"wordpress", "cms", "exploit"},
		},

		// ─────────────── CONDITIONAL TOOLS (injected by smart pipeline) ──────

		// Hydra — injected when naabu/nmap finds open SSH/FTP/MySQL/RDP ports
		{
			ID: "hydra", Name: "hydra", Phase: PhaseExploit, Category: "bruteforce",
			Description: "Network service brute-forcer — SSH, FTP, MySQL, RDP, Telnet (conditional inject)",
			InstallCmd:  "apt install hydra -y",
			BinaryPath:  "hydra", ROI: ROIHigh, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-l", Description: "Username or file"},
				{Name: "-P", Description: "Password list", Default: "/opt/wordlists/passwords.txt"},
				{Name: "-t", Description: "Tasks (threads)", Default: "4"},
				{Name: "-s", Description: "Port"},
				{Name: "ssh|ftp|mysql|rdp|telnet", Description: "Service protocol", Required: true},
			},
			Tags: []string{"bruteforce", "credentials", "conditional"},
		},

		// ZAP — DEPRECATED for headless orchestrator use.
		// OWASP ZAP is GUI-first; its daemon mode is heavy (Java + 1-2GB RAM)
		// and slow compared to nuclei + vigolium + ffuf for our coverage needs.
		// Kept registered for backwards compat; installer does NOT install it.
		{
			ID: "zap", Name: "zap", Phase: PhaseScan, Category: "webapp",
			Description: "OWASP ZAP active scan — DEPRECATED for headless use (GUI-first, heavy); covered by nuclei + vigolium",
			InstallCmd:  "apt install zaproxy -y",
			BinaryPath:  "zap.sh", ROI: ROIHigh, Parallel: false, Timeout: 600,
			Flags: []Flag{
				{Name: "-t", Description: "Target URL", Required: true},
				{Name: "-r", Description: "Report HTML output"},
				{Name: "-j", Description: "JSON report"},
				{Name: "-l", Description: "Alert level", Default: "Medium"},
			},
			Tags: []string{"webapp", "active", "owasp", "conditional", "deprecated"},
		},

		// ═══════════════════════════════════════════════════════════════════════
		// RECONFTW HYBRID INTEGRATION
		// reconFTW runs as a unified tool (opțiunea C — hybrid):
		//   1. reconftw tool     → full reconFTW pipeline (battle-tested, ~30 min)
		//   2. Individual tools  → granular orchestration + conditional chaining
		// Output files from reconFTW feed directly into the pipeline's
		// conditional chaining via analyzeOutputs().
		// ═══════════════════════════════════════════════════════════════════════

		// ── reconFTW as unified orchestrator tool ─────────────────────────────
		{
			ID: "reconftw", Name: "reconftw", Phase: PhaseRecon, Category: "framework",
			Description: "Full reconFTW pipeline — 80+ tools, incremental mode, hotlist scoring, asset store JSONL",
			InstallCmd:  "git clone https://github.com/six2dez/reconftw && cd reconftw && ./install.sh",
			BinaryPath:  "reconftw", ROI: ROICritical, Parallel: false, Timeout: 7200,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
				{Name: "-r", Description: "Full recon (all modules)"},
				{Name: "-s", Description: "Sub-recon (subdomains only)"},
				{Name: "-p", Description: "Passive recon only"},
				{Name: "--deep", Description: "Deep recon (brute + permutations)"},
				{Name: "--quick-rescan", Description: "Skip heavy stages if no new assets"},
				{Name: "-o", Description: "Output directory"},
			},
			Tags: []string{"framework", "recon", "reconftw", "unified"},
		},

		// ── OSINT & Email (from reconFTW) ─────────────────────────────────────
		{
			ID: "emailfinder", Name: "emailfinder", Phase: PhaseRecon, Category: "osint",
			Description: "Find emails for a domain via multiple sources (reconFTW)",
			InstallCmd:  "pip3 install emailfinder",
			BinaryPath:  "emailfinder", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"osint", "email", "reconftw"},
		},
		{
			ID: "msftrecon", Name: "msftrecon", Phase: PhaseRecon, Category: "cloud",
			Description: "Microsoft 365 & Azure tenant mapping (reconFTW)",
			InstallCmd:  "pip3 install msftrecon",
			BinaryPath:  "msftrecon", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
			},
			Tags: []string{"cloud", "azure", "m365", "reconftw"},
		},
		{
			ID: "metagoofil", Name: "metagoofil", Phase: PhaseRecon, Category: "osint",
			Description: "Extract metadata from public documents (PDF, DOCX, XLSX)",
			InstallCmd:  "pip3 install metagoofil",
			BinaryPath:  "metagoofil", ROI: ROIMedium, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
				{Name: "-t", Description: "File types", Default: "pdf,doc,xls"},
				{Name: "-o", Description: "Output dir"},
			},
			Tags: []string{"osint", "metadata", "reconftw"},
		},

		// ── DNS & Subdomain (from reconFTW) ───────────────────────────────────
		{
			ID: "alterx", Name: "alterx", Phase: PhaseRecon, Category: "dns",
			Description: "Fast subdomain permutation engine — DNS wordlist generator",
			InstallCmd:  "go install github.com/projectdiscovery/alterx/cmd/alterx@latest",
			BinaryPath:  "alterx", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-l", Description: "Subdomains list", Required: true},
				{Name: "-p", Description: "Permutation patterns"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"dns", "permutation", "reconftw"},
		},
		{
			// DEPRECATED — coverage delivered by puredns (which already validates
			// resolvers as part of its workflow). executor_integration_test.go
			// already marks this as `// covered by puredns`.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "dnsvalidator", Name: "dnsvalidator", Phase: PhaseRecon, Category: "dns",
			Description: "Validate DNS resolvers — DEPRECATED (covered by puredns wildcard-tests workflow)",
			InstallCmd:  "pip3 install dnsvalidator",
			BinaryPath:  "dnsvalidator", ROI: ROIMedium, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-tL", Description: "Resolver list"},
				{Name: "-threads", Description: "Threads", Default: "200"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"dns", "resolver", "reconftw", "deprecated"},
		},
		{
			ID: "chaos-client", Name: "chaos-client", Phase: PhaseRecon, Category: "subdomain",
			Description: "ProjectDiscovery Chaos — passive subdomain from chaos dataset",
			InstallCmd:  "go install github.com/projectdiscovery/chaos-client/cmd/chaos@latest",
			BinaryPath:  "chaos", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
				{Name: "-key", Description: "Chaos API key"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"subdomain", "passive", "reconftw"},
		},

		// ── API & Secrets (from reconFTW) ─────────────────────────────────────
		{
			ID: "porch-pirate", Name: "porch-pirate", Phase: PhaseRecon, Category: "api",
			Description: "Mine Postman collections for secrets and API endpoints",
			InstallCmd:  "pip3 install porch-pirate",
			BinaryPath:  "porch-pirate", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-s", Description: "Search term (domain)", Required: true},
				{Name: "--dump", Description: "Dump all collections"},
			},
			Tags: []string{"api", "secrets", "postman", "reconftw"},
		},
		{
			ID: "swaggerspy", Name: "swaggerspy", Phase: PhaseRecon, Category: "api",
			Description: "Detect exposed Swagger/OpenAPI endpoints",
			InstallCmd:  "pip3 install swaggerspy",
			BinaryPath:  "swaggerspy", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
			},
			Tags: []string{"api", "swagger", "openapi", "reconftw"},
		},
		{
			ID: "leaksearch", Name: "leaksearch", Phase: PhaseRecon, Category: "secrets",
			Description: "Search for leaked credentials on paste sites & breach DBs",
			InstallCmd:  "pip3 install LeakSearch",
			BinaryPath:  "leaksearch", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-q", Description: "Query (email/domain)", Required: true},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"secrets", "leaks", "credentials", "reconftw"},
		},

		// ── URL & Parameter (from reconFTW) ───────────────────────────────────
		{
			// freq does NOT require a binary — the executor case at executor.go:1129
			// implements the URL-frequency algorithm using inline shell
			// (cat | grep | sort | uniq -c | sort -rn). Empty BinaryPath bypasses
			// the `command -v` check in pipeline.go; empty InstallCmd signals
			// the installer to skip it.
			ID: "freq", Name: "freq", Phase: PhaseEnum, Category: "urls",
			Description: "URL frequency analysis — inline shell pipeline (no binary required)",
			InstallCmd:  "",
			BinaryPath:  "", ROI: ROIMedium, Parallel: true, Timeout: 60,
			Flags: []Flag{
				{Name: "-i", Description: "Input URL list"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"urls", "analysis", "reconftw", "inline"},
		},
		{
			ID: "kxss", Name: "kxss", Phase: PhaseEnum, Category: "xss",
			Description: "Find parameters reflecting special XSS characters",
			InstallCmd:  "go install github.com/Emoe/kxss@latest",
			BinaryPath:  "kxss", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-i", Description: "URL list (stdin)", Required: true},
			},
			Tags: []string{"xss", "params", "enum", "reconftw"},
		},
		{
			ID: "ppmap", Name: "ppmap", Phase: PhaseEnum, Category: "javascript",
			Description: "Prototype pollution parameter scanner",
			InstallCmd:  "go install github.com/kleiton0x00/ppmap@latest",
			BinaryPath:  "ppmap", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
			},
			Tags: []string{"javascript", "prototype-pollution", "reconftw"},
		},

		// ── Scanning (from reconFTW) ───────────────────────────────────────────
		{
			ID: "ghauri", Name: "ghauri", Phase: PhaseScan, Category: "sqli",
			Description: "Advanced SQL injection tool — alternative to sqlmap, faster on modern targets",
			InstallCmd:  "pip3 install ghauri",
			BinaryPath:  "ghauri", ROI: ROICritical, Parallel: false, Timeout: 600,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "--batch", Description: "Never ask for input"},
				{Name: "--level", Description: "Test level", Default: "3"},
				{Name: "--dbs", Description: "Enumerate databases"},
			},
			Tags: []string{"sqli", "injection", "reconftw"},
		},
		{
			ID: "mantra", Name: "mantra", Phase: PhaseScan, Category: "secrets",
			Description: "Find secrets in JS files and responses on the fly",
			InstallCmd:  "go install github.com/MrEmpy/mantra@latest",
			BinaryPath:  "mantra", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-s", Description: "Silent mode"},
			},
			Tags: []string{"secrets", "js", "scan", "reconftw"},
		},
		{
			// DEPRECATED — osmedeus is itself a full orchestration framework with its
			// own workflows, DB, and 50+ tools. Running it inside our orchestrator
			// duplicates the orchestrator's job and steals control. If you want
			// osmedeus, run it directly; do not embed it.
			// Kept registered for backwards compat; installer does NOT install it.
			ID: "osmedeus", Name: "osmedeus", Phase: PhaseScan, Category: "framework",
			Description: "Modern orchestration engine — DEPRECATED for embedded use (it's a competing orchestrator)",
			InstallCmd:  "go install github.com/j3ssie/osmedeus@latest",
			BinaryPath:  "osmedeus", ROI: ROICritical, Parallel: false, Timeout: 3600,
			Flags: []Flag{
				{Name: "scan", Description: "Scan subcommand"},
				{Name: "-t", Description: "Target domain", Required: true},
				{Name: "-w", Description: "Workflow", Default: "general"},
				{Name: "--json", Description: "JSON output"},
			},
			Tags: []string{"framework", "orchestration", "scan", "reconftw", "deprecated"},
		},

		// ── Exploitation (from reconFTW) ──────────────────────────────────────
		{
			ID: "openredirex", Name: "openredirex", Phase: PhaseExploit, Category: "redirect",
			Description: "Open redirect scanner — async, fast, pattern-based",
			InstallCmd:  "pip3 install openredirex",
			BinaryPath:  "openredirex", ROI: ROIMedium, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-l", Description: "URL list", Required: true},
				{Name: "-p", Description: "Payloads file"},
			},
			Tags: []string{"redirect", "exploit", "reconftw"},
		},
		{
			ID: "byp4xx", Name: "byp4xx", Phase: PhaseExploit, Category: "bypass",
			Description: "Bypass 4xx errors with various techniques — headers, path manipulation",
			InstallCmd:  "go install github.com/lobuhi/byp4xx@latest",
			BinaryPath:  "byp4xx", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "", Description: "Target URL (positional)", Required: true},
			},
			Tags: []string{"bypass", "403", "exploit", "reconftw"},
		},
		{
			ID: "nuclei-ai", Name: "nuclei-ai", Phase: PhaseExploit, Category: "ai",
			Description: "Nuclei with AI-powered template generation for novel vulnerabilities",
			InstallCmd:  "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
			BinaryPath:  "nuclei", ROI: ROICritical, Parallel: true, Timeout: 600,
			Flags: []Flag{
				{Name: "-l", Description: "URL list", Required: true},
				{Name: "-ai", Description: "Enable AI template generation"},
				{Name: "-severity", Description: "Severity filter", Default: "critical,high"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"ai", "nuclei", "templates", "reconftw"},
		},

		// ── BBounty Live Agent (Python ultra_agent.py) ────────────────────────
		// Spawned automatically by the pipeline when SCAN_ID is set.
		// Runs 10 live bug bounty modules in parallel (Phase 1) + sequential (Phase 2).
		// Findings are POSTed back to the orchestrator via orchestrator_client.py.
		//
		// FIX: InstallCmd previously referenced
		//   apps/agents/specialist_agents/requirements.txt — that file does NOT exist.
		// The agent's actual dependencies live in apps/agents/python_runtime/requirements.txt.
		// Use --break-system-packages so it works on Ubuntu 23+ / 24+ where pip is PEP-668 locked.
		{
			ID: "bbounty-agent", Name: "bbounty-agent", Phase: PhaseRecon, Category: "agent",
			Description: "BBounty Live Agent — 10 parallel bug bounty modules, AI triage, auto-POST findings",
			InstallCmd:  "pip3 install -r apps/agents/python_runtime/requirements.txt --break-system-packages",
			BinaryPath:  "python3",
			ROI:         ROICritical, Parallel: false, Timeout: 1800,
			Flags: []Flag{
				{Name: "apps/agents/specialist_agents/ultra_agent.py", Description: "Agent script path", Required: true},
				{Name: "--target", Description: "Target domain (auto-injected from BBOUNTY_TARGET env)"},
				{Name: "--mode", Description: "Scan mode", Default: "full"},
				{Name: "--scope", Description: "Scope (auto-injected from scan request)"},
			},
			Tags: []string{"agent", "python", "parallel", "ai", "live"},
		},

		// ═══════════════════════════════════════════════════════════════════════
		// NEW TOOLS — 2025 additions (interactsh, notify, afrog, bountyplz)
		// ═══════════════════════════════════════════════════════════════════════

		// interactsh — OOB (Out-of-Band) interaction server for blind vulns
		// Detects blind SSRF, blind XSS, XXE, SSTI that return nothing visible.
		// Without interactsh these vulnerabilities are completely missed.
		{
			ID: "interactsh", Name: "interactsh", Phase: PhaseRecon, Category: "oob",
			Description: "OOB interaction server — detects blind SSRF, blind XSS, XXE, SSTI (ProjectDiscovery)",
			InstallCmd:  "go install github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest",
			BinaryPath:  "interactsh-client", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-server", Description: "Interactsh server (default: oast.pro)", Default: "oast.pro"},
				{Name: "-token", Description: "API token for private server"},
				{Name: "-json", Description: "JSON output"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"oob", "ssrf", "blind", "interactsh", "projectdiscovery"},
		},

		// notify — Stream findings to Telegram/Slack/Discord/Teams in real-time
		{
			ID: "notify", Name: "notify", Phase: PhaseExploit, Category: "notification",
			Description: "Stream critical findings to Telegram/Slack/Discord (ProjectDiscovery)",
			InstallCmd:  "go install github.com/projectdiscovery/notify/cmd/notify@latest",
			BinaryPath:  "notify", ROI: ROIHigh, Parallel: true, Timeout: 30,
			Flags: []Flag{
				{Name: "-provider-config", Description: "Provider config file (~/.config/notify/provider-config.yaml)"},
				{Name: "-bulk", Description: "Send in bulk"},
				{Name: "-char-limit", Description: "Character limit per message", Default: "4096"},
			},
			Tags: []string{"notification", "telegram", "slack", "discord", "notify"},
		},

		// afrog — Fast vulnerability scanner, complements nuclei (different coverage)
		{
			ID: "afrog", Name: "afrog", Phase: PhaseScan, Category: "vuln",
			Description: "Fast vuln scanner — 4.3k stars, different CVE coverage than nuclei (complement)",
			InstallCmd:  "go install github.com/zan8in/afrog/v3/cmd/afrog@latest",
			BinaryPath:  "afrog", ROI: ROICritical, Parallel: true, Timeout: 600,
			Flags: []Flag{
				{Name: "-t", Description: "Target URL", Required: true},
				{Name: "-s", Description: "Severity filter", Default: "critical,high,medium"},
				{Name: "-json", Description: "JSON output"},
				{Name: "-o", Description: "Output file"},
				{Name: "--silent", Description: "Silent mode"},
			},
			Tags: []string{"vuln", "scanner", "afrog", "cve"},
		},

		// bountyplz — Auto-submit reports to HackerOne/Bugcrowd from Markdown
		{
			ID: "bountyplz", Name: "bountyplz", Phase: PhaseExploit, Category: "reporting",
			Description: "Auto-submit bug bounty reports to HackerOne/Bugcrowd from Markdown templates",
			InstallCmd:  "pip3 install bountyplz",
			BinaryPath:  "bountyplz", ROI: ROIHigh, Parallel: false, Timeout: 120,
			Flags: []Flag{
				{Name: "hackerone", Description: "Submit to HackerOne"},
				{Name: "bugcrowd", Description: "Submit to Bugcrowd"},
				{Name: "-t", Description: "Report template (Markdown file)", Required: true},
				{Name: "--dry-run", Description: "Preview without submitting"},
			},
			Tags: []string{"reporting", "hackerone", "bugcrowd", "submit", "bountyplz"},
		},

		// ── CORS Engine (native Go — no subprocess) ───────────────────────────
		{
			ID: "cors-engine", Name: "cors-engine", Phase: PhaseScan, Category: "cors",
			Description: "Native Go CORS engine — 7 vectors: origin reflection, null, subdomain spoof, HTTP downgrade, preflight bypass",
			InstallCmd:  "",
			BinaryPath:  "cors-engine",
			ROI:         ROICritical, Parallel: true, Timeout: 120,
			Native: true, // runs as Go function, not subprocess
			Tags:   []string{"cors", "native", "go", "origin", "credentials"},
		},

		// ── Vhost fuzzing (ffuf Host header mode) ─────────────────────────────
		{
			ID: "ffuf-vhost", Name: "ffuf-vhost", Phase: PhaseScan, Category: "fuzzing",
			Description: "Virtual host discovery via ffuf Host header fuzzing — finds hidden vhosts",
			InstallCmd:  "go install github.com/ffuf/ffuf/v2@latest",
			BinaryPath:  "ffuf",
			ROI:         ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-H", Description: "Host header with FUZZ", Default: "Host: FUZZ"},
				{Name: "-w", Description: "Wordlist", Default: "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"},
				{Name: "-mc", Description: "Match codes", Default: "200,301,302,403"},
				{Name: "-t", Description: "Threads", Default: "40"},
				{Name: "-json", Description: "JSON output"},
				{Name: "-silent", Description: "Silent"},
			},
			Tags: []string{"vhost", "ffuf", "fuzzing", "host-header", "virtual-host"},
		},
		{
			// SCOPE-F: Vigolium — high-fidelity web vulnerability scanner (AGPL-3.0).
			// Native scan only — do NOT expose agent/swarm/autopilot modes in the pipeline;
			// those run unsandboxed (full shell + network access) per vigolium's SECURITY.md.
			// Uses --format jsonl for structured output parsed by ParseVigoliumOutput.
			// License note: AGPL-3.0 — BBounty Pro does not distribute vigolium binaries;
			// it invokes the tool as a subprocess. Legal review recommended before SaaS deploy.
			ID: "vigolium", Name: "vigolium", Phase: PhaseScan, Category: "dast",
			Description: "High-fidelity DAST scanner (j3ssie) — 251 modules (154 active + 97 passive) " +
				"covering OWASP Top 10, injection, IDOR/BOLA, OAST blind detection, SPA/browser crawl, " +
				"value-aware mutation, API fuzzing. NATIVE scan only (agentic modes excluded — " +
				"they run unsandboxed LLM with host shell access). AGPL-3.0: run as external binary only.",
			// Install: npm global. Alternativ: curl install.sh sau go install (vezi README).
			// npm e cel mai simplu pe un VPS care are deja Node (instalat de install-ubuntu.sh).
			// T7 (SF-3): PINNED to a fixed version (was floating @latest → supply-chain risk:
			// an attacker who compromises the package could push malicious code that gets
			// auto-installed). Bump this string deliberately after reviewing each release.
			// Latest published at pin time (2026-05-28): 0.1.16-beta.
			InstallCmd: "npm install -g @vigolium/vigolium@0.1.16-beta",
			BinaryPath: "vigolium", ROI: ROICritical, Parallel: false, Timeout: 1200,
			Flags: []Flag{
				{Name: "scan", Description: "Native deterministic scan mode (NOT agent/swarm)"},
				{Name: "-t", Description: "Target URL", Required: true},
				{Name: "--strategy", Description: "Scan depth: lite/balanced/deep (smart-mode: deep)", Default: "deep"},
				{Name: "--format", Description: "Output format (jsonl for parser)", Default: "jsonl"},
				{Name: "--silent", Description: "Suppress progress output"},
				{Name: "--rate-limit", Description: "Max requests/sec", Default: "30"},
				{Name: "--concurrency", Description: "Global worker pool (default 50 — we cap at 10)", Default: "10"},
				{Name: "--max-per-host", Description: "Per-host concurrency cap", Default: "2"},
				{Name: "--timeout", Description: "HTTP request timeout", Default: "15s"},
			},
			Tags: []string{"dast", "web", "owasp", "injection", "xss", "sqli", "ssrf", "idor", "api", "oast", "agpl"},
		},
	}

	// Tools that are kept registered for backwards compat but DISABLED by default.
	// Rationale per tool is documented in the tool's struct comment AND in
	// ORCHESTRATOR_TOOL_INTEGRATION.md at the repo root. Operators can re-enable
	// any of these manually after weighing the trade-off documented there.
	deprecated := map[string]bool{
		"aquatone":     true, // upstream archived 2018 — use gowitness
		"403fuzzer":    true, // nomore403 + byp4xx cover this surface
		"astra":        true, // Flipkart project archived — vulnapi + nuclei + sqlmap chain replaces
		"corsy":        true, // cors-engine (native Go) covers CORS misconfigs in-process
		"dnsvalidator": true, // covered by puredns wildcard-tests workflow
		"osmedeus":     true, // it's a competing orchestrator — duplicates our role
		"race-the-web": true, // upstream stale — use Turbo Intruder / custom scripts
		"tplmap":       true, // upstream archived 2019 — use nuclei SSTI tags
		"wfuzz":        true, // upstream maintenance-only — use ffuf + ffuf-custom
		"zap":          true, // GUI-first, heavy daemon — nuclei + vigolium cover surface
	}

	for _, t := range tools {
		t.Enabled = true
		// AGPL NOTE (vigolium): rulat ca BINAR EXTERN nemodificat via CLI
		// (subprocess în executor.go), NU ca import de cod. Conform aprobării
		// scrise de la Jessie Ho (creatorul Vigolium, email 2026-05-28):
		// uz SaaS cu Vigolium NEMODIFICAT = fără licență comercială, doar
		// atribuire prin link la sursa publică (vezi THIRD_PARTY_LICENSES.md).
		// De aceea vigolium NU mai e gated aici — e activ ca orice alt tool.
		// IMPORTANT: dacă vreodată MODIFICI codul Vigolium, AGPL cere să oferi
		// sursa modificată end-userilor SaaS — atunci ai nevoie de licență
		// comercială de la Jessie. Cât timp e nemodificat, ești în clar.
		// Deprecated tools: kept registered, but disabled — pipeline won't pick
		// them in filterTools() and the installer skips them.
		if deprecated[t.ID] {
			t.Enabled = false
		}
		r.tools[t.ID] = t
	}
}

func (r *Registry) Get(id string) (*Tool, bool) {
	t, ok := r.tools[id]
	return t, ok
}

func (r *Registry) All() []*Tool {
	tools := make([]*Tool, 0, len(r.tools))
	for _, t := range r.tools {
		tools = append(tools, t)
	}
	sort.Slice(tools, func(i, j int) bool {
		return tools[i].Phase < tools[j].Phase
	})
	return tools
}

func (r *Registry) ByPhase(phase string) []*Tool {
	var result []*Tool
	for _, t := range r.tools {
		if t.Phase == phase {
			result = append(result, t)
		}
	}
	return result
}

func (r *Registry) HandleList(w http.ResponseWriter, req *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(r.All())
}

func (r *Registry) HandleInfo(w http.ResponseWriter, req *http.Request) {
	id := chi.URLParam(req, "toolID")
	t, ok := r.Get(id)
	if !ok {
		http.Error(w, `{"error":"tool not found"}`, http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(t)
}

func (r *Registry) HandleRunSingle(w http.ResponseWriter, req *http.Request) {
	// Single tool run — delegates to executor
	w.WriteHeader(http.StatusAccepted)
	w.Write([]byte(`{"status":"queued"}`))
}
