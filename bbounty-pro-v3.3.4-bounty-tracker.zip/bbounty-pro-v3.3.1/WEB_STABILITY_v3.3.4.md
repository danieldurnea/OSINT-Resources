# BBounty Pro — Web (Next.js) Stability Improvements v3.3.4

**Date:** 2026-05-29 · **Scope:** `apps/web` only (Go/infra untouched)
**Goal:** stop pages from crashing to a blank screen and prevent the UI from
hanging when the backend is slow under multi-user load.

---

## What was wrong (verified in code)

| # | Issue | Effect under load |
|---|---|---|
| 1 | **No error boundaries** — zero `error.tsx`/`global-error.tsx` in the App Router | Any single render error → **blank white screen**, whole page dead |
| 2 | **API client had no timeout** — plain `fetch`, no `AbortController` | If the Go backend is slow, requests hang forever → frozen UI |
| 3 | **No lockfile** (`LOCKFILE_NEEDED.txt`) | Non-reproducible builds → "works locally, breaks in prod" |

The rest of the web stack was actually solid (standalone output, security headers,
WebSocket auto-reconnect, HTTP error handling) — these three were the real gaps.

## What was implemented

### 1. Error boundaries (the big one) — NEW
- **`app/error.tsx`** — route-level boundary. Any error thrown by a page or its
  children now renders a recoverable fallback (with **Retry** + **Home** buttons)
  instead of a blank screen. Matches the existing terminal aesthetic (JetBrains
  Mono, `#080c0e`). Logs the error to console for debugging.
- **`app/global-error.tsx`** — last-resort boundary that catches errors even in
  the root layout. Self-contained (its own `<html>`/`<body>`, inline styles, no
  app imports) so it can never itself fail.

**Why this matters most:** with more users, the odds of *some* component hitting
an edge case rise. Before, one such error killed the page for that user. Now it's
contained to a recoverable panel — the "pages crash" symptom is addressed at the
root.

### 2. API client timeout + retry — `lib/api-client.ts`
- **30s timeout** per request via `AbortController` — a slow/stuck backend can no
  longer hang the UI indefinitely; the user gets a clear "Request timed out"
  instead of a frozen screen.
- **Automatic retry** (up to 2, exponential backoff 400ms→800ms) on *transient*
  failures only: network errors, timeouts, and gateway 502/503/504. Client errors
  (4xx) and other 5xx are **not** retried (correct — retrying them is pointless).
- All 6 API export groups (`api`, `scanAPI`, `findingsAPI`, `skillsAPI`, `roeAPI`,
  `aiAPI`) unchanged — no caller code needs updating.

Verified: `tsc --strict` type-checks `api-client.ts` clean; error boundaries have
valid JSX (only module-resolution noise in the sandbox, which has no node_modules).

## What YOU need to do (one step I can't do here)

**Generate the lockfile** — the sandbox has no npm registry access. On your machine:
```bash
cd apps/web && npm install      # creates package-lock.json
git add package-lock.json && git commit -m "Add web lockfile for reproducible builds"
```
The Dockerfile uses Bun with `--frozen-lockfile` and expects `bun.lockb`; if you
build with Bun, run `bun install` at the repo root to refresh `bun.lockb` too.
Either way, **commit the lockfile** — this fixes issue #3.

## Optional next steps (not done — your call)

- **Loading states** (`loading.tsx`) per route for perceived stability during slow
  fetches (Suspense fallbacks).
- **WebSocket backpressure** — if a scan streams thousands of events fast, throttle
  UI updates (batch with `requestAnimationFrame`) so the browser tab doesn't lag.
  Worth doing only if you see it in practice with real scans.
- **A health/readiness check** on the web container in compose (so orchestration
  restarts it if it wedges).

## Honest note

These three fixes remove the most common Next.js crash/hang patterns, which is the
right place to start. But true "stable with many users" also depends on the **Go
backend** capacity (it does the heavy lifting) and your **VPS sizing** — the
frontend is light. If you still see instability after this, the bottleneck is far
more likely the orchestrator/DB under concurrent scans than the web tier.

---

*Generated 2026-05-29. apps/web only; additive defensive changes; api-client*
*type-checks clean; no API surface changes; lockfile step left for the operator.*
