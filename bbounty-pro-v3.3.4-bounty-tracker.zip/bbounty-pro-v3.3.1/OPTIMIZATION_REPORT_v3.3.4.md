# BBounty Pro v3.3.4 — 2026 Optimization Report (Go / Python)

**Date:** 2026-05-29
**Base:** v3.3.3-HARDENED + recon0 DSL integration
**Scope touched:** `apps/orchestrator` (Go runtime + Redis pool), `apps/ai-proxy`
and `apps/agents` dependency pins. **Untouched:** all Go business logic,
`platform/`, `apps/web/`, infra/compose, Go dependencies (`go.mod`/`go.sum`
pristine — zero new Go deps).

---

## 0. Verification — all green

| Check | Result |
|---|---|
| `go vet ./...` | ✅ |
| `go build ./...` | ✅ |
| `go test ./...` | ✅ |
| `go test -race ./...` | ✅ 0 races, 9 pkgs |
| `gofmt -l` | ✅ clean |
| ai-proxy `import main` under NEW stack | ✅ (verified before committing bumps) |
| anthropic 0.105 API surface used by main.py | ✅ all present |
| ultra_agent import under NEW deps | ✅ |
| `pytest tests/ -q` under NEW deps | ✅ 48 passed |
| `go.mod`/`go.sum` | ✅ pristine, go 1.26 |

---

## 1. Go runtime optimizations (matter most for 10+ concurrent scans)

### Green Tea GC — free, already active · ✅
Go 1.26 (which your Dockerfile now uses, since v3.3.3) ships the **Green Tea
garbage collector as the default**. It cuts GC overhead 10–40% for exactly your
profile: cache-heavy, JSON-heavy, high-fan-out workloads (Redis + many concurrent
scans). **No code change needed** — you get it by building with Go 1.26. This
report just confirms you're positioned to benefit. (Opt-out would be
`GOEXPERIMENT=nogreenteagc`, removed in Go 1.27 — don't.)

### Anti-OOM soft memory limit from cgroup · ✅ (new)
Added `cgroupMemSoftLimit()` (`cmd/server/cgroup_mem.go`) + a startup hook in
`main.go`: when `GOMEMLIMIT` is not set in the env, the orchestrator reads its
own cgroup v2 memory limit and sets the Go soft memory limit to ~90% of it. Under
a burst of 10+ concurrent scans, this makes the GC reclaim aggressively *before*
the container hits its hard 2G limit and gets OOM-killed. Trades a little CPU for
stability. No-ops safely on bare metal / when no limit is enforced. Operators can
still override by setting `GOMEMLIMIT` explicitly (the runtime honours it natively).

### Redis connection pool scales with CPU · ✅
`internal/cache/redis.go` had a fixed `PoolSize=20`, which becomes a bottleneck
under 10+ scans (each holds several connections during Phase Execute). Now
`PoolSize = GOMAXPROCS×10` (min 20), `MinIdleConns = PoolSize/4`. GOMAXPROCS is
container-aware (Go 1.25+), so the pool auto-sizes to the box you deploy on
(e.g. 16 vCPU → 160 connections). go-redis pooling is thread-safe; idle
connections are cheap and reaped after 5 min.

---

## 2. Python dependency modernization (verified, not blind)

The riskiest part of "bump to latest" is breakage. I bumped **only after proving
the actual code still imports and tests pass** under the new versions (in a clean
venv), per the "don't break what works" rule.

### ai-proxy (`apps/ai-proxy/requirements.txt`)
| Package | Was | Now |
|---|---|---|
| fastapi | 0.115.5 | **0.136.3** |
| uvicorn | 0.32.1 | **0.48.0** |
| anthropic | 0.49.0 | **0.105.2** |
| pydantic | 2.10.3 | **2.13.4** |
| google-generativeai | 0.8.3 | **0.8.6** |
| httpx / dotenv / slowapi | unchanged | unchanged |
| ~~starlette / anyio~~ | pinned 0.41.3 / 4.7.0 | **unpinned** (let FastAPI resolve) |

- **Why unpin starlette/anyio:** FastAPI 0.136 needs starlette 1.2.x (a *major*
  jump from 0.41). A manual pin is brittle and was the kind of thing that breaks
  CI. Letting FastAPI pull a compatible pair is the upstream-recommended approach;
  verified it resolves to starlette 1.2.0 / anyio 4.13.0 and `import main` works.
- **Verified:** `import main` succeeds on the full new stack; the anthropic API
  surface the code uses (`AsyncAnthropic`, `messages.create`, `RateLimitError`,
  `APIStatusError`) all exist in 0.105.2.

### agents (`apps/agents/python_runtime/requirements.txt`)
requests 2.32.3→**2.34.2**, urllib3 2.2.3→**2.7.0**, beautifulsoup4 4.12.3→**4.14.3**,
lxml 5.3.0→**6.1.1**, pydantic 2.10.3→**2.13.4**, pyyaml 6.0.2→**6.0.3**.
Verified: `ultra_agent` imports and **all 48 pytest pass** under the new pins.

---

## 3. Found, flagged, NOT changed (would need your call)

- **`google.generativeai` is deprecated upstream** — it now prints a FutureWarning
  ("switch to `google-genai`"). Still works, but a real migration (API rewrite in
  `main.py`) should be planned. Not done here to avoid touching working code blind.
- **`encoding/json/v2`** (Go 1.25+, opt-in via `GOEXPERIMENT=jsonv2`) is faster for
  large/nested JSON — your tool-output parsing would benefit. Left out because it's
  still experimental and a build-flag change; worth a dedicated, benchmarked pass.
- **Go image digest pinning** (`@sha256:`) — still a documented TODO from v3.3.3
  (can't resolve a digest here without a registry pull).

---

## 4. What you should do on the VPS

1. Rebuild: `docker compose -f infra/docker-compose.yml build` (pulls the new
   Python deps; Go already on 1.26 → Green Tea GC active).
2. The anti-OOM soft limit activates automatically inside the container (reads the
   cgroup limit). Nothing to set. To tune manually, set `GOMEMLIMIT` (e.g. `1800MiB`).
3. Watch `docker stats` — with the scaled Redis pool + Green Tea GC, the
   orchestrator should hold up better under concurrent scans. If RSS still nears
   the 2G limit with many scans, raise the orchestrator `memory:` limit in compose.

---

## 5. Honest note on impact

These are **solid, low-risk wins**, not magic. The biggest real-world lever for
your "10+ concurrent scans" goal is still **hardware + concurrency limits + (eventually)
separating the Kali workers onto their own host** — software tuning helps at the
margins (GC overhead, pool contention, OOM stability), but it won't make a 4-vCPU
box behave like a 16-vCPU one. Size the VPS first, then these optimizations make
that hardware go further.

---

*Generated 2026-05-29. All verification green; zero new Go deps; Python bumps*
*proven import- and test-compatible before committing.*
