// Package billing handles Stripe subscription management for BBounty Pro.
//
// Flow:
//
//	User clicks "Subscribe" → POST /api/v1/billing/checkout
//	→ redirect to Stripe Checkout (hosted page, no card data touches our server)
//	→ Stripe calls POST /api/v1/billing/webhook on success/failure
//	→ webhook activates plan in Redis (instant, no DB round-trip)
//	→ plan enforcement middleware checks Redis on every /api/v1/scan/start
//
// Plans:
//
//	solo         $29/mo  30 scans/month
//	professional $79/mo  unlimited scans, Claude Code reports
//	team         $199/mo 5 seats, unlimited scans, API access
package billing

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/rs/zerolog/log"
)

// billingDebitKey is the context key for the billing debit function.
// Set by EnforcePlan, consumed by HandleStart on successful scan creation.
type billingDebitKey struct{}

// DebitScan calls the billing debit function stored in ctx by EnforcePlan.
// Must be called by HandleStart after scan is successfully created.
// No-op if key not present (e.g. in tests).
func DebitScan(ctx context.Context) {
	if fn, ok := ctx.Value(billingDebitKey{}).(func()); ok && fn != nil {
		fn()
	}
}

// ── Plan definitions ──────────────────────────────────────────────────────────

type Plan struct {
	ID            string
	Name          string
	PriceUSD      int // cents per month
	StripePriceID string
	ScansPerMonth int // -1 = unlimited
	Features      []string
}

var Plans = map[string]Plan{
	"solo": {
		ID: "solo", Name: "Solo Hunter", PriceUSD: 2900,
		ScansPerMonth: 30,
		Features: []string{
			"30 scans/month",
			"Profiles: quick + deep",
			"Dashboard + Markdown reports",
			"Findings in real-time",
		},
	},
	"professional": {
		ID: "professional", Name: "Professional", PriceUSD: 7900,
		ScansPerMonth: -1,
		Features: []string{
			"Unlimited scans",
			"All profiles (incl. reconftw-deep)",
			"Claude Code AI reports",
			"Telegram/Slack notify on critical",
			"interactsh OOB detection",
			"bountyplz auto-submit",
		},
	},
	"team": {
		ID: "team", Name: "Team", PriceUSD: 19900,
		ScansPerMonth: -1,
		Features: []string{
			"5 seats",
			"Unlimited scans",
			"All Professional features",
			"API access",
			"Priority support",
		},
	},
}

// ── Subscription stored in Redis ──────────────────────────────────────────────

type Subscription struct {
	UserID               string     `json:"user_id"`
	PlanID               string     `json:"plan_id"`
	StripeCustomerID     string     `json:"stripe_customer_id"`
	StripeSubscriptionID string     `json:"stripe_subscription_id"`
	Status               string     `json:"status"` // active, canceled, past_due, trialing
	CurrentPeriodStart   time.Time  `json:"current_period_start"`
	CurrentPeriodEnd     time.Time  `json:"current_period_end"`
	ScansUsedThisPeriod  int        `json:"scans_used_this_period"`
	CanceledAt           *time.Time `json:"canceled_at,omitempty"`
}

func (s *Subscription) IsActive() bool {
	return s.Status == "active" || s.Status == "trialing"
}

func (s *Subscription) Plan() Plan {
	if p, ok := Plans[s.PlanID]; ok {
		return p
	}
	return Plans["solo"]
}

func (s *Subscription) CanScan() (bool, string) {
	if !s.IsActive() {
		return false, "subscription not active — visit /billing to renew"
	}
	plan := s.Plan()
	if plan.ScansPerMonth == -1 {
		return true, "" // unlimited
	}
	if s.ScansUsedThisPeriod >= plan.ScansPerMonth {
		return false, fmt.Sprintf(
			"scan limit reached (%d/%d) — upgrade to Professional for unlimited scans",
			s.ScansUsedThisPeriod, plan.ScansPerMonth,
		)
	}
	return true, ""
}

// ── Service ───────────────────────────────────────────────────────────────────

// Service holds billing state and optional email callback.
type Service struct {
	cache               *cache.Client
	stripeKey           string
	stripeWebhookSecret string
	appURL              string
	// onPayment is called after successful checkout to send receipt email.
	// Injected from main.go to avoid circular dependency.
	onPayment func(ctx context.Context, userID, planName string, amountUSD int)
}

func New(c *cache.Client, stripeKey, webhookSecret, appURL string) *Service {
	return &Service{
		cache:               c,
		stripeKey:           stripeKey,
		stripeWebhookSecret: webhookSecret,
		appURL:              strings.TrimRight(appURL, "/"),
	}
}

// SetPaymentCallback injects a function called after successful Stripe checkout.
// Use from main.go to send receipt emails without circular imports.
func (s *Service) SetPaymentCallback(fn func(ctx context.Context, userID, planName string, amountUSD int)) {
	s.onPayment = fn
}

// ── Redis keys ────────────────────────────────────────────────────────────────

func keySubscription(userID string) string { return "billing:sub:" + userID }
func keyCustomer(customerID string) string { return "billing:customer:" + customerID }
func keyScanCount(userID, period string) string {
	return fmt.Sprintf("billing:scans:%s:%s", userID, period)
}

// ── Subscription CRUD ─────────────────────────────────────────────────────────

func (s *Service) GetSubscription(ctx context.Context, userID string) (*Subscription, error) {
	raw, err := s.cache.Raw().Get(ctx, keySubscription(userID)).Result()
	if err != nil {
		return nil, err
	}
	var sub Subscription
	if err := json.Unmarshal([]byte(raw), &sub); err != nil {
		return nil, err
	}
	return &sub, nil
}

func (s *Service) SaveSubscription(ctx context.Context, sub *Subscription) error {
	data, err := json.Marshal(sub)
	if err != nil {
		return err
	}
	// Store for 2 billing periods (safety margin)
	ttl := time.Until(sub.CurrentPeriodEnd) + 60*24*time.Hour
	if ttl < 24*time.Hour {
		ttl = 24 * time.Hour
	}
	if err := s.cache.Raw().Set(ctx, keySubscription(sub.UserID), data, ttl).Err(); err != nil {
		return err
	}
	// Index by Stripe customer ID
	return s.cache.Raw().Set(ctx,
		keyCustomer(sub.StripeCustomerID), sub.UserID,
		ttl,
	).Err()
}

// IncrementScanCount increments the scan counter for the current billing period.
// Returns the new count.
func (s *Service) IncrementScanCount(ctx context.Context, userID string) (int64, error) {
	period := time.Now().Format("2006-01") // YYYY-MM
	key := keyScanCount(userID, period)
	count, err := s.cache.Raw().Incr(ctx, key).Result()
	if err != nil {
		return 0, err
	}
	// Set TTL to end of month + 7 days safety
	s.cache.Raw().Expire(ctx, key, 40*24*time.Hour)
	return count, nil
}

func (s *Service) GetScanCount(ctx context.Context, userID string) (int, error) {
	period := time.Now().Format("2006-01")
	raw, err := s.cache.Raw().Get(ctx, keyScanCount(userID, period)).Result()
	if err != nil {
		return 0, nil // no scans yet
	}
	n, err := strconv.Atoi(raw)
	if err != nil {
		// Redis value corrupted — treat as 0 and log
		log.Warn().Str("raw", raw).Str("user", userID).
			Msg("[billing] scan count parse error — treating as 0")
		return 0, nil
	}
	return n, nil
}

// ── Stripe Checkout ───────────────────────────────────────────────────────────

type CheckoutRequest struct {
	PlanID string `json:"plan_id"`
	UserID string `json:"-"` // from JWT context
	Email  string `json:"-"` // from JWT context
}

type CheckoutResponse struct {
	URL string `json:"url"`
}

// CreateCheckoutSession creates a Stripe Checkout session and returns the URL.
// The user is redirected to Stripe's hosted page — card data never touches our server.
func (s *Service) CreateCheckoutSession(ctx context.Context, req CheckoutRequest) (*CheckoutResponse, error) {
	plan, ok := Plans[req.PlanID]
	if !ok {
		return nil, fmt.Errorf("unknown plan: %s", req.PlanID)
	}

	if plan.StripePriceID == "" {
		// StripePriceID not set — return instructions
		return nil, fmt.Errorf(
			"Stripe price ID not configured for plan %s — set STRIPE_PRICE_%s in .env",
			req.PlanID, strings.ToUpper(req.PlanID),
		)
	}

	// Build Stripe Checkout session via API
	body := strings.NewReader(fmt.Sprintf(
		"mode=subscription"+
			"&payment_method_types[0]=card"+
			"&line_items[0][price]=%s"+
			"&line_items[0][quantity]=1"+
			"&customer_email=%s"+
			"&metadata[user_id]=%s"+
			"&metadata[plan_id]=%s"+
			"&success_url=%s/billing/success?session_id={CHECKOUT_SESSION_ID}"+
			"&cancel_url=%s/billing/cancel",
		plan.StripePriceID,
		req.Email,
		req.UserID,
		req.PlanID,
		s.appURL,
		s.appURL,
	))

	httpReq, err := http.NewRequestWithContext(ctx,
		http.MethodPost,
		"https://api.stripe.com/v1/checkout/sessions",
		body,
	)
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Authorization", "Bearer "+s.stripeKey)
	httpReq.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := http.DefaultClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("stripe API error: %w", err)
	}
	defer resp.Body.Close()

	var session struct {
		URL   string `json:"url"`
		Error *struct {
			Message string `json:"message"`
		} `json:"error"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&session); err != nil {
		return nil, err
	}
	if session.Error != nil {
		return nil, fmt.Errorf("stripe: %s", session.Error.Message)
	}
	if session.URL == "" {
		return nil, fmt.Errorf("stripe returned empty URL")
	}

	return &CheckoutResponse{URL: session.URL}, nil
}

// CreatePortalSession creates a Stripe Customer Portal session (manage subscription).
func (s *Service) CreatePortalSession(ctx context.Context, userID string) (string, error) {
	sub, err := s.GetSubscription(ctx, userID)
	if err != nil || sub == nil {
		return "", fmt.Errorf("no subscription found")
	}

	body := strings.NewReader(fmt.Sprintf(
		"customer=%s&return_url=%s/billing",
		sub.StripeCustomerID, s.appURL,
	))

	req, _ := http.NewRequestWithContext(ctx,
		http.MethodPost,
		"https://api.stripe.com/v1/billing_portal/sessions",
		body,
	)
	req.Header.Set("Authorization", "Bearer "+s.stripeKey)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	var portal struct {
		URL string `json:"url"`
	}
	json.NewDecoder(resp.Body).Decode(&portal)
	return portal.URL, nil
}

// ── Webhook handler ───────────────────────────────────────────────────────────

// HandleWebhook processes Stripe webhook events.
// Stripe signs every event — we verify the signature before processing.
func (s *Service) HandleWebhook(w http.ResponseWriter, r *http.Request) {
	const maxBodyBytes = 65536
	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)

	payload, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "payload too large", http.StatusRequestEntityTooLarge)
		return
	}

	// Verify Stripe signature
	sigHeader := r.Header.Get("Stripe-Signature")
	if !s.verifyWebhookSignature(payload, sigHeader) {
		log.Warn().Str("sig", sigHeader).Msg("invalid Stripe webhook signature")
		http.Error(w, "invalid signature", http.StatusBadRequest)
		return
	}

	// Parse event
	var event struct {
		Type string          `json:"type"`
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(payload, &event); err != nil {
		http.Error(w, "invalid JSON", http.StatusBadRequest)
		return
	}

	log.Info().Str("event", event.Type).Msg("[billing] Stripe webhook")

	switch event.Type {
	case "checkout.session.completed":
		s.handleCheckoutCompleted(r.Context(), event.Data)
	case "customer.subscription.updated":
		s.handleSubscriptionUpdated(r.Context(), event.Data)
	case "customer.subscription.deleted":
		s.handleSubscriptionDeleted(r.Context(), event.Data)
	case "invoice.payment_failed":
		s.handlePaymentFailed(r.Context(), event.Data)
	case "invoice.payment_succeeded":
		s.handlePaymentSucceeded(r.Context(), event.Data)
	default:
		// Unhandled event — acknowledge and ignore
	}

	w.WriteHeader(http.StatusOK)
}

func (s *Service) verifyWebhookSignature(payload []byte, sigHeader string) bool {
	if s.stripeWebhookSecret == "" || sigHeader == "" {
		return false
	}

	// Extract timestamp and signature from Stripe-Signature header
	// Format: t=1492774577,v1=5257a869e7ecebeda32affa62cdca3fa51cad7e7...
	var ts string
	var sig string
	for _, part := range strings.Split(sigHeader, ",") {
		kv := strings.SplitN(part, "=", 2)
		if len(kv) != 2 {
			continue
		}
		switch kv[0] {
		case "t":
			ts = kv[1]
		case "v1":
			sig = kv[1]
		}
	}
	if ts == "" || sig == "" {
		return false
	}

	// Compute expected signature
	mac := hmac.New(sha256.New, []byte(s.stripeWebhookSecret))
	mac.Write([]byte(ts + "." + string(payload)))
	expected := hex.EncodeToString(mac.Sum(nil))

	return hmac.Equal([]byte(expected), []byte(sig))
}

// ── Webhook event handlers ────────────────────────────────────────────────────

type stripeSubscription struct {
	ID                 string            `json:"id"`
	Status             string            `json:"status"`
	Customer           string            `json:"customer"`
	CurrentPeriodStart int64             `json:"current_period_start"`
	CurrentPeriodEnd   int64             `json:"current_period_end"`
	Metadata           map[string]string `json:"metadata"`
	CanceledAt         *int64            `json:"canceled_at"`
}

type stripeCheckoutSession struct {
	ID           string            `json:"id"`
	Customer     string            `json:"customer"`
	Subscription string            `json:"subscription"`
	Metadata     map[string]string `json:"metadata"`
}

func (s *Service) handleCheckoutCompleted(ctx context.Context, data json.RawMessage) {
	var wrapper struct {
		Object stripeCheckoutSession `json:"object"`
	}
	if err := json.Unmarshal(data, &wrapper); err != nil {
		log.Error().Err(err).Msg("[billing] checkout.session.completed parse error")
		return
	}
	sess := wrapper.Object

	userID := sess.Metadata["user_id"]
	planID := sess.Metadata["plan_id"]
	if userID == "" || planID == "" {
		log.Error().Msg("[billing] missing metadata in checkout session")
		return
	}

	// Fetch full subscription from Stripe
	sub, err := s.fetchStripeSubscription(ctx, sess.Subscription)
	if err != nil {
		log.Error().Err(err).Msg("[billing] fetch subscription failed")
		return
	}

	bbSub := &Subscription{
		UserID:               userID,
		PlanID:               planID,
		StripeCustomerID:     sess.Customer,
		StripeSubscriptionID: sess.Subscription,
		Status:               sub.Status,
		CurrentPeriodStart:   time.Unix(sub.CurrentPeriodStart, 0),
		CurrentPeriodEnd:     time.Unix(sub.CurrentPeriodEnd, 0),
	}

	if err := s.SaveSubscription(ctx, bbSub); err != nil {
		log.Error().Err(err).Str("user", userID).Msg("[billing] save subscription failed")
		return
	}

	log.Info().
		Str("user", userID).
		Str("plan", planID).
		Str("status", sub.Status).
		Msg("[billing] ✓ subscription activated")

	// Send receipt email
	if s.onPayment != nil {
		plan := Plans[planID]
		go s.onPayment(context.Background(), userID, plan.Name, plan.PriceUSD)
	}
}
func (s *Service) handleSubscriptionUpdated(ctx context.Context, data json.RawMessage) {
	var wrapper struct {
		Object stripeSubscription `json:"object"`
	}
	if err := json.Unmarshal(data, &wrapper); err != nil {
		return
	}
	sub := wrapper.Object

	userID, err := s.cache.Raw().Get(ctx, keyCustomer(sub.Customer)).Result()
	if err != nil || userID == "" {
		return
	}

	existing, err := s.GetSubscription(ctx, userID)
	if err != nil || existing == nil {
		return
	}

	existing.Status = sub.Status
	existing.CurrentPeriodStart = time.Unix(sub.CurrentPeriodStart, 0)
	existing.CurrentPeriodEnd = time.Unix(sub.CurrentPeriodEnd, 0)

	if sub.CanceledAt != nil {
		t := time.Unix(*sub.CanceledAt, 0)
		existing.CanceledAt = &t
	}

	// Plan may have changed (upgrade/downgrade)
	if planID := sub.Metadata["plan_id"]; planID != "" {
		existing.PlanID = planID
	}

	s.SaveSubscription(ctx, existing)
	log.Info().Str("user", userID).Str("status", sub.Status).Msg("[billing] subscription updated")
}

func (s *Service) handleSubscriptionDeleted(ctx context.Context, data json.RawMessage) {
	var wrapper struct {
		Object stripeSubscription `json:"object"`
	}
	if err := json.Unmarshal(data, &wrapper); err != nil {
		return
	}
	sub := wrapper.Object

	userID, err := s.cache.Raw().Get(ctx, keyCustomer(sub.Customer)).Result()
	if err != nil || userID == "" {
		return
	}

	existing, err := s.GetSubscription(ctx, userID)
	if err != nil || existing == nil {
		return
	}

	existing.Status = "canceled"
	s.SaveSubscription(ctx, existing)
	log.Info().Str("user", userID).Msg("[billing] subscription canceled")
}

func (s *Service) handlePaymentFailed(ctx context.Context, data json.RawMessage) {
	var wrapper struct {
		Object struct {
			Customer     string `json:"customer"`
			Subscription string `json:"subscription"`
		} `json:"object"`
	}
	if err := json.Unmarshal(data, &wrapper); err != nil {
		return
	}

	userID, _ := s.cache.Raw().Get(ctx, keyCustomer(wrapper.Object.Customer)).Result()
	log.Warn().Str("user", userID).Msg("[billing] payment failed — subscription may go past_due")
}

func (s *Service) handlePaymentSucceeded(ctx context.Context, data json.RawMessage) {
	var wrapper struct {
		Object struct {
			Customer     string `json:"customer"`
			Subscription string `json:"subscription"`
		} `json:"object"`
	}
	if err := json.Unmarshal(data, &wrapper); err != nil {
		return
	}

	userID, _ := s.cache.Raw().Get(ctx, keyCustomer(wrapper.Object.Customer)).Result()
	if userID == "" {
		return
	}

	// Reset scan counter on successful renewal
	period := time.Now().Format("2006-01")
	s.cache.Raw().Del(ctx, keyScanCount(userID, period))
	log.Info().Str("user", userID).Msg("[billing] payment succeeded — scan counter reset")
}

func (s *Service) fetchStripeSubscription(ctx context.Context, subID string) (*stripeSubscription, error) {
	req, _ := http.NewRequestWithContext(ctx,
		http.MethodGet,
		"https://api.stripe.com/v1/subscriptions/"+subID,
		nil,
	)
	req.Header.Set("Authorization", "Bearer "+s.stripeKey)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var sub stripeSubscription
	if err := json.NewDecoder(resp.Body).Decode(&sub); err != nil {
		return nil, err
	}
	return &sub, nil
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

// HandlePlans returns all available plans.
// GET /api/v1/billing/plans
func (s *Service) HandlePlans(w http.ResponseWriter, r *http.Request) {
	type planResp struct {
		ID            string   `json:"id"`
		Name          string   `json:"name"`
		PriceUSD      int      `json:"price_usd"`
		ScansPerMonth int      `json:"scans_per_month"` // -1 = unlimited
		Features      []string `json:"features"`
	}
	var plans []planResp
	for _, order := range []string{"solo", "professional", "team"} {
		p := Plans[order]
		plans = append(plans, planResp{
			ID: p.ID, Name: p.Name, PriceUSD: p.PriceUSD,
			ScansPerMonth: p.ScansPerMonth, Features: p.Features,
		})
	}
	writeJSON(w, http.StatusOK, plans)
}

// HandleCheckout creates a Stripe Checkout session.
// POST /api/v1/billing/checkout
func (s *Service) HandleCheckout(w http.ResponseWriter, r *http.Request) {
	userID := r.Context().Value("userID")
	email := r.Context().Value("email")
	if userID == nil {
		writeErr(w, http.StatusUnauthorized, "not authenticated")
		return
	}

	var req struct {
		PlanID string `json:"plan_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid request body")
		return
	}

	resp, err := s.CreateCheckoutSession(r.Context(), CheckoutRequest{
		PlanID: req.PlanID,
		UserID: fmt.Sprintf("%v", userID),
		Email:  fmt.Sprintf("%v", email),
	})
	if err != nil {
		log.Error().Err(err).Msg("[billing] checkout error")
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}

	writeJSON(w, http.StatusOK, resp)
}

// HandlePortal redirects to Stripe Customer Portal (manage subscription, cancel, etc.)
// POST /api/v1/billing/portal
func (s *Service) HandlePortal(w http.ResponseWriter, r *http.Request) {
	userID := fmt.Sprintf("%v", r.Context().Value("userID"))
	url, err := s.CreatePortalSession(r.Context(), userID)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"url": url})
}

// HandleStatus returns the current subscription status for the authenticated user.
// GET /api/v1/billing/status
func (s *Service) HandleStatus(w http.ResponseWriter, r *http.Request) {
	userID := fmt.Sprintf("%v", r.Context().Value("userID"))

	sub, err := s.GetSubscription(r.Context(), userID)
	if err != nil {
		// No subscription — return free tier info
		writeJSON(w, http.StatusOK, map[string]any{
			"plan":          "none",
			"status":        "inactive",
			"scans_used":    0,
			"scans_allowed": 0,
			"message":       "No active subscription. Visit /billing to subscribe.",
		})
		return
	}

	scansUsed, _ := s.GetScanCount(r.Context(), userID)
	plan := sub.Plan()

	writeJSON(w, http.StatusOK, map[string]any{
		"plan":               sub.PlanID,
		"plan_name":          plan.Name,
		"status":             sub.Status,
		"is_active":          sub.IsActive(),
		"scans_used":         scansUsed,
		"scans_allowed":      plan.ScansPerMonth,
		"current_period_end": sub.CurrentPeriodEnd,
		"features":           plan.Features,
	})
}

// ── Plan enforcement middleware ───────────────────────────────────────────────

// EnforcePlan is a middleware that checks if the user has an active subscription
// and hasn't exceeded their scan limit before allowing a scan to start.
func (s *Service) EnforcePlan(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		userID := fmt.Sprintf("%v", r.Context().Value("userID"))
		if userID == "" || userID == "<nil>" {
			writeErr(w, http.StatusUnauthorized, "not authenticated")
			return
		}

		sub, err := s.GetSubscription(r.Context(), userID)
		if err != nil {
			writeErr(w, http.StatusPaymentRequired,
				"no active subscription — visit /billing to subscribe")
			return
		}

		canScan, reason := sub.CanScan()
		if !canScan {
			writeErr(w, http.StatusPaymentRequired, reason)
			return
		}

		// Store debit function in context — called by HandleStart ONLY on success.
		// FIX: incrementing here (before scan starts) caused count leak if
		// HandleStart returned an error (e.g. rate limit, invalid target).
		debitFn := func() {
			ctx2 := context.Background()
			if _, err := s.IncrementScanCount(ctx2, userID); err != nil {
				log.Error().Err(err).Str("user", userID).Msg("[billing] scan count increment failed")
			}
			// Store plan in Redis for concurrent scan limit check
			planKey := "billing:plan:" + userID
			s.cache.Raw().Set(ctx2, planKey, sub.Plan, 35*24*time.Hour)
		}
		ctx := context.WithValue(r.Context(), billingDebitKey{}, debitFn)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}
